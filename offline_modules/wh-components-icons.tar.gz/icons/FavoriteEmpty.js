"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var FavoriteEmpty = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 4l2.09 4.25a1.52 1.52 0 001.14.82l4.64.64-3.42 3.32a1.49 1.49 0 00-.45 1.38l.8 4.59-4.17-2.19a1.45 1.45 0 00-.7-.17 1.49 1.49 0 00-.71.17L7.11 19l.8-4.65A1.53 1.53 0 007.48 13L4.14 9.77l4.69-.69A1.52 1.52 0 0010 8.25L12 4m0-2.21a.94.94 0 00-.86.53L8.61 7.59l-5.79.86a.94.94 0 00-.77.64.92.92 0 00.24 1l4.14 4-1 5.79a.92.92 0 00.39.91.9.9 0 001 .06l5.12-2.73 5.2 2.73a.81.81 0 00.44.12.76.76 0 00.53-.18.93.93 0 00.38-.91l-1-5.73L21.72 10a.92.92 0 00.23-1 1 1 0 00-.76-.64l-5.76-.8-2.59-5.2a1 1 0 00-.84-.53z",
    fill: "currentColor"
  }));
});
var _default = FavoriteEmpty;
exports["default"] = _default;