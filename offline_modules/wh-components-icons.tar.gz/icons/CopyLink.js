"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var CopyLink = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M20 10.31l-5 5a3.28 3.28 0 01-4.61.06L8.8 13.71l1.59-1.59L12 13.74a1.06 1.06 0 001.46-.06l4.94-4.93a1.06 1.06 0 00.06-1.46l-1.78-1.78a1.06 1.06 0 00-1.46.06l-1.75 1.75a3.27 3.27 0 00-2.76-.39L13.66 4a3.31 3.31 0 014.64-.06l1.79 1.76a3.25 3.25 0 01-.09 4.61zm-9.47 6.35L8.7 18.48a1 1 0 01-1.43 0l-1.75-1.75a1 1 0 010-1.43l5-5a.94.94 0 011.36 0L13.5 12l1.59-1.59-1.62-1.63A3.13 3.13 0 009 8.75l-5 5a3.23 3.23 0 000 4.57l1.79 1.79a3.24 3.24 0 004.57 0l3-3a3.25 3.25 0 01-2.84-.45z",
    fill: "currentColor"
  }));
});
var _default = CopyLink;
exports["default"] = _default;