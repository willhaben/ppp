"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var EyeDisabled = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 9.27A2.82 2.82 0 009.14 12a2.1 2.1 0 00.06.51l3.22-3.22a2.58 2.58 0 00-.42-.02zM12 14.78A2.83 2.83 0 0014.9 12a3.31 3.31 0 00-.05-.55l-3.27 3.26a2.2 2.2 0 00.42.07z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M7.49 12A4.44 4.44 0 0112 7.69a4.55 4.55 0 011.7.32l1.82-1.82A11 11 0 002 12a11.49 11.49 0 003.44 4.25l2.45-2.45a4.18 4.18 0 01-.4-1.8zM16.56 12A4.44 4.44 0 0112 16.36a4.71 4.71 0 01-1.71-.36l-1.83 1.86a11.08 11.08 0 003.56.56c7.12 0 10-6.4 10-6.4a12 12 0 00-3.49-4.24l-2.41 2.41a4.22 4.22 0 01.44 1.81zM2.634 20.52L20.538 2.614l.877.877L3.511 21.396z"
  })));
});
var _default = EyeDisabled;
exports["default"] = _default;