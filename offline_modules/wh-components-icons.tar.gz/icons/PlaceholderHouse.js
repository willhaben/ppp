"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var PlaceholderHouse = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    viewBox: "0 0 283.46 283.46",
    width: "1em",
    height: "1em",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    "data-name": "icon_placeholder_house",
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M203 226.06H80.76a11.61 11.61 0 01-11.6-11.6v-74.89h-.39a7.85 7.85 0 01-7.27-5.22 8.57 8.57 0 011.8-9.46l73.22-69.54a7.34 7.34 0 0110.49.06l73.68 70a8.25 8.25 0 011.74 9.13 7.56 7.56 0 01-7 5h-1.12v75.18A11.32 11.32 0 01203 226.06zm-61.22-166.9a1.71 1.71 0 00-1.15.56l-73.19 69.52a2.69 2.69 0 00-.37 2.88c.14.34.66 1.45 1.7 1.45h3.39a3 3 0 013 3v77.89a5.61 5.61 0 005.6 5.6H203a5.31 5.31 0 005.3-5.31v-78.18a3 3 0 013-3h4.12c.85 0 1.31-1 1.43-1.26a2.43 2.43 0 00-.3-2.56l-73.74-70a1.51 1.51 0 00-1.03-.59z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M141.73 136.87a20 20 0 1120-20 20.05 20.05 0 01-20 20zm0-34.05a14 14 0 1014 14 14 14 0 00-14-14zM129.76 199.58h-34.7a8.68 8.68 0 01-8.67-8.67v-24.53a8.68 8.68 0 018.67-8.67h34.7a8.68 8.68 0 018.67 8.67v24.53a8.68 8.68 0 01-8.67 8.67zm-34.7-35.87a2.67 2.67 0 00-2.67 2.67v24.53a2.67 2.67 0 002.67 2.67h34.7a2.67 2.67 0 002.67-2.67v-24.53a2.67 2.67 0 00-2.67-2.67zM195.53 222.11h-6v-55.56a2.68 2.68 0 00-2.67-2.67h-29.73a2.68 2.68 0 00-2.67 2.67v55.56h-6v-55.56a8.68 8.68 0 018.67-8.67h29.73a8.68 8.68 0 018.67 8.67z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M129.76 199.58h-34.7a8.68 8.68 0 01-8.67-8.67v-24.53a8.68 8.68 0 018.67-8.67h34.7a8.68 8.68 0 018.67 8.67v24.53a8.68 8.68 0 01-8.67 8.67zm-34.7-35.87a2.67 2.67 0 00-2.67 2.67v24.53a2.67 2.67 0 002.67 2.67h34.7a2.67 2.67 0 002.67-2.67v-24.53a2.67 2.67 0 00-2.67-2.67zM202.05 113.08a3 3 0 01-3-3V81.2a1.25 1.25 0 00-1.24-1.2h-14.74a1.24 1.24 0 00-1.23 1.23v6.61a3 3 0 01-6 0V81.2a7.23 7.23 0 017.23-7.2h14.74a7.24 7.24 0 017.24 7.23v28.88a3 3 0 01-3 2.97z"
  })));
});
var _default = PlaceholderHouse;
exports["default"] = _default;