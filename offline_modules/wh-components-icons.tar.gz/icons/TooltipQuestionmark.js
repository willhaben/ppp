"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var TooltipQuestionmark = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 2A10 10 0 112 12 10 10 0 0112 2z",
    fill: "#f4f6fb",
    fillRule: "evenodd"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 3a9 9 0 11-9 9 9 9 0 019-9m0-1a10 10 0 1010 10A10 10 0 0012 2z",
    fill: "#cad3e1"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M10.22 16.85a1.43 1.43 0 01.37-1.05 1.51 1.51 0 011.09-.36 1.43 1.43 0 011.06.37 1.6 1.6 0 010 2.07 1.46 1.46 0 01-1.06.38 1.54 1.54 0 01-1.08-.37 1.4 1.4 0 01-.38-1.04zm.27-2.85v-.61a2.7 2.7 0 01.34-1.39 4.38 4.38 0 011.24-1.25 4.89 4.89 0 001.14-1 1.43 1.43 0 00.28-.87 1 1 0 00-.4-.82A1.92 1.92 0 0012 7.79a6.4 6.4 0 00-2.84.81l-.9-1.81a7.89 7.89 0 013.92-1 4.15 4.15 0 012.71.82 2.65 2.65 0 011 2.18 2.85 2.85 0 01-.41 1.57 5.82 5.82 0 01-1.57 1.49 4.93 4.93 0 00-1 .9 1.38 1.38 0 00-.21.8V14z",
    fill: "#5d6675",
    fillRule: "evenodd"
  }));
});
var _default = TooltipQuestionmark;
exports["default"] = _default;