"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Expiresoon = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21 8.37a3.66 3.66 0 001-2.57 3.75 3.75 0 00-6.4-2.65A9.73 9.73 0 0121 8.37zM8.49 3.15a3.75 3.75 0 10-5.4 5.21 9.72 9.72 0 015.4-5.21z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M17.31 18.89a8.52 8.52 0 10-12-1.44 8.23 8.23 0 001.45 1.44l-.9 1.5a1.06 1.06 0 00.37 1.46 1 1 0 00.55.15 1.06 1.06 0 00.91-.5l.92-1.5a8.55 8.55 0 006.87 0l.9 1.49a1.07 1.07 0 001.84-1.11zm-4.56-5a1.91 1.91 0 01-.71.14 1.85 1.85 0 01-.76-3.55V6.89a.76.76 0 111.52 0v3.62a1.82 1.82 0 011 2.26L16.15 15a.77.77 0 010 1.07.73.73 0 01-.53.24.75.75 0 01-.52-.2z"
  })));
});
var _default = Expiresoon;
exports["default"] = _default;