"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var ImageUpload = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M15.19 12.05a3.81 3.81 0 11-3.81-3.8 3.81 3.81 0 013.81 3.8zm5 5.05v-2.3h-1.41v2.3h-2.31v1.41h2.31v2.31h1.41v-2.31h2.31V17.1zm-3.72-.62h-.63v2.06H3.62a1.12 1.12 0 01-1.12-1.11V6.92a1.12 1.12 0 011.12-1.11h4.6s0-1.62 1-1.62h4.46c1 0 1 1.62 1 1.62h4.45a1.12 1.12 0 011.12 1.11v7.26h-2v2.3zm0-4.43a5.13 5.13 0 10-5.13 5.11 5.13 5.13 0 005.17-5.11z",
    fill: "currentColor"
  }));
});
var _default = ImageUpload;
exports["default"] = _default;