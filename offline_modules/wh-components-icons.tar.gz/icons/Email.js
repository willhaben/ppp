"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Email = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M13.11 15a1.56 1.56 0 01-2.21 0l-2.07-2.08a.31.31 0 00-.44 0l-5.15 5.15a.31.31 0 00.21.53h17.11a.31.31 0 00.21-.53l-5.15-5.15a.31.31 0 00-.44 0z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M3.24 5.92l8.55 8.55a.3.3 0 00.43 0l8.55-8.55a.3.3 0 00-.21-.52H3.45a.3.3 0 00-.21.52zM2 6.84v10.33a.31.31 0 00.53.22l5.16-5.17a.3.3 0 000-.43L2.53 6.62a.31.31 0 00-.53.22zM22 6.84v10.33a.3.3 0 01-.52.22l-5.17-5.17a.3.3 0 010-.43l5.17-5.17a.3.3 0 01.52.22z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    "data-name": "message4",
    d: "M13.11 15a1.56 1.56 0 01-2.21 0l-2.07-2.08a.31.31 0 00-.44 0l-5.15 5.15a.31.31 0 00.21.53h17.11a.31.31 0 00.21-.53l-5.15-5.15a.31.31 0 00-.44 0z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    "data-name": "message3",
    d: "M3.24 5.92l8.55 8.55a.3.3 0 00.43 0l8.55-8.55a.3.3 0 00-.21-.52H3.45a.3.3 0 00-.21.52z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    "data-name": "message2",
    d: "M2 6.84v10.33a.31.31 0 00.53.22l5.16-5.17a.3.3 0 000-.43L2.53 6.62a.31.31 0 00-.53.22z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    "data-name": "message1",
    d: "M22 6.84v10.33a.3.3 0 01-.52.22l-5.17-5.17a.3.3 0 010-.43l5.17-5.17a.3.3 0 01.52.22z"
  })));
});
var _default = Email;
exports["default"] = _default;