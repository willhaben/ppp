"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var SocialTwitter = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M8.29 20.13A11.59 11.59 0 0020 8.45v-.53a8.43 8.43 0 002-2.12 8.49 8.49 0 01-2.36.64 4.1 4.1 0 001.81-2.27 8.17 8.17 0 01-2.61 1 4.1 4.1 0 00-7 3.74 11.64 11.64 0 01-8.45-4.29 4.16 4.16 0 00-.55 2.07 4.09 4.09 0 001.82 3.41 4.07 4.07 0 01-1.86-.51v.05a4.1 4.1 0 003.29 4 3.81 3.81 0 01-1.09.17 3.94 3.94 0 01-.77-.08 4.11 4.11 0 003.84 2.85A8.27 8.27 0 013 18.34a7.93 7.93 0 01-1-.06 11.57 11.57 0 006.29 1.85",
    fill: "currentColor"
  }));
});
var _default = SocialTwitter;
exports["default"] = _default;