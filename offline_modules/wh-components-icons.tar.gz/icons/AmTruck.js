"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var AmTruck = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    "data-name": "Vertical Icons",
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21.72 12.35a19.19 19.19 0 00-1.39-3.61l-.47-.93a1.09 1.09 0 00-1-.67h-3.7a1.11 1.11 0 00-1.1 1.11v4.09a.09.09 0 01-.1.1h-.29a.1.1 0 01-.11-.11V7a1.1 1.1 0 00-1.09-1.11H3.21A1.1 1.1 0 002.12 7v8.24A1.73 1.73 0 003.83 17H4a2.22 2.22 0 012.2-2.2 2.17 2.17 0 011.54.64A2.23 2.23 0 018.42 17h7.37a2.22 2.22 0 012.2-2.2 2.17 2.17 0 011.54.64 2.22 2.22 0 01.65 1.52 2.39 2.39 0 001.94-2.49 21.2 21.2 0 00-.4-2.12zm-2.65-.09h-2.83a.76.76 0 01-.78-.74v-2.3a.76.76 0 01.78-.74H18a1.07 1.07 0 01.87.52c1.11 2.05 1.1 2.35 1.1 2.45a.84.84 0 01-.9.81z",
    fill: "currentColor"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6.23 15.25a1.71 1.71 0 100 3.42 1.71 1.71 0 100-3.42zm0 2.52A.82.82 0 117 17a.82.82 0 01-.78.77zM18 15.25A1.71 1.71 0 1019.72 17 1.72 1.72 0 0018 15.25zm0 2.52a.82.82 0 11.82-.81.82.82 0 01-.82.81z",
    fill: "currentColor"
  }));
});
var _default = AmTruck;
exports["default"] = _default;