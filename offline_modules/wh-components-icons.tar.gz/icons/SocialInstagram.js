"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var SocialInstagram = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M9 12a3 3 0 113 3 3 3 0 01-3-3m-1.62 0A4.62 4.62 0 1012 7.38 4.62 4.62 0 007.38 12m8.34-4.8a1.08 1.08 0 102.16 0 1.08 1.08 0 10-2.16 0M8.36 19.33A5.12 5.12 0 016.69 19a2.77 2.77 0 01-1-.68 2.77 2.77 0 01-.68-1 5.12 5.12 0 01-.31-1.67v-3.64-3.64A5.12 5.12 0 015 6.69a2.77 2.77 0 01.68-1 2.77 2.77 0 011-.68 5.12 5.12 0 011.67-.31h7.28a5.12 5.12 0 011.68.3 2.77 2.77 0 011 .68 2.77 2.77 0 01.68 1 5.12 5.12 0 01.31 1.67c0 1 .05 1.24.05 3.64s0 2.69-.05 3.64a5.12 5.12 0 01-.3 1.68A3.08 3.08 0 0117.31 19a5.12 5.12 0 01-1.67.31c-1 0-1.24.05-3.64.05s-2.69 0-3.64-.05M8.29 3.05a6.9 6.9 0 00-2.19.42A4.64 4.64 0 003.47 6.1a6.9 6.9 0 00-.42 2.19v7.42a6.9 6.9 0 00.42 2.19 4.64 4.64 0 002.63 2.63 6.9 6.9 0 002.19.47c1 0 1.27.05 3.71.05s2.75 0 3.71-.05a6.9 6.9 0 002.19-.42 4.64 4.64 0 002.63-2.63 6.9 6.9 0 00.47-2.24c0-1 .05-1.27.05-3.71S21 9.25 21 8.29a6.9 6.9 0 00-.42-2.19 4.64 4.64 0 00-2.68-2.63 6.9 6.9 0 00-2.19-.42H8.29",
    fill: "currentColor"
  }));
});
var _default = SocialInstagram;
exports["default"] = _default;