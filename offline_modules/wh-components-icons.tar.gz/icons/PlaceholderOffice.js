"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var PlaceholderOffice = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    viewBox: "0 0 283.46 283.46",
    width: "1em",
    height: "1em",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    "data-name": "icon_placeholder_office-2",
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M75.131 64.49c.355 0 .716.033 1.079.101l81.065 15.2a5.79 5.79 0 014.723 5.691v134.163H75.143a5.79 5.79 0 01-5.79-5.79V70.282c0-3.255 2.656-5.792 5.778-5.792m0-6c-6.495 0-11.778 5.29-11.778 11.792v143.572c0 6.501 5.289 11.79 11.79 11.79h92.855V85.482c0-5.67-4.045-10.544-9.618-11.588l-81.065-15.2a11.883 11.883 0 00-2.184-.204z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M169.02 129.362l40.437 8.287a5.79 5.79 0 014.655 5.678v70.528a5.79 5.79 0 01-5.79 5.79h-39.345l.043-90.283m-5.996-7.353l-.004 7.351-.044 90.283-.003 6.003h45.348c6.501 0 11.79-5.289 11.79-11.79v-70.528c0-5.601-3.986-10.463-9.478-11.561l-40.409-8.281-7.2-1.477zM115.676 92.257a5.79 5.79 0 110 11.58 5.79 5.79 0 010-11.58m0-6c-6.501 0-11.79 5.289-11.79 11.79s5.289 11.79 11.79 11.79 11.79-5.289 11.79-11.79-5.289-11.79-11.79-11.79zM138.337 121.209a.5.5 0 01.5.5v10.581a.5.5 0 01-.5.5h-10.581a.5.5 0 01-.5-.5v-10.581a.5.5 0 01.5-.5h10.581m0-6h-10.581a6.508 6.508 0 00-6.5 6.5v10.581c0 3.584 2.916 6.5 6.5 6.5h10.581c3.584 0 6.5-2.916 6.5-6.5v-10.581c0-3.584-2.916-6.5-6.5-6.5zM103.595 121.209a.5.5 0 01.5.5v10.581a.5.5 0 01-.5.5H93.014a.5.5 0 01-.5-.5v-10.581a.5.5 0 01.5-.5h10.581m0-6H93.014a6.508 6.508 0 00-6.5 6.5v10.581c0 3.584 2.916 6.5 6.5 6.5h10.581c3.584 0 6.5-2.916 6.5-6.5v-10.581c0-3.584-2.916-6.5-6.5-6.5zM138.337 155.951a.5.5 0 01.5.5v10.581a.5.5 0 01-.5.5h-10.581a.5.5 0 01-.5-.5v-10.581a.5.5 0 01.5-.5h10.581m0-6h-10.581a6.508 6.508 0 00-6.5 6.5v10.581c0 3.584 2.916 6.5 6.5 6.5h10.581c3.584 0 6.5-2.916 6.5-6.5v-10.581c0-3.584-2.916-6.5-6.5-6.5zM103.595 190.693a.5.5 0 01.5.5v28.452H92.514v-28.452a.5.5 0 01.5-.5h10.581m0-6H93.014a6.508 6.508 0 00-6.5 6.5v34.452h23.581v-34.452c0-3.584-2.916-6.5-6.5-6.5zM103.595 155.951a.5.5 0 01.5.5v10.581a.5.5 0 01-.5.5H93.014a.5.5 0 01-.5-.5v-10.581a.5.5 0 01.5-.5h10.581m0-6H93.014a6.508 6.508 0 00-6.5 6.5v10.581c0 3.584 2.916 6.5 6.5 6.5h10.581c3.584 0 6.5-2.916 6.5-6.5v-10.581c0-3.584-2.916-6.5-6.5-6.5zM138.337 190.693a.5.5 0 01.5.5v10.581a.5.5 0 01-.5.5h-10.581a.5.5 0 01-.5-.5v-10.581a.5.5 0 01.5-.5h10.581m0-6h-10.581a6.508 6.508 0 00-6.5 6.5v10.581c0 3.584 2.916 6.5 6.5 6.5h10.581c3.584 0 6.5-2.916 6.5-6.5v-10.581c0-3.584-2.916-6.5-6.5-6.5z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M196.241 155.951a.5.5 0 01.5.5v10.581a.5.5 0 01-.5.5H185.66a.5.5 0 01-.5-.5v-10.581a.5.5 0 01.5-.5h10.581m0-6H185.66a6.508 6.508 0 00-6.5 6.5v10.581c0 3.584 2.916 6.5 6.5 6.5h10.581c3.584 0 6.5-2.916 6.5-6.5v-10.581c0-3.584-2.916-6.5-6.5-6.5zM196.241 190.693a.5.5 0 01.5.5v10.581a.5.5 0 01-.5.5H185.66a.5.5 0 01-.5-.5v-10.581a.5.5 0 01.5-.5h10.581m0-6H185.66a6.508 6.508 0 00-6.5 6.5v10.581c0 3.584 2.916 6.5 6.5 6.5h10.581c3.584 0 6.5-2.916 6.5-6.5v-10.581c0-3.584-2.916-6.5-6.5-6.5z"
  })));
});
var _default = PlaceholderOffice;
exports["default"] = _default;