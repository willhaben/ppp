"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Messaging = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M20.21 2.69H8a1.83 1.83 0 00-1.82 1.83v7.64A1.83 1.83 0 008 14h6.5l4.74 4.3V14h.94A1.83 1.83 0 0022 12.16V4.52a1.83 1.83 0 00-1.79-1.83zm-5.61 8.62H9.69a.48.48 0 110-1h4.91a.48.48 0 010 1zm4-2.5H9.68a.48.48 0 110-1h8.87a.48.48 0 010 1zm0-2.49H9.68a.47.47 0 01-.48-.47.48.48 0 01.48-.48h8.87a.48.48 0 01.47.48.47.47 0 01-.47.47zm-4.54 9l2.79 2.53h-8.2l-3.76 3.53v-3.54h-1A1.84 1.84 0 012 16V8.21a1.85 1.85 0 011.88-1.84h1v5.8A3.14 3.14 0 008 15.31z",
    fill: "currentColor"
  }));
});
var _default = Messaging;
exports["default"] = _default;