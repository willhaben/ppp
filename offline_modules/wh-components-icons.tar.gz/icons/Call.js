"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Call = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M15.41 15.45a5.77 5.77 0 00-2.07.66.89.89 0 01-1.18-.42l-1.71-2.51-1.54-2.63a.89.89 0 01.14-1.24s1.28-1 1.48-1.6S9.41 3.7 8.62 3.2c-.54-.35-1.34 0-1.88.31-2.2 1.39-1.56 6.35 1.43 11.1 3 4.74 7.2 7.45 9.4 6.07.54-.35 1.17-.93 1.09-1.57-.11-.91-2.66-3.59-3.25-3.66z",
    fill: "currentColor"
  }));
});
var _default = Call;
exports["default"] = _default;