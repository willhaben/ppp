"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var PlaceholderHoliday = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    viewBox: "0 0 283.46 283.46",
    width: "1em",
    height: "1em",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    "data-name": "icon_placeholder_holiday",
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M90.67 63.5a7.57 7.57 0 017.45 6.27l6.88 39.66 28.94-28a7.57 7.57 0 0111.28.85l.27.36a7.56 7.56 0 01-2.17 11.1l-31.12 18.45 26.73 5.17a6 6 0 014.57 7.69l-.11.34a6 6 0 01-5.7 4.17 5.89 5.89 0 01-2.47-.54l-26.74-12.11 6.58 20.38a4.57 4.57 0 01-3.46 5.9l-.27.05a4.56 4.56 0 01-5.45-4.13L104 115.46l-17.2 16.3a4.57 4.57 0 01-6.82-.59l-.16-.21a4.58 4.58 0 011.38-6.7l18.19-10.5-30.34-6.31a6 6 0 01-4.46-7.76l.11-.33a6 6 0 015.69-4.09 5.94 5.94 0 012.54.57l24.65 11.58-14.3-33.23a7.57 7.57 0 014.8-10.25l.42-.13a7.74 7.74 0 012.17-.31m0-6a13.79 13.79 0 00-3.88.56l-.43.13a13.56 13.56 0 00-8.59 18.37l8 18.7-10.29-4.85a11.82 11.82 0 00-5.09-1.14A12 12 0 0059 97.46l-.11.35a12 12 0 008.93 15.51l14.94 3.11-4.57 2.63A10.59 10.59 0 0075 134.55l.16.21a10.62 10.62 0 008.49 4.24 10.51 10.51 0 007.27-2.9l8.08-7.64.87 11.12a10.63 10.63 0 0010.54 9.75 11 11 0 002.06-.2l.27-.06a10.56 10.56 0 008-13.62l-2.38-7.45 14.38 6.52a12 12 0 0016.37-7.28l.1-.32a12 12 0 00-9.13-15.42l-11.22-2.17 17.53-10.37A13.57 13.57 0 00150.28 79l-.27-.35a13.56 13.56 0 00-20.23-1.53L109 97.25l-5-28.5A13.54 13.54 0 0090.67 57.5zM167.49 146.71a5.87 5.87 0 012.49.56l47.07 19.49a2.91 2.91 0 01-1.25 5.54h-10.46v47.22h-75.69V172.3h-10.47a2.91 2.91 0 01-1.24-5.54L165 147.27a5.87 5.87 0 012.49-.56m0-6a12 12 0 00-4.89 1.06l-47 19.44-.13.06-.14.06a8.91 8.91 0 003.81 17h4.47v47.22h87.69V178.3h4.46a8.91 8.91 0 003.81-17l-.13-.06-.14-.06-47-19.44a11.92 11.92 0 00-4.89-1.06z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M156.75 184.3a.5.5 0 01.5.5v34.61h-11.64V184.8a.5.5 0 01.5-.5h10.64m0-6h-10.64a6.51 6.51 0 00-6.5 6.5v40.61h23.64V184.8a6.51 6.51 0 00-6.5-6.5zM189.37 184.3a.5.5 0 01.5.5v10.65a.5.5 0 01-.5.5h-10.65a.51.51 0 01-.5-.5V184.8a.5.5 0 01.5-.5h10.65m0-6h-10.65a6.51 6.51 0 00-6.5 6.5v10.65a6.51 6.51 0 006.5 6.5h10.65a6.51 6.51 0 006.5-6.5V184.8a6.51 6.51 0 00-6.5-6.5zM98 226.08a3 3 0 01-2.91-2.3 230.75 230.75 0 01-4.9-33.78c-1.87-25.86.64-47.51 7.47-64.34a3 3 0 015.56 2.26c-15.49 38.18-2.48 94-2.35 94.5a3 3 0 01-2.22 3.58 3.34 3.34 0 01-.65.08z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M222.86 226.08H62.47a3 3 0 010-6h160.39a3 3 0 010 6z"
  })));
});
var _default = PlaceholderHoliday;
exports["default"] = _default;