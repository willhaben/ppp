"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var AmMotorbike = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    "data-name": "Vertical Icons",
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M5.86 13.16A2.77 2.77 0 108.63 16a2.8 2.8 0 00-2.77-2.84zm0 4.59a1.84 1.84 0 111.84-1.81 1.85 1.85 0 01-1.85 1.81zM18.31 13.16A2.77 2.77 0 1021.08 16a2.79 2.79 0 00-2.77-2.84zm0 4.59a1.84 1.84 0 111.83-1.81 1.83 1.83 0 01-1.83 1.81z",
    fill: "currentColor"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M18.7 11.58a10.26 10.26 0 00-1.59-2.11 1.4 1.4 0 000-.54 1.1 1.1 0 00-.45-.67.53.53 0 00-.79.23 1.4 1.4 0 00-.57-.17c-.45 0-1.47.28-1.53.88a1.38 1.38 0 00.2.73l.1.11a3.13 3.13 0 00-2.41-.43 3.45 3.45 0 00-2 1.05 1 1 0 01-.29.25c-.67.25-2.11-.69-2.36-1-.35-.45-2.77-.59-3.15-.45l-.36.15V10c0 .41.42.73.71.9a7.67 7.67 0 002.07 1.45 3.48 3.48 0 011.13.32 2.08 2.08 0 01.38.21l.09.05.14.12a3.68 3.68 0 01.38.31 3.61 3.61 0 011 2.57 3.36 3.36 0 01-.35 1.48l.12.06a19.31 19.31 0 002 .06c1.18 0 2.52 0 3.07-.08h.52l-.14-.51a3.85 3.85 0 01-.14-1 3.76 3.76 0 01.6-2 3.2 3.2 0 01.94-1 3.71 3.71 0 012.18-.73h.58z",
    fill: "currentColor"
  }));
});
var _default = AmMotorbike;
exports["default"] = _default;