"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var CatDealeroffer = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M20.09 2H3.91A1.9 1.9 0 002 3.91v16.18A1.9 1.9 0 003.91 22h16.18A1.9 1.9 0 0022 20.09V3.91A1.9 1.9 0 0020.09 2zm1.17 18.09a1.17 1.17 0 01-1.17 1.17H3.91a1.17 1.17 0 01-1.17-1.17V3.91a1.17 1.17 0 011.17-1.17h16.18a1.17 1.17 0 011.17 1.17zm-1.85-8.86v1.54a.51.51 0 01-.51.51H5.1a.51.51 0 01-.51-.51v-1.54a.51.51 0 01.51-.51h13.8a.51.51 0 01.51.51zm0 5.12v1.53a.51.51 0 01-.51.51H5.1a.51.51 0 01-.51-.51v-1.53a.51.51 0 01.51-.52h13.8a.51.51 0 01.51.52zm0-10.23v1.53a.51.51 0 01-.51.52H5.1a.51.51 0 01-.51-.52V6.12a.51.51 0 01.51-.51h13.8a.51.51 0 01.51.51z",
    fill: "#00a4e8",
    "data-name": "Marktplatz Kategorien"
  }));
});
var _default = CatDealeroffer;
exports["default"] = _default;