"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Topanzeige = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12.09 3a9 9 0 109 9 9 9 0 00-9-9zm5.78 8.24l-6.54 6.54a1.77 1.77 0 01-2.52 0l-2.52-2.52a1.77 1.77 0 010-2.52l6.54-6.54a1.77 1.77 0 012.52 0l2.52 2.52a1.77 1.77 0 010 2.52z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M9 13.49l2.29 2.29-.83.85-2.28-2.31-.64.68-.72-.72 2.12-2.12.72.72zM13.44 13.78a1.88 1.88 0 01-2.93-.11 2.14 2.14 0 01-.08-3.13 1.86 1.86 0 012.92.11 2.14 2.14 0 01.09 3.13zm-2.32-2.43c-.29.29-.36.81.2 1.37s1 .67 1.38.25c.25-.25.43-.79-.21-1.42s-.98-.55-1.37-.2zM15.24 10l-.13.13.92.92-.83.82-3-3 .88-.87c.81-.81 1.58-.9 2.25-.23a1.5 1.5 0 01-.09 2.23zm-1.48-1.38l-.07.09.74.73a.13.13 0 00.07 0 .53.53 0 000-.79.48.48 0 00-.74-.03z"
  })));
});
var _default = Topanzeige;
exports["default"] = _default;