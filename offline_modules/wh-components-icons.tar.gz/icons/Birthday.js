"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Birthday = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M4 13.58c.06-.52.12-1 .17-1.56a1.84 1.84 0 011.57-1.75 4.87 4.87 0 01.54 0h11.58c1.46 0 2.12.66 2.15 2.25a24.87 24.87 0 01-.11 3.11c-.1 1-.45 1.07-1.13.42-.35-.34-.67-.72-1-1.05-.63-.59-1.05-.58-1.68 0-.36.35-.68.74-1.05 1.08-.57.53-.91.53-1.47 0-.27-.24-.51-.51-.76-.78-.95-1-1.35-1-2.31 0-.25.27-.49.54-.75.79-.55.5-.89.51-1.44 0-.36-.33-.68-.71-1-1.05-.69-.67-1.12-.66-1.81 0a6.3 6.3 0 00-.58.68c-.25.33-.44.33-.58-.07A9 9 0 014 14.47z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M7.27 22a2.35 2.35 0 01-1.4-2.2c-.07-1-.27-2.08-.44-3.12-.06-.32-.06-.57.22-.77s.63-.51 1-.26a6.06 6.06 0 01.79.65c.32.3.61.64.94.93a.84.84 0 001.2 0c.39-.34.74-.73 1.1-1.1.77-.77 1.11-.77 1.89 0 .29.3.57.63.88.92a1 1 0 001.6 0c.37-.34.7-.73 1.06-1.07.61-.59 1-.6 1.58 0 .29.28.57.58.84.89a.63.63 0 01.11.43c-.14 1.08-.28 2.15-.48 3.22A2 2 0 0116.85 22zM9 9.52H7.47V5.6H9zM9 4.19a.78.78 0 01-.79.81.78.78 0 01-.74-.82A12 12 0 018.21 2 12 12 0 019 4.19zM12.78 9.52H11.3V5.6h1.48zM12.78 4.19a.74.74 0 11-1.48 0A12 12 0 0112 2a12 12 0 01.78 2.19zM16.71 9.52h-1.48V5.6h1.48zM16.71 4.19a.74.74 0 11-1.48 0A12 12 0 0116 2a12 12 0 01.71 2.19z"
  })));
});
var _default = Birthday;
exports["default"] = _default;