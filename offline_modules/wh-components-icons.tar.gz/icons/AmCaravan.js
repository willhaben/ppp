"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var AmCaravan = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    "data-name": "Vertical Icons",
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22 14.47a1.48 1.48 0 00-.28-.28 2.93 2.93 0 00-.26-1.27 2 2 0 00-.76-.55 3.39 3.39 0 01-.61-.38c-.24-.2-1-.94-1.5-1.48a.2.2 0 010-.24A1.67 1.67 0 0018.84 9a3.08 3.08 0 00-1.62-1.87c-2.54-1.5-6.59-.48-7.17-.32H9c0-.55-.06-.65-.13-.74s-.3-.41-2.16-.31c-.69 0-.93.12-1.07.36 0 .08-.1.18-.09.69H3.21a1 1 0 00-1.08 1.02v8c0 .66 1.11.93 1.93 1.05a2.2 2.2 0 012.19-2.13 2.19 2.19 0 012.19 2.2H16a2.12 2.12 0 01.64-1.54 2.15 2.15 0 011.55-.66 2.17 2.17 0 011.54.64 2.23 2.23 0 01.65 1.56h.36a1.28 1.28 0 001.17-.73 2.06 2.06 0 00.09-1.75zM8 11.4a1 1 0 01-.95.95H5.36a1 1 0 01-1-.95v-.47a1 1 0 011-.95h1.72a1 1 0 01.95.95zm5.14 5.12l-3.63-.05V11a1 1 0 011-1h1.72a1 1 0 01.95 1zm3.67-4.17h-1.69a1 1 0 01-.95-.95v-.47a.94.94 0 01.95-.95c.5-.13 2.69.84 2.68 1.42s-.43.95-.96.95z",
    fill: "currentColor"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M6.25 15.21a1.73 1.73 0 00-1.72 1.73 1.72 1.72 0 101.72-1.73zm0 2.53a.82.82 0 010-1.64.81.81 0 01.81.83.82.82 0 01-.81.81zM18.16 15.21a1.73 1.73 0 00-1.72 1.73 1.72 1.72 0 003.44 0 1.73 1.73 0 00-1.72-1.73zm0 2.53a.82.82 0 110-1.64.82.82 0 110 1.64z",
    fill: "currentColor"
  }));
});
var _default = AmCaravan;
exports["default"] = _default;