"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var PlaceholderTruck = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    viewBox: "0 0 283.46 283.46",
    width: "1em",
    height: "1em",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    "data-name": "icon_placeholder_truck",
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M216.74 186.91h-15.47v-6h15.4A15.23 15.23 0 00230.85 165c-.21-1.44-1.88-12.81-3.59-19.1a181.52 181.52 0 00-13-33.56l-4.65-9.24-.09-.18a3 3 0 00-2.71-1.86h-35.72a3.05 3.05 0 00-3 3.13v39.56a8.66 8.66 0 01-8.64 8.64h-2.73a8.68 8.68 0 01-8.67-8.68V91.92a3.06 3.06 0 00-3-3.14H55.58a3.06 3.06 0 00-3 3.14v79.72a9.12 9.12 0 008.93 9.27h15.97v6H61.54a15.12 15.12 0 01-14.93-15.27V91.92a9.06 9.06 0 019-9.14h89.53a9.06 9.06 0 019 9.14v51.78a2.68 2.68 0 002.67 2.68h2.73a2.64 2.64 0 002.64-2.64v-39.56a9.06 9.06 0 019-9.13h35.76a9 9 0 018.2 5.43l4.61 9.16A186.71 186.71 0 01233 144.31c1.93 7.05 3.7 19.47 3.77 20v.3c.49 11.78-8.47 21.79-20 22.31z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M104.14 180.91h70.6v6h-70.6zM208.73 141.38h-27.14a5.76 5.76 0 01-5.93-5.56v-22.25a5.76 5.76 0 015.93-5.56c2.48 0 15-.08 16.35 0 1.88.12 5.49 1.14 7.17 4.23 3.17 5.81 10.52 19.68 10.44 22.84-.09 3.53-2.73 6-6.71 6.3zm-27.07-6h26.83a2.12 2.12 0 001-.3c-.51-2.28-5.94-13.06-9.7-20a3.26 3.26 0 00-2.27-1.11h-15.91z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M90.49 200.68a16.59 16.59 0 1116.59-16.59 16.61 16.61 0 01-16.59 16.59zm0-27.18a10.59 10.59 0 1010.59 10.59 10.6 10.6 0 00-10.59-10.59zM188 200.68a16.59 16.59 0 1116.59-16.59A16.61 16.61 0 01188 200.68zm0-27.18a10.59 10.59 0 1010.59 10.59A10.6 10.6 0 00188 173.5z"
  })));
});
var _default = PlaceholderTruck;
exports["default"] = _default;