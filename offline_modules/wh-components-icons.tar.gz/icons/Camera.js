"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Camera = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22 18.49V6.6a1.27 1.27 0 00-1.27-1.27h-5s0-1.83-1.09-1.83h-5c-1.08 0-1.1 1.83-1.1 1.83H3.29A1.27 1.27 0 002 6.6v11.9a1.27 1.27 0 001.27 1.27h17.5A1.52 1.52 0 0022 18.49zM6.26 12.4a5.8 5.8 0 115.8 5.8 5.8 5.8 0 01-5.8-5.8z",
    fill: "currentColor"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12.06 8.1a4.31 4.31 0 104.3 4.31 4.32 4.32 0 00-4.3-4.31z",
    fill: "currentColor"
  }));
});
var _default = Camera;
exports["default"] = _default;