"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var PlaceholderCar = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    viewBox: "0 0 283.46 283.46",
    width: "1em",
    height: "1em",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    "data-name": "icon_placeholder_car",
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("g", {
    "data-name": "6oty5B.tif"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M98.314 187.508l.142-5.998 78.748 1.856-.141 5.998z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M218.77 190.18c-2.69 0-4.64-.13-4.69-.13l.45-6c3.27.24 12.61.23 15.29-1.24a4.49 4.49 0 002.57-4.49c0-1.82 0-3.64.06-5.41a63.21 63.21 0 00-.21-9.49c-.49-4-1.05-7.27-3.33-9.56-.13-.13-.41-.43-.79-.85-4-4.32-6.65-6.84-8-7.5-3.89-1.88-14.4-4.79-28.83-8h-.21c-3.35-.74-5.63-2.8-7.64-4.61-.64-.57-1.24-1.11-1.84-1.59a106.06 106.06 0 00-23.6-14.43c-7.67-3.31-14.05-5.13-20.08-5.73-5.46-.54-39.72 1.56-50.75 3.68-4.21.8-8.37 1.47-12.6 2.14-3 2.07-16.87 16.75-19 19.75-.65 2.84-1.06 5.06-1.34 7.17-.45 3.57-2.42 15.89-3.28 19.48v5.43c.12.45.25.9.37 1.34.33 1.25.65 2.43 1 3.56a9.34 9.34 0 007.83 6.24l-.82 5.94a15.35 15.35 0 01-12.67-10.2c-.47-1.33-.83-2.67-1.19-4l-.41-1.68-.12-.4v-7l.1-.38c.66-2.41 2.75-15.33 3.23-19.09a83 83 0 011.55-8.2c.16-.67.45-1.92 10.55-12.53 10.39-10.89 11.72-11.1 12.8-11.27 4.34-.69 8.59-1.37 12.86-2.19 10.9-2.09 46-4.39 52.47-3.75 6.66.66 13.61 2.63 21.87 6.19a111.85 111.85 0 0124.94 15.23c.76.6 1.46 1.23 2.14 1.84 1.67 1.51 3.12 2.81 4.92 3.21h.21c8.74 1.93 24.28 5.6 30.15 8.44 2.71 1.32 6.48 5.21 9.81 8.84l.62.67c3.92 3.93 4.57 9.21 5 13.07a69.44 69.44 0 01.25 10.37c0 1.71-.09 3.47-.06 5.17a10.43 10.43 0 01-5.68 9.83c-3.15 1.79-9.5 2.13-13.9 2.13zM55.41 136.94z"
  })), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M195.94 202.4a22.39 22.39 0 01-22.29-22.08 21.93 21.93 0 016.47-15.67A22.2 22.2 0 01195.9 158a22 22 0 0115.69 6.53 22.37 22.37 0 016.55 16 22.14 22.14 0 01-22.2 21.87zm0-6a16.16 16.16 0 0011.41-27.66 16.09 16.09 0 00-11.44-4.74 16.24 16.24 0 00-11.55 4.91 15.89 15.89 0 00-4.73 11.39 16.37 16.37 0 0016.3 16.13zM79.21 202.4a22.39 22.39 0 01-22.29-22.08 21.88 21.88 0 016.47-15.67A22.2 22.2 0 0179.17 158a22 22 0 0115.69 6.53 22.41 22.41 0 016.55 16 22.14 22.14 0 01-22.2 21.87zm0-6a16.16 16.16 0 0011.41-27.66A16.09 16.09 0 0079.18 164a16.24 16.24 0 00-11.55 4.91 15.91 15.91 0 00-4.73 11.39 16.37 16.37 0 0016.3 16.13zM167.81 142.83L66.3 141.55a2.54 2.54 0 01-1.75-4.36l14.06-13.81a2.53 2.53 0 01.83-.54c8-3.2 51-5.58 59-4.77 7.79.78 32.88 9 36.85 18.13a2.55 2.55 0 01-1 3.2l-5.12 3.07a2.58 2.58 0 01-1.36.36zm-95.33-6.29l94.64 1.19 2.18-1.31c-2.26-2.36-6.92-5.13-13.12-7.76-7.43-3.15-15-5.2-18.27-5.53-7.23-.72-47.92 1.53-56.13 4.27z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M110 141.55a2.54 2.54 0 01-2.48-2.61l.42-16.7a2.55 2.55 0 012.55-2.48h.06a2.54 2.54 0 012.48 2.61l-.42 16.7a2.55 2.55 0 01-2.61 2.48zM151.2 142.32a2.55 2.55 0 01-2.07-1.06l-13-18.15a2.55 2.55 0 114.14-3l13 18.15a2.55 2.55 0 01-2.07 4z"
  })));
});
var _default = PlaceholderCar;
exports["default"] = _default;