"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var PaymentCreditcard = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M20.37 5H3.63A1.63 1.63 0 002 6.66V17.4a1.63 1.63 0 001.63 1.65h16.74A1.64 1.64 0 0022 17.4V6.66A1.63 1.63 0 0020.37 5zm-16.74.9h16.74a.74.74 0 01.72.75v1.44H2.9V6.66a.75.75 0 01.73-.75zm16.74 12.25H3.63a.75.75 0 01-.73-.75V11h18.21v6.4a.77.77 0 01-.74.75z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M5.88 14.87H5a.8.8 0 00-.81.8.81.81 0 00.81.81h.88a.82.82 0 00.81-.81.81.81 0 00-.81-.8zM12.74 14.87H9.06a.8.8 0 00-.8.8.81.81 0 00.8.81h3.68a.81.81 0 00.81-.81.8.8 0 00-.81-.8z"
  })));
});
var _default = PaymentCreditcard;
exports["default"] = _default;