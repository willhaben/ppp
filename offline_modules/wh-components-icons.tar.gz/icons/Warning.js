"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Warning = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 5.19l8.58 14H3.42l8.58-14m0-1.53a.65.65 0 00-.56.33L2.1 19.24a.71.71 0 00.57 1.09h18.65a.71.71 0 00.57-1.09L12.56 4a.66.66 0 00-.56-.34z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12.21 14.43h-.35a.8.8 0 01-.79-.74l-.2-3.69a.79.79 0 01.79-.83h.75a.79.79 0 01.79.83l-.2 3.69a.8.8 0 01-.79.74zm-1.36 2a1 1 0 01.3-.79 1.24 1.24 0 01.88-.28 1.17 1.17 0 01.86.28 1 1 0 01.3.79 1 1 0 01-.31.78 1.2 1.2 0 01-.85.29 1.25 1.25 0 01-.87-.29 1 1 0 01-.31-.82z"
  })));
});
var _default = Warning;
exports["default"] = _default;