"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Print = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.89 9.78a1.13 1.13 0 10-2.25 0 1.13 1.13 0 002.25 0zm-3.38 3.37h-9v6.75h9zM21 8.65v6.75a1.11 1.11 0 01-1.12 1.13h-2.24v3.37a1.12 1.12 0 01-1.13 1.1h-9a1.11 1.11 0 01-1.12-1.1v-3.37H4.14A1.12 1.12 0 013 15.4V8.65a1.11 1.11 0 011.14-1.12h15.75A1.11 1.11 0 0121 8.65zM17.64 6.4H6.39V4.15A1.11 1.11 0 017.51 3h9a1.11 1.11 0 011.13 1.12z",
    fill: "currentColor",
    fillRule: "evenodd"
  }));
});
var _default = Print;
exports["default"] = _default;