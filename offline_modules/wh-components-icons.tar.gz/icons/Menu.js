"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Menu = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    viewBox: "0 0 100 100",
    width: "1em",
    height: "1em",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M10.2 27.6c0-2.9 2.4-5.3 5.3-5.3h68.9c2.9 0 5.3 2.4 5.3 5.3s-2.4 5.3-5.3 5.3H15.5c-2.9 0-5.3-2.4-5.3-5.3zm74.3 17h-69c-2.9 0-5.3 2.4-5.3 5.3 0 3 2.4 5.4 5.3 5.4h68.9c2.9 0 5.3-2.4 5.3-5.4.1-2.8-2.3-5.3-5.2-5.3zm0 22.5h-69c-2.9 0-5.3 2.4-5.3 5.3s2.4 5.3 5.3 5.3h68.9c2.9 0 5.3-2.4 5.3-5.3s-2.3-5.3-5.2-5.3z"
  }));
});
var _default = Menu;
exports["default"] = _default;