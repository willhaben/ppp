"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Minus = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M20 13a1 1 0 000-2H4a1 1 0 000 2z",
    fill: "currentColor"
  }));
});
var _default = Minus;
exports["default"] = _default;