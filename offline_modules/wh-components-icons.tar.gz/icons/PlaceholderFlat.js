"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var PlaceholderFlat = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    viewBox: "0 0 283.46 283.46",
    width: "1em",
    height: "1em",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    "data-name": "icon_placeholder_flat",
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M221.49 225.46a3 3 0 01-3-3V74.82a8.76 8.76 0 00-8.75-8.76H73.68a8.77 8.77 0 00-8.75 8.76v147.49a3 3 0 01-6 0V74.82a14.77 14.77 0 0114.75-14.76h136.06a14.77 14.77 0 0114.75 14.76v147.64a3 3 0 01-3 3z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M186.69 185.22h-6V171.9a9.65 9.65 0 00-9.64-9.64h-69.83a9.65 9.65 0 00-9.64 9.64v13.32h-6V171.9a15.66 15.66 0 0115.64-15.64h69.83a15.66 15.66 0 0115.64 15.64z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M186.85 225.46h-6.32a9.33 9.33 0 01-8.82-6.32h-71.14a9.35 9.35 0 01-8.83 6.32h-6.32a9.34 9.34 0 01-9.32-9.32v-25.28a9.33 9.33 0 019.32-9.32h6.32a9.33 9.33 0 019.32 9.32v4.32a3.32 3.32 0 003.32 3.32h63.51a3.32 3.32 0 003.32-3.32v-4.32a9.33 9.33 0 019.32-9.32h6.32a9.33 9.33 0 019.32 9.32v25.28a9.34 9.34 0 01-9.32 9.32zm-88.79-12.32h76.15a3 3 0 013 3 3.32 3.32 0 003.32 3.32h6.32a3.32 3.32 0 003.32-3.32v-25.28a3.32 3.32 0 00-3.32-3.32h-6.32a3.32 3.32 0 00-3.32 3.32v4.32a9.33 9.33 0 01-9.32 9.32h-63.51a9.33 9.33 0 01-9.32-9.32v-4.32a3.32 3.32 0 00-3.32-3.32h-6.32a3.32 3.32 0 00-3.32 3.32v25.28a3.32 3.32 0 003.32 3.32h6.32a3.32 3.32 0 003.32-3.32 3 3 0 013-3zM196.93 136.66h-40.82a8.68 8.68 0 01-8.67-8.67V87.17a8.68 8.68 0 018.67-8.67h40.82a8.68 8.68 0 018.67 8.67V128a8.71 8.71 0 01-8.67 8.67zM156.11 84.5a2.68 2.68 0 00-2.67 2.67V128a2.68 2.68 0 002.67 2.67h40.82a2.7 2.7 0 002.67-2.67V87.17a2.68 2.68 0 00-2.67-2.67z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M173.52 81.25h6v52.67h-6z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M150.18 104.58h52.67v6h-52.67z"
  })));
});
var _default = PlaceholderFlat;
exports["default"] = _default;