"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Transactions = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 3a9 9 0 109 9 9 9 0 00-9-9zm2.12 13.77a4.52 4.52 0 01-4-.65 4.36 4.36 0 01-1.36-1.65l-.93.27-.3-1 .8-.22-.07-.24c0-.15-.07-.3-.1-.44l-.84.16L7 12l1-.28a4.66 4.66 0 01.44-2.27A4.53 4.53 0 0111.37 7a5.79 5.79 0 012.3-.18l.07 1.78a4.17 4.17 0 00-1.74.1 2.32 2.32 0 00-1.54 1.3 2.38 2.38 0 00-.19 1.07l3.61-1 .3 1-3.84 1.09c0 .14.07.3.11.45l.07.23 3.85-1.1.29 1-3.65 1a2.39 2.39 0 00.78.89 2.54 2.54 0 002.08.2 4.22 4.22 0 001.55-.85l.8 1.51a5 5 0 01-2.1 1.28z",
    fill: "currentColor"
  }));
});
var _default = Transactions;
exports["default"] = _default;