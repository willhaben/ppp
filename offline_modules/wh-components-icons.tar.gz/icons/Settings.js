"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Settings = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M11.86 15.67a3.5 3.5 0 113.5-3.5 3.5 3.5 0 01-3.5 3.5zm7.43-2.52a7.79 7.79 0 00.07-1 7.79 7.79 0 00-.07-1l2.11-1.61a.5.5 0 00.12-.64l-2-3.46a.5.5 0 00-.61-.22l-2.49 1a7.31 7.31 0 00-1.69-1l-.38-2.65a.49.49 0 00-.49-.42h-4a.49.49 0 00-.49.42L9 5.24a7.68 7.68 0 00-1.69 1l-2.49-1a.49.49 0 00-.61.22L2.2 8.9a.49.49 0 00.12.64l2.11 1.65a7.93 7.93 0 00-.07 1 7.93 7.93 0 00.07 1L2.32 14.8a.5.5 0 00-.12.64l2 3.46a.5.5 0 00.61.22l2.49-1a7.31 7.31 0 001.7.98l.38 2.65a.49.49 0 00.49.42h4a.49.49 0 00.49-.42l.38-2.65a7.68 7.68 0 001.69-1l2.49 1a.49.49 0 00.61-.22l2-3.46a.5.5 0 00-.12-.64z",
    fill: "currentColor",
    fillRule: "evenodd"
  }));
});
var _default = Settings;
exports["default"] = _default;