"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var PlaceholderGarage = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    viewBox: "0 0 283.46 283.46",
    width: "1em",
    height: "1em",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    "data-name": "icon_placeholder_garage",
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M141.73 84.52a11.71 11.71 0 012.7.31l70.7 16.68a6.11 6.11 0 014.66 6v105.82a6.07 6.07 0 01-6 6.13H69.68a6.07 6.07 0 01-6-6.13V107.49a6.11 6.11 0 014.66-6L139 84.83a11.78 11.78 0 012.7-.31m0-6a18.11 18.11 0 00-4.08.47L67 95.67a12.06 12.06 0 00-9.27 11.82v105.83a12.08 12.08 0 0012 12.14h144.06a12.08 12.08 0 0012-12.14V107.49a12.07 12.07 0 00-9.28-11.82L145.81 79a18 18 0 00-4.08-.47z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M194.77 135.4a1 1 0 011 1v83.06H87.69V136.4a1 1 0 011-1h106.08m0-6H88.69a7 7 0 00-7 7v89.06h120.08V136.4a7 7 0 00-7-7z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M84.55 147.45h113.21v6H84.55zM84.55 165.45h113.21v6H84.55zM84.55 183.45h113.21v6H84.55zM84.55 201.45h113.21v6H84.55z"
  })));
});
var _default = PlaceholderGarage;
exports["default"] = _default;