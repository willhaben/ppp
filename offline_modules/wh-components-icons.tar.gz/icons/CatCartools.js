"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var CatCartools = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M15.83 4.49A8.43 8.43 0 004 14.61 8.41 8.41 0 0014.61 20a8.43 8.43 0 001.22-15.51zm.2 13.7a31.41 31.41 0 01-2.8-4.06l.53-.38a26.74 26.74 0 013 3.88 2.68 2.68 0 01-.76.56zm-8 0a2.56 2.56 0 01-.76-.54 31.75 31.75 0 013-3.92l.52.39A25.87 25.87 0 018 18.21zm-3-9a32.59 32.59 0 014.67 1.62l-.21.62a26 26 0 01-4.72-1.37A2.55 2.55 0 015 9.17zm6.19 4.29l-.12-.07-.2-.14a1.65 1.65 0 01-.41-2 1.68 1.68 0 011-.84 1.88 1.88 0 01.52-.08 1.7 1.7 0 01.76.18 1.68 1.68 0 01-.24 3.09 1.67 1.67 0 01-1.3-.16zm1.09-4h-.65a27.69 27.69 0 01-.16-5 2.64 2.64 0 01.93 0 34.54 34.54 0 01-.11 5zm2 1.32a27 27 0 014.63-1.67 2.53 2.53 0 01.3.89 32.94 32.94 0 01-4.73 1.4zm4.41-2.43a14.84 14.84 0 00-2.35.72 18.38 18.38 0 00-2.65 1.15 2.37 2.37 0 00-.61-.44 24.39 24.39 0 00.21-3 19.34 19.34 0 000-2.29 7.72 7.72 0 012.22.73 7.54 7.54 0 013.17 3.13zM9.64 4.74a9.81 9.81 0 011.07-.26 15.77 15.77 0 000 2.47 20.65 20.65 0 00.24 2.83 2.64 2.64 0 00-.64.45 21.64 21.64 0 00-2.87-1.15 18 18 0 00-2.17-.67 7.6 7.6 0 014.37-3.67zm-4.9 9.62a7.62 7.62 0 01-.28-3.57 14.79 14.79 0 002.37.81 18.72 18.72 0 002.74.63 2.84 2.84 0 00.1.49 2.17 2.17 0 00.15.35 24.26 24.26 0 00-1.91 2.29 16.93 16.93 0 00-1.37 2 7.66 7.66 0 01-1.8-3zm9.62 4.9a7.6 7.6 0 01-5.82-.46 13.33 13.33 0 001.58-2.07 21.59 21.59 0 001.43-2.37 2.12 2.12 0 00.44 0 2.56 2.56 0 00.47 0 24.37 24.37 0 001.54 2.5 14.59 14.59 0 001.47 1.92 8.1 8.1 0 01-1.11.48zm4.44-3.8a7.4 7.4 0 01-1.31 1.84A13.54 13.54 0 0016 15.18a18.65 18.65 0 00-1.84-2.12 2.47 2.47 0 00.24-.83 22.41 22.41 0 002.94-.73 18.67 18.67 0 002.18-.75 7.56 7.56 0 01-.72 4.71zm2.71-6.55a10 10 0 10-6.42 12.6 10 10 0 006.42-12.6zm-6.68 11.81a9.17 9.17 0 115.89-11.55 9.18 9.18 0 01-5.89 11.55z",
    fill: "#00a4e8",
    "data-name": "Marktplatz Kategorien"
  }));
});
var _default = CatCartools;
exports["default"] = _default;