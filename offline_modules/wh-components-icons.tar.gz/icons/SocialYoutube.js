"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var SocialYoutube = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M10 15V9l5 3zm11.79-7A4.35 4.35 0 0021 6a2.87 2.87 0 00-2-.84C16.2 5 12 5 12 5s-4.2 0-7 .2A2.92 2.92 0 003 6a4.42 4.42 0 00-.8 2 30.24 30.24 0 00-.2 3.25v1.5A29.94 29.94 0 002.2 16a4.35 4.35 0 00.8 2 3.39 3.39 0 002.2.85C6.8 19 12 19 12 19s4.2 0 7-.21a2.9 2.9 0 002-.79 4.35 4.35 0 00.8-2 29.94 29.94 0 00.2-3.22v-1.5A31.86 31.86 0 0021.79 8z",
    fill: "currentColor"
  }));
});
var _default = SocialYoutube;
exports["default"] = _default;