"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var SocialLinkedin = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.37 3H4.63A1.63 1.63 0 003 4.63v14.74A1.63 1.63 0 004.63 21h14.74A1.63 1.63 0 0021 19.37V4.63A1.63 1.63 0 0019.37 3zM8.57 18.54a.48.48 0 01-.47.46h-2a.48.48 0 01-.47-.48v-8.43a.48.48 0 01.47-.48h2a.48.48 0 01.47.48zM7.09 8.82A1.92 1.92 0 119 6.9a1.92 1.92 0 01-1.91 1.92zm12 9.76a.44.44 0 01-.43.44h-2.15a.44.44 0 01-.43-.44v-4c0-.59.17-2.59-1.55-2.59-1.33 0-1.61 1.37-1.66 2v4.57a.44.44 0 01-.44.44h-2.09a.44.44 0 01-.43-.44v-8.51a.44.44 0 01.43-.44h2.09a.44.44 0 01.44.44v.74a3 3 0 012.79-1.32c3.47 0 3.45 3.24 3.45 5v4.09z",
    fill: "currentColor"
  }));
});
var _default = SocialLinkedin;
exports["default"] = _default;