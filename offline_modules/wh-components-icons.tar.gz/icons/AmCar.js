"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var AmCar = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    "data-name": "Vertical Icons",
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22 15a2 2 0 00-.44-1.2 5.83 5.83 0 00-1-1 23.61 23.61 0 00-3.17-.88 2.2 2.2 0 01-.88-.6 11.82 11.82 0 00-2.59-1.58 7.36 7.36 0 00-2.23-.63c-.69-.11-5.78.16-6.92.62A11.19 11.19 0 002.55 12a6.07 6.07 0 00-.16.85c-.06.41-.28 1.79-.36 2.07v.67c.06.19.11.39.17.58a1.32 1.32 0 001 .85v-.15-.1a.51.51 0 010-.13 1.66 1.66 0 010-.32 1.49 1.49 0 01.09-.3v-.11a2.26 2.26 0 012.14-1.44 2.29 2.29 0 011.62.67 2.65 2.65 0 01.21.26.71.71 0 01.07.09 1.65 1.65 0 01.2.37 2.41 2.41 0 01.19.93 2.45 2.45 0 010 .38l7.89.21a2.12 2.12 0 01-.1-.62 2.3 2.3 0 014.6 0 2.26 2.26 0 01-.13.74 4.29 4.29 0 001.58-.18.79.79 0 00.44-.76A14.74 14.74 0 0022 15zM4.12 12.42a10.1 10.1 0 011.52-1.77 22.26 22.26 0 013.55-.37l.18 2.21zm10.72.1h-5l-.18-2.24c.93 0 1.73-.06 2 0 .81.08 3.31 1.16 3.66 2a.75.75 0 01-.48.24z",
    fill: "currentColor"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M17.83 15a1.8 1.8 0 100 3.6 1.8 1.8 0 100-3.6zm0 2.65a.86.86 0 11.86-.85.87.87 0 01-.86.83zM5.48 15a1.8 1.8 0 100 3.6 1.8 1.8 0 100-3.6zm0 2.65a.86.86 0 110-1.72.86.86 0 110 1.72z",
    fill: "currentColor"
  }));
});
var _default = AmCar;
exports["default"] = _default;