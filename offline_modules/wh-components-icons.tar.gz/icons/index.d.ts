export declare const system: () => {
    foo: string;
};
export interface FooProps {
    foobar: string;
}
