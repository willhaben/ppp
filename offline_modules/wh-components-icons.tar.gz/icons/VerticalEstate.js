"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var VerticalEstate = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    viewBox: "0 0 100 100",
    width: "1em",
    height: "1em",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M84.1 44.1L77 37.4c0-.1.1-.2.1-.3V24.4c0-1.5-1.2-2.7-2.7-2.7H68c-1.5 0-2.7 1.2-2.7 2.7v1.8L51.9 13.5c-1.1-1.1-2.8-1.1-4 0l-32 30.4c-.9.9-1.2 2.3-.7 3.6.5 1.2 1.5 2 2.8 2h.6v33.2c0 2.5 2.1 4.6 4.6 4.6h53.5c2.5 0 4.5-2 4.5-4.5V49.5h.9c1.2 0 2.2-.7 2.6-1.9.6-1.3.3-2.6-.6-3.5zM67 27.3v-2.9c0-.5.4-1 1-1h6.4c.5 0 1 .4 1 1v11.4l-8.5-8.1c.1-.1.1-.2.1-.4zm4.3 58.4H55V61.8c0-.9.7-1.6 1.6-1.6h13c.9 0 1.6.7 1.6 1.6v23.9zM83.2 47c-.1.2-.4.8-1 .8h-1.8c-.5 0-.9.4-.9.9v34.2c0 1.5-1.2 2.8-2.8 2.8H73V61.8c0-1.8-1.5-3.3-3.3-3.3h-13c-1.8 0-3.3 1.5-3.3 3.3v23.9H23.2c-1.6 0-2.9-1.3-2.9-2.9V48.7c0-.5-.4-.9-.9-.9H18c-.7 0-1.1-.7-1.2-.9-.2-.5-.2-1.3.3-1.8l32-30.4c.3-.2.5-.4.8-.4.3 0 .5.1.8.4L83 45.4c.4.4.4 1.1.2 1.6zM49.9 31.7c-4.6 0-8.3 3.7-8.3 8.3s3.7 8.3 8.3 8.3c4.6 0 8.3-3.7 8.3-8.3s-3.7-8.3-8.3-8.3zm0 14.9c-3.6 0-6.6-3-6.6-6.6 0-3.6 3-6.6 6.6-6.6s6.6 3 6.6 6.6c0 3.7-3 6.6-6.6 6.6zm-5.2 11.8H29.5c-1.8 0-3.3 1.5-3.3 3.3v10.7c0 1.8 1.5 3.3 3.3 3.3h15.2c1.8 0 3.3-1.5 3.3-3.3V61.7c0-1.8-1.5-3.3-3.3-3.3zm1.6 14.1c0 .9-.7 1.6-1.6 1.6H29.5c-.9 0-1.6-.7-1.6-1.6V61.7c0-.9.7-1.6 1.6-1.6h15.2c.9 0 1.6.7 1.6 1.6v10.8z",
    fill: "currentColor"
  }));
});
var _default = VerticalEstate;
exports["default"] = _default;