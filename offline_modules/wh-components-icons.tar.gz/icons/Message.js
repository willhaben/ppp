"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Message = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.8 3.65H4.21A2.21 2.21 0 002 5.86V15a2.22 2.22 0 002.2 2.21h9.66l4.77 4.24v-4.24h1.17A2.22 2.22 0 0022 15V5.86a2.22 2.22 0 00-2.2-2.21zM13.05 14H6.21a.57.57 0 110-1.14h6.84a.57.57 0 110 1.14zm4.75-3H6.21a.57.57 0 01-.57-.57.58.58 0 01.57-.57H17.8a.58.58 0 01.57.57.57.57 0 01-.57.57zm0-3H6.21a.58.58 0 010-1.15H17.8a.58.58 0 010 1.15z",
    fill: "currentColor"
  }));
});
var _default = Message;
exports["default"] = _default;