"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Logout = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    fill: "currentColor",
    fillRule: "evenodd"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M18.43 16.66a.7.7 0 00-.73.66v2.54a.84.84 0 01-.85.82H6.41a.84.84 0 01-.85-.82V4.16a.84.84 0 01.85-.83h10.44a.84.84 0 01.85.83v2.66a.73.73 0 001.46 0V4.16A2.23 2.23 0 0016.85 2H6.41A2.24 2.24 0 004.1 4.16v15.7A2.24 2.24 0 006.41 22h10.44a2.24 2.24 0 002.31-2.15v-2.53a.7.7 0 00-.73-.66z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M19.82 11.78l-4.91-4.91a.32.32 0 00-.54.23v2.69H7.94a.32.32 0 00-.32.32v3.8a.31.31 0 00.32.31h6.43v2.7a.32.32 0 00.54.22l4.91-4.91a.33.33 0 000-.45z"
  })));
});
var _default = Logout;
exports["default"] = _default;