"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var SocialPinterest = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 2a10 10 0 00-4 19.16 8.68 8.68 0 01.17-2.3l1.29-5.45a3.78 3.78 0 01-.32-1.58c0-1.48.86-2.59 1.93-2.59a1.34 1.34 0 011.34 1.5 21.19 21.19 0 01-.88 3.55 1.55 1.55 0 001.58 1.93c1.89 0 3.17-2.43 3.17-5.32 0-2.19-1.48-3.83-4.16-3.83a4.73 4.73 0 00-4.92 4.79 2.86 2.86 0 00.66 2 .49.49 0 01.14.56c0 .18-.16.63-.2.8a.35.35 0 01-.5.25c-1.4-.57-2-2.1-2-3.82 0-2.84 2.39-6.25 7.14-6.25 3.82 0 6.33 2.77 6.33 5.73C18.71 15 16.53 18 13.32 18a2.86 2.86 0 01-2.44-1.25s-.58 2.3-.71 2.75a8.27 8.27 0 01-1 2.14A9.83 9.83 0 0012 22a10 10 0 000-20z",
    fill: "currentColor"
  }));
});
var _default = SocialPinterest;
exports["default"] = _default;