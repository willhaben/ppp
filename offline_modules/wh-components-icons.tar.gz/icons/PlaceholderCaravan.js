"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var PlaceholderCaravan = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    viewBox: "0 0 283.46 283.46",
    width: "1em",
    height: "1em",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    "data-name": "icon_placeholder_caravan",
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M101.48 182.357l72.03-.44.036 6-72.029.44z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M201.12 187.75v-6l23.8-.13a4.63 4.63 0 004.17-2.25c2.15-3.25 2-8.51 1.53-9.78a2.65 2.65 0 00-1.29-1 2.77 2.77 0 01-2.62-2.93c-.07-4.84-.68-10-1.3-11.09-.45-.65-3-2-4.65-2.89a40.44 40.44 0 01-7.28-4.58c-2.86-2.45-10.48-9.83-15.13-15a9.43 9.43 0 01-.5-11.85 8.51 8.51 0 001.38-6.78c-.94-4.42-5.13-8.94-12.11-13.08-23.15-13.74-63.58-2.32-64-2.21a2.72 2.72 0 01-.8.12l-16.24.16a3.09 3.09 0 01-2.24-1 3 3 0 01-.77-2.31c.22-2.44.34-5 .31-6.55a87.29 87.29 0 00-18.14 0c0 1.61.09 4.32.26 6.59a3 3 0 01-3 3.23h-27c-2.44 0-2.85.66-2.85 2.64v76.43c2.2 1.52 11.29 4.06 19.28 4.06v6c-3.31 0-25.28-1.73-25.28-9.27v-77.15c0-5.49 3.22-8.64 8.85-8.64h23.78c-.29-6 .26-6.94.61-7.54.87-1.48 2.43-2.25 9-2.62s17.45-.53 19.59 2.34c.46.62 1.2 1.61.84 7.78l12.56-.12c4.68-1.3 43.94-11.53 68.31 2.93 8.59 5.09 13.61 10.81 14.92 17a14.5 14.5 0 01-2.36 11.51 3.49 3.49 0 00.07 4.35c4.43 4.91 11.9 12.16 14.58 14.46a35.39 35.39 0 006.19 3.83c3 1.59 5.53 3 6.82 4.86 1.61 2.41 2.11 8.42 2.25 12.3a8.81 8.81 0 013 2.7c1.83 2.62 1.83 10.13-.79 15.17a10.82 10.82 0 01-9.91 6.19h-4.79z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M129.34 185h-6v-47.91a11.27 11.27 0 0111.25-11.25h8.08a11.26 11.26 0 0111.24 11.25v47.82h-6v-47.82a5.25 5.25 0 00-5.24-5.25h-8.08a5.25 5.25 0 00-5.25 5.25zM97.68 156.64H77.79a11.27 11.27 0 01-11.25-11.25v-8.3a11.27 11.27 0 0111.25-11.25h19.89a11.26 11.26 0 0111.24 11.25v8.3a11.26 11.26 0 01-11.24 11.25zm-19.89-24.8a5.26 5.26 0 00-5.25 5.25v8.3a5.26 5.26 0 005.25 5.25h19.89a5.25 5.25 0 005.24-5.25v-8.3a5.25 5.25 0 00-5.24-5.25zM185.89 156.64h-13.11a11.26 11.26 0 01-11.24-11.25v-8.3c0-3.72 1.1-6.72 3.19-8.69s4.78-2.76 8.23-2.55c7.36.44 22.5 13 24.07 18.75a8.31 8.31 0 01-1.6 7.33 12.4 12.4 0 01-9.54 4.71zM172 131.82a4.46 4.46 0 00-3.13 1c-1.08 1-1.31 2.91-1.31 4.32v8.3a5.25 5.25 0 005.24 5.25h13.11a6.36 6.36 0 004.77-2.35 2.37 2.37 0 00.58-2.1c-.93-3.18-13.66-14.05-18.64-14.35zM87.68 201.28a17.06 17.06 0 1117.06-17.06 17.08 17.08 0 01-17.06 17.06zm0-28.12a11.06 11.06 0 1011.06 11.06 11.07 11.07 0 00-11.06-11.06zM187.52 201.28a17.06 17.06 0 1117.06-17.06 17.08 17.08 0 01-17.06 17.06zm0-28.12a11.06 11.06 0 1011.06 11.06 11.07 11.07 0 00-11.06-11.06z"
  })));
});
var _default = PlaceholderCaravan;
exports["default"] = _default;