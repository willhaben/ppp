"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var PlaceholderMotorbike = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    viewBox: "0 0 283.46 283.46",
    width: "1em",
    height: "1em",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    "data-name": "icon_placeholder_motorbike",
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M187.16 96.85c.89 0 2.84 1.74 3.4 4.3a11.69 11.69 0 01-.62 5.79s16 17.79 17.17 22a43.58 43.58 0 00-25.29 8.53 35.48 35.48 0 00-10.91 11.69 43.71 43.71 0 00-5.27 35.19c-6 .6-18.41.82-29.48.82s-20.81-.22-21.7-.48c-2.1-.62-13.72-14.09-13.72-14.09s-17.84 1.29-20.33 1.55h-.12c-2.42 0-3.74-7.19-1.67-7.62s34.07-6.69 35.84-7.39c1-.41-2.41-8.83-8.4-15.23-4.41-4.71-10.71-7.84-15.12-8.29-12-1.23-26.88-16.35-26.88-16.35s-5.6-3.08-5.6-5.6c0-.68 1.91-1 4.75-1 7.7 0 22.2 2 23.47 3.65 1.52 1.91 15.17 12.08 25.46 12.08a12.09 12.09 0 004.11-.66c5.08-1.82 7.44-10.59 23.4-13.27a40.22 40.22 0 016.75-.6c12.59 0 17.37 6.81 18.22 6.81 1 0 2-2.42 2.54-3.14s2.5-3.16 2.61-3.91-3.36-3.59-3.36-3.59a9.15 9.15 0 01-1.34-4.7c.19-2.14 6.85-4.94 10.61-4.94h.36c3.67.2 8.07 3.81 8.07 3.81l1.31-2.27s.78-2.91 1.6-3.11h.13m0-6a6.51 6.51 0 00-1.52.18 6.67 6.67 0 00-4 2.76 15.69 15.69 0 00-5.3-1.35h-.68c-4.46 0-15.94 3.1-16.59 10.41a13 13 0 00.94 5.79 33.19 33.19 0 00-13.64-2.72 46.73 46.73 0 00-7.74.67c-12.55 2.12-18.17 7.64-21.88 11.3a15.41 15.41 0 01-2.56 2.24 6.1 6.1 0 01-2.09.31c-7.45 0-18.88-8-20.86-9.94-1.31-1.6-3.35-3-13-4.5a112.51 112.51 0 00-15-1.29 25.25 25.25 0 00-4.53.33c-5.92 1.09-6.22 5.71-6.22 6.63 0 2.67 1.4 6.59 7.93 10.42 3.36 3.31 17.2 16.2 29.94 17.5 2.86.29 7.81 2.64 11.35 6.42a36.76 36.76 0 014.93 6.77c-5.21 1.09-13.72 2.8-25.46 5.13l-3.75.75c-3 .62-6.36 3.5-5.74 9.56s4.07 9.93 8.62 9.93h.73c1.65-.17 11.2-.88 17.17-1.31 11 12.6 13.15 13.22 14.59 13.64.67.2 2.45.72 23.39.72 6.48 0 22.39-.08 30.07-.85l7.08-.71-1.89-6.86a37.72 37.72 0 014.56-30.39l.07-.11.07-.12a29.54 29.54 0 019.06-9.71l.11-.07.11-.08a37.43 37.43 0 0121.81-7.36l7.8-.12-2.11-7.51c-1.18-4.16-9.13-13.81-16.37-22a15.18 15.18 0 00-.1-5.44c-1-4.44-4.7-9-9.26-9z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M207.77 201.42a29.1 29.1 0 1129.09-29.09 29.13 29.13 0 01-29.09 29.09zm0-52.19a23.1 23.1 0 1023.09 23.1 23.12 23.12 0 00-23.09-23.1zM75.7 201.42a29.1 29.1 0 1122.87-47.06 3 3 0 11-4.71 3.7A23.1 23.1 0 1098 178.38a3 3 0 115.79 1.57 29.12 29.12 0 01-28.09 21.47z"
  })));
});
var _default = PlaceholderMotorbike;
exports["default"] = _default;