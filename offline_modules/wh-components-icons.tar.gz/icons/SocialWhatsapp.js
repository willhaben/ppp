"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var SocialWhatsapp = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22 11.74a9.83 9.83 0 01-14.56 8.53L2 22l1.77-5.23a9.68 9.68 0 01-1.41-5 9.82 9.82 0 0119.64 0zm-9.82-8.19a8.23 8.23 0 00-8.25 8.19 8.09 8.09 0 001.57 4.8l-1 3.05 3.17-1a8.27 8.27 0 0012.8-6.84 8.24 8.24 0 00-8.29-8.2zm5 10.44c-.06-.1-.22-.16-.46-.28S15.25 13 15 12.93s-.38-.12-.54.12-.62.78-.76.94-.28.18-.52.06a6.76 6.76 0 01-1.94-1.19 7.28 7.28 0 01-1.34-1.65c-.14-.24 0-.37.11-.49s.24-.28.36-.42a1.63 1.63 0 00.24-.4.42.42 0 000-.41c-.06-.12-.54-1.3-.74-1.78s-.4-.4-.54-.4h-.46a.92.92 0 00-.65.3 2.69 2.69 0 00-.84 2 4.48 4.48 0 001 2.46 9.82 9.82 0 004.11 3.61c2.44 1 2.44.64 2.88.6A2.42 2.42 0 0017 15.12a2 2 0 00.14-1.12z",
    fill: "currentColor"
  }));
});
var _default = SocialWhatsapp;
exports["default"] = _default;