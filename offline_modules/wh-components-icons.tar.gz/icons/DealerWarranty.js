"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var DealerWarranty = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    "data-name": "icon_dealer_warranty",
    d: "M17 9.73l-5.49 5.64a.85.85 0 01-.58.25.85.85 0 01-.58-.23L7.1 12.06a.72.72 0 010-1.05.82.82 0 011.11 0l2.69 2.71 4.93-5A.82.82 0 0117 8.66a.73.73 0 010 1.07zm2.19-5.41l-6.62-2.2a1.66 1.66 0 00-1.08 0l-6.6 2.2a.79.79 0 00-.56.73v9.89c0 3.31 5.81 6.29 7.34 7a.88.88 0 00.71 0c1.53-.72 7.33-3.7 7.33-7V5.05a.7.7 0 00-.5-.73z",
    fill: "currentColor",
    fillRule: "evenodd"
  }));
});
var _default = DealerWarranty;
exports["default"] = _default;