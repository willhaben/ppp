"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Guarantee = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M18.78 9.79a.57.57 0 010-.54l.67-1.32a.58.58 0 00-.2-.76L18 6.36a.57.57 0 01-.27-.46l-.08-1.48a.57.57 0 00-.56-.56l-1.48-.08a.57.57 0 01-.46-.27l-.81-1.24a.6.6 0 00-.76-.21l-1.32.68a.57.57 0 01-.54 0l-1.32-.68a.6.6 0 00-.76.21l-.8 1.24a.57.57 0 01-.46.27l-1.48.08a.57.57 0 00-.56.56L6.26 5.9a.57.57 0 01-.26.46l-1.24.81a.58.58 0 00-.2.76l.67 1.32a.57.57 0 010 .54l-.67 1.32a.58.58 0 00.2.76l1.24.81a.57.57 0 01.27.46l.08 1.48a.57.57 0 00.56.56l1.31.07v6.25a.5.5 0 00.77.42l2.47-1.63a1 1 0 011.1 0L15 21.92a.5.5 0 00.77-.42v-6.25l1.31-.07a.57.57 0 00.56-.56l.08-1.48a.57.57 0 01.27-.46l1.24-.81a.58.58 0 00.2-.76zm-3-1.23l-1.63 1.59.38 2.21a.36.36 0 01-.15.36.3.3 0 01-.2.06.35.35 0 01-.17 0l-2-1.06-2 1.06a.37.37 0 01-.39 0 .36.36 0 01-.14-.36l.38-2.23-1.61-1.61A.37.37 0 018.46 8l2.23-.33 1-2A.35.35 0 0112 5.4a.37.37 0 01.33.2l1 2 2.22.31a.37.37 0 01.3.25.36.36 0 01-.1.4z",
    fill: "currentColor"
  }));
});
var _default = Guarantee;
exports["default"] = _default;