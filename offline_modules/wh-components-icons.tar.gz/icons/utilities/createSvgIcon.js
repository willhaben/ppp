"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.createSvgIcon = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _color = require("@wh-components/system/color");

var _system = require("@wh-components/system");

var size = (0, _system.system)({
  size: {
    properties: ['height', 'width'],
    scale: 'components.icon.size'
  }
});

var createSvgIcon = function createSvgIcon(Component) {
  var SvgIcon = (0, _styledComponents["default"])(Component).withConfig({
    displayName: "createSvgIcon__SvgIcon",
    componentId: "sc-1vebdtk-0"
  })({
    display: 'inline-block',
    flex: '0 0 auto'
  }, (0, _system.compose)(size, _space.space, _layout.display, _color.color));
  SvgIcon.defaultProps = {
    size: '1em',
    color: 'palette.koala'
  };
  return SvgIcon;
};

exports.createSvgIcon = createSvgIcon;