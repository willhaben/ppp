"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Mapview = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M22.11 17.32L19.76 8.7a.59.59 0 00-.35-.39.56.56 0 00-.52 0l-2.26 1.37a.59.59 0 00.6 1l1.6-.95 2 7.45-3.28 1.93-.89-7a.59.59 0 00-1.17.15l.89 7-3.67-1.13v-1.4a.59.59 0 00-.59-.59.59.59 0 00-.59.59v1.4l-3.67 1.13.89-7a.59.59 0 10-1.17-.15l-.89 7-3.28-1.91 2-7.45L7 10.7a.59.59 0 10.6-1L5.37 8.35a.56.56 0 00-.52 0 .58.58 0 00-.34.39l-2.35 8.58a.59.59 0 00.26.66l4.45 2.62a.61.61 0 00.3.08h.17l4.79-1.47 4.8 1.47h.17a.61.61 0 00.3-.08l4.44-2.6a.58.58 0 00.27-.68z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16 7.2a3.9 3.9 0 00-7.79 0c0 2.08 3.89 7.75 3.89 7.75S16 9.28 16 7.2zm-5.53 0a1.64 1.64 0 111.63 1.62 1.63 1.63 0 01-1.6-1.6z"
  })));
});
var _default = Mapview;
exports["default"] = _default;