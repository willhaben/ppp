"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Favorite = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M21.72 10l-4.24 4.12 1 5.73a.93.93 0 01-.38.91.76.76 0 01-.53.18.81.81 0 01-.44-.12l-5.2-2.73-5.12 2.76a.94.94 0 01-1.38-1l1-5.79-4.14-4a.92.92 0 01-.24-1 .94.94 0 01.77-.64l5.79-.86 2.52-5.23a.94.94 0 01.87-.5 1 1 0 01.85.53l2.59 5.26 5.76.8a1 1 0 01.76.64.92.92 0 01-.24.94z",
    fill: "currentColor"
  }));
});
var _default = Favorite;
exports["default"] = _default;