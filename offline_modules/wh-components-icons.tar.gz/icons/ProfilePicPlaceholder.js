"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var ProfilePicPlaceholder = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    fill: "#e9eef8",
    d: "M0 0h24v24H0z"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 17.79c-3.71 0-7 2-9 6.21h18c-2-4.19-5.28-6.21-9-6.21z",
    fill: "#aab4c7"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M16.69 10.7h-.24A4.49 4.49 0 0012 7.1a4.53 4.53 0 00-3.77 2 4.47 4.47 0 00-.68 1.65.85.85 0 00-.23 0 1.13 1.13 0 100 2.26h.16V13a4.44 4.44 0 003.39 4.28v1.35A1.14 1.14 0 0012 19.76a1.13 1.13 0 001.13-1.13v-1.35a4.45 4.45 0 003.4-4.28h.16a1.13 1.13 0 000-2.26z",
    fill: "#fff"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M15.13 4.7a2 2 0 00.27-.43.16.16 0 00-.19-.22l-.38.12a.16.16 0 01-.21-.17v-.18a.16.16 0 00-.2-.16 2.47 2.47 0 00-.69.27A5 5 0 0012 3.6a5.49 5.49 0 00-5.31 5.79 6.66 6.66 0 00.43 2.38.15.15 0 00.28 0 4 4 0 01.4-1.42 5.81 5.81 0 011.4-1.76.14.14 0 01.2 0 5.74 5.74 0 003.19 2c2.24.51 2.83-.12 3.27-.4s.65.94.71 1.64a.14.14 0 00.27 0 6.59 6.59 0 00.46-2.45 5.88 5.88 0 00-2.17-4.68z",
    fill: "#8e99ac"
  }));
});
var _default = ProfilePicPlaceholder;
exports["default"] = _default;