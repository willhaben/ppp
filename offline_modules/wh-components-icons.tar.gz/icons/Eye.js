"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var Eye = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("g", {
    fill: "currentColor"
  }, /*#__PURE__*/_react["default"].createElement("ellipse", {
    cx: 12.02,
    cy: 12.02,
    rx: 2.88,
    ry: 2.75
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 5.62A11 11 0 002 12a11 11 0 0010 6.4c7.12 0 10-6.4 10-6.4a11.22 11.22 0 00-10-6.38zm0 10.74A4.44 4.44 0 017.49 12 4.44 4.44 0 0112 7.69 4.44 4.44 0 0116.56 12 4.44 4.44 0 0112 16.36z"
  })));
});
var _default = Eye;
exports["default"] = _default;