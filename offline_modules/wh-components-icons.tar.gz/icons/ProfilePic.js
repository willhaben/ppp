"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _createSvgIcon = require("./utilities/createSvgIcon");

var ProfilePic = (0, _createSvgIcon.createSvgIcon)(function (_ref) {
  var className = _ref.className,
      focusable = _ref.focusable,
      role = _ref.role,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["className", "focusable", "role", "testId"]);
  return /*#__PURE__*/_react["default"].createElement("svg", {
    width: "1em",
    height: "1em",
    viewBox: "0 0 24 24",
    className: className,
    focusable: focusable,
    role: role,
    pointerEvents: "none",
    "data-testid": testId,
    "aria-hidden": props['aria-hidden'],
    "aria-label": props['aria-label'],
    "aria-labelledby": props['aria-labelledby']
  }, /*#__PURE__*/_react["default"].createElement("path", {
    d: "M2 12a10 10 0 1110 10A10 10 0 012 12",
    fill: "#e9eef8",
    stroke: "#aab4c7",
    strokeMiterlimit: 10,
    strokeWidth: 0.5
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M12 16.82a7.43 7.43 0 00-6.22 3 10 10 0 0012.45 0 7.43 7.43 0 00-6.23-3z",
    fill: "#aab4c7"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M15.91 10.92a.65.65 0 00-.2 0 3.76 3.76 0 00-3.71-3 3.8 3.8 0 00-3.14 1.64 3.56 3.56 0 00-.56 1.38.68.68 0 00-.2 0 .94.94 0 000 1.88h.13a3.7 3.7 0 002.83 3.57v1.13a.94.94 0 00.94.94 1 1 0 00.95-.94V16.4a3.7 3.7 0 002.82-3.57h.14a.94.94 0 000-1.88z",
    fill: "#fff"
  }), /*#__PURE__*/_react["default"].createElement("path", {
    d: "M14.61 5.92a2.05 2.05 0 00.22-.36.13.13 0 00-.16-.18l-.31.09a.13.13 0 01-.18-.13v-.16a.13.13 0 00-.18-.13 2.07 2.07 0 00-.57.23A4.06 4.06 0 0012 5a4.58 4.58 0 00-4.43 4.82 5.42 5.42 0 00.37 2 .11.11 0 00.22 0 3.46 3.46 0 01.34-1.19 4.83 4.83 0 011.17-1.47.12.12 0 01.17 0 4.83 4.83 0 002.65 1.62c1.86.43 2.36-.1 2.73-.33s.54.78.59 1.36a.12.12 0 00.23 0 5.75 5.75 0 00.38-2 4.9 4.9 0 00-1.81-3.89z",
    fill: "#8e99ac"
  }));
});
var _default = ProfilePic;
exports["default"] = _default;