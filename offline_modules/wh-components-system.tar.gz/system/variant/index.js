"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports["default"] = exports.variant = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/defineProperty"));

var _forEach = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/for-each"));

var _isArray = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/array/is-array"));

var _utilities = require("../utilities");

var _ = require("..");

var concatValue = function concatValue(value) {
  return (0, _utilities.isArray)(value) ? value.join('') : value;
};

var variant = function variant(_ref) {
  var scale = _ref.scale,
      _ref$prop = _ref.prop,
      prop = _ref$prop === void 0 ? 'variant' : _ref$prop;

  // TODO avoid force cast
  var styleFunction = // Object.keys(variants).length
  // ? (value, scale, props) => css(get(scale, concatValue(value), null))(props.theme)

  /* eslint-disable-next-line no-shadow */

  /* : */
  function styleFunction(value, scale) {
    return (0, _utilities.getFromKeyPath)(scale, concatValue(value), null);
  };

  styleFunction.scale = scale; // styleFunction.defaults = variants

  styleFunction.prop = prop;
  var config = {};

  if ((0, _isArray["default"])(prop)) {
    (0, _forEach["default"])(prop).call(prop, function (p) {
      config[p] = styleFunction;
    });
  } else {
    config = (0, _defineProperty2["default"])({}, prop, styleFunction);
  }

  return (0, _.createParser)(config);
};

exports.variant = variant;
var _default = variant;
exports["default"] = _default;