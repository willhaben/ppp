interface VariantOptions {
    scale?: string;
    prop: string | string[];
}
export declare const variant: ({ scale, prop }: VariantOptions) => import("..").ParserFunction;
export default variant;
