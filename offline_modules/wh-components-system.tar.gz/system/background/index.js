"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.background = exports.backgroundPropKeys = void 0;

var _ = require("..");

var backgroundPropKeys = ['background', 'backgroundImage', 'backgroundSize', 'backgroundPosition', 'backgroundPositionX', 'backgroundPositionY', 'backgroundRepeat', 'backgroundRepeatX', 'backgroundRepeatY'];
exports.backgroundPropKeys = backgroundPropKeys;
var background = (0, _.system)({
  background: true,
  backgroundImage: true,
  backgroundSize: true,
  backgroundPosition: true,
  backgroundPositionX: true,
  backgroundPositionY: true,
  backgroundRepeat: true,
  backgroundRepeatX: true,
  backgroundRepeatY: true
});
exports.background = background;