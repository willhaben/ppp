import { ResponsiveValue, SystemValue } from '..';
import { BackgroundSizeProperty, BackgroundPositionProperty, BackgroundRepeatProperty } from 'csstype';
export interface BackgroundProps {
    background?: ResponsiveValue<SystemValue>;
    backgroundImage?: ResponsiveValue<string>;
    backgroundSize?: ResponsiveValue<BackgroundSizeProperty<SystemValue>>;
    backgroundPosition?: ResponsiveValue<BackgroundPositionProperty<SystemValue>>;
    backgroundPositionX?: ResponsiveValue<BackgroundPositionProperty<SystemValue>>;
    backgroundPositionY?: ResponsiveValue<BackgroundPositionProperty<SystemValue>>;
    backgroundRepeat?: ResponsiveValue<BackgroundRepeatProperty>;
    backgroundRepeatX?: ResponsiveValue<BackgroundRepeatProperty>;
    backgroundRepeatY?: ResponsiveValue<BackgroundRepeatProperty>;
}
export declare const backgroundPropKeys: Readonly<(keyof BackgroundProps)[]>;
export declare const background: import("..").ParserFunction;
