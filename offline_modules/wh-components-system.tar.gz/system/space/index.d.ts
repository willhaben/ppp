import { ResponsiveValue, SystemValue } from '..';
export interface MarginProps {
    margin?: ResponsiveValue<SystemValue>;
    marginTop?: ResponsiveValue<SystemValue>;
    marginRight?: ResponsiveValue<SystemValue>;
    marginBottom?: ResponsiveValue<SystemValue>;
    marginLeft?: ResponsiveValue<SystemValue>;
    marginHorizontal?: ResponsiveValue<SystemValue>;
    marginVertical?: ResponsiveValue<SystemValue>;
}
export declare const marginPropKeys: Readonly<(keyof MarginProps)[]>;
export declare const margin: import("..").ParserFunction;
export interface PaddingProps {
    padding?: ResponsiveValue<SystemValue>;
    paddingTop?: ResponsiveValue<SystemValue>;
    paddingRight?: ResponsiveValue<SystemValue>;
    paddingBottom?: ResponsiveValue<SystemValue>;
    paddingLeft?: ResponsiveValue<SystemValue>;
    paddingHorizontal?: ResponsiveValue<SystemValue>;
    paddingVertical?: ResponsiveValue<SystemValue>;
}
export declare const paddingPropKeys: Readonly<(keyof PaddingProps)[]>;
export declare const padding: import("..").ParserFunction;
export declare type SpaceProps = MarginProps & PaddingProps;
export declare const spacePropKeys: Readonly<(keyof SpaceProps)[]>;
export declare const space: import("..").ParserFunction;
