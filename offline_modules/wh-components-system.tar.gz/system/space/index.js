"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.space = exports.spacePropKeys = exports.padding = exports.paddingPropKeys = exports.margin = exports.marginPropKeys = void 0;

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _ = require("..");

var _utilities = require("../utilities");

var _context;

var defaults = {
  space: [0, 4, 8, 16, 32, 64, 128, 256, 512]
};

var getMargin = function getMargin(n, scale) {
  if ((0, _utilities.isString)(n)) {
    return (0, _utilities.getFromKeyPath)(scale, n, n);
  } else if ((0, _utilities.isNumber)(n)) {
    var isNegative = n < 0;
    var absolute = Math.abs(n);
    var value = (0, _utilities.getFromKeyPath)(scale, absolute, absolute);

    if (!(0, _utilities.isNumber)(value)) {
      return isNegative ? "-".concat(value) : value;
    }

    return value * (isNegative ? -1 : 1);
  } else {
    return n;
  }
};

var marginPropKeys = ['margin', 'marginTop', 'marginRight', 'marginBottom', 'marginLeft', 'marginHorizontal', 'marginVertical'];
exports.marginPropKeys = marginPropKeys;
var margin = (0, _.system)({
  margin: {
    property: 'margin',
    scale: 'space',
    transform: getMargin,
    defaultScale: defaults.space
  },
  marginTop: {
    property: 'marginTop',
    scale: 'space',
    transform: getMargin,
    defaultScale: defaults.space
  },
  marginRight: {
    property: 'marginRight',
    scale: 'space',
    transform: getMargin,
    defaultScale: defaults.space
  },
  marginBottom: {
    property: 'marginBottom',
    scale: 'space',
    transform: getMargin,
    defaultScale: defaults.space
  },
  marginLeft: {
    property: 'marginLeft',
    scale: 'space',
    transform: getMargin,
    defaultScale: defaults.space
  },
  marginHorizontal: {
    properties: ['marginLeft', 'marginRight'],
    scale: 'space',
    transform: getMargin,
    defaultScale: defaults.space
  },
  marginVertical: {
    properties: ['marginTop', 'marginBottom'],
    scale: 'space',
    transform: getMargin,
    defaultScale: defaults.space
  }
});
exports.margin = margin;
var paddingPropKeys = ['padding', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'paddingHorizontal', 'paddingVertical'];
exports.paddingPropKeys = paddingPropKeys;
var padding = (0, _.system)({
  padding: {
    property: 'padding',
    scale: 'space',
    defaultScale: defaults.space
  },
  paddingTop: {
    property: 'paddingTop',
    scale: 'space',
    defaultScale: defaults.space
  },
  paddingRight: {
    property: 'paddingRight',
    scale: 'space',
    defaultScale: defaults.space
  },
  paddingBottom: {
    property: 'paddingBottom',
    scale: 'space',
    defaultScale: defaults.space
  },
  paddingLeft: {
    property: 'paddingLeft',
    scale: 'space',
    defaultScale: defaults.space
  },
  paddingHorizontal: {
    properties: ['paddingLeft', 'paddingRight'],
    scale: 'space',
    defaultScale: defaults.space
  },
  paddingVertical: {
    properties: ['paddingTop', 'paddingBottom'],
    scale: 'space',
    defaultScale: defaults.space
  }
});
exports.padding = padding;
var spacePropKeys = (0, _concat["default"])(_context = []).call(_context, marginPropKeys, paddingPropKeys);
exports.spacePropKeys = spacePropKeys;
var space = (0, _.compose)(margin, padding);
exports.space = space;