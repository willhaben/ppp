import { ResponsiveValue } from '..';
export interface ShadowProps {
    boxShadow?: ResponsiveValue<string>;
    textShadow?: ResponsiveValue<string>;
}
export declare const shadowPropKeys: Readonly<(keyof ShadowProps)[]>;
export declare const shadow: import("..").ParserFunction;
