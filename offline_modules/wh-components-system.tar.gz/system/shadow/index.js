"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.shadow = exports.shadowPropKeys = void 0;

var _ = require("..");

var shadowPropKeys = ['boxShadow', 'textShadow'];
exports.shadowPropKeys = shadowPropKeys;
var shadow = (0, _.system)({
  boxShadow: {
    property: 'boxShadow',
    scale: 'shadows'
  },
  textShadow: {
    property: 'textShadow',
    scale: 'shadows'
  }
});
exports.shadow = shadow;