"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty2 = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty2(exports, "__esModule", {
  value: true
});

exports.extractProps = exports.removeUndefined = exports.hasKey = exports.getFromKeyPath = exports.sort = exports.merge = exports.isArray = exports.isStyleFunction = exports.isFunction = exports.isString = exports.isNumber = exports.isObject = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/define-property"));

var _defineProperties = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/define-properties"));

var _getOwnPropertyDescriptors = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors"));

var _getOwnPropertyDescriptor = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor"));

var _filter = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/filter"));

var _getOwnPropertySymbols = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols"));

var _getIterator2 = _interopRequireDefault(require("@babel/runtime-corejs3/core-js/get-iterator"));

var _getIteratorMethod2 = _interopRequireDefault(require("@babel/runtime-corejs3/core-js/get-iterator-method"));

var _symbol = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/symbol"));

var _from = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/array/from"));

var _slice = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/slice"));

var _keys = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/keys"));

var _sort = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/sort"));

var _forEach = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/for-each"));

var _defineProperty3 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/defineProperty"));

var _assign = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/assign"));

var _isArray = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/array/is-array"));

var _typeof2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/typeof"));

function ownKeys(object, enumerableOnly) { var keys = (0, _keys["default"])(object); if (_getOwnPropertySymbols["default"]) { var symbols = (0, _getOwnPropertySymbols["default"])(object); if (enumerableOnly) symbols = (0, _filter["default"])(symbols).call(symbols, function (sym) { return (0, _getOwnPropertyDescriptor["default"])(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context5; (0, _forEach["default"])(_context5 = ownKeys(Object(source), true)).call(_context5, function (key) { (0, _defineProperty3["default"])(target, key, source[key]); }); } else if (_getOwnPropertyDescriptors["default"]) { (0, _defineProperties["default"])(target, (0, _getOwnPropertyDescriptors["default"])(source)); } else { var _context6; (0, _forEach["default"])(_context6 = ownKeys(Object(source))).call(_context6, function (key) { (0, _defineProperty2["default"])(target, key, (0, _getOwnPropertyDescriptor["default"])(source, key)); }); } } return target; }

function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof _symbol["default"] === "undefined" || (0, _getIteratorMethod2["default"])(o) == null) { if ((0, _isArray["default"])(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = (0, _getIterator2["default"])(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { var _context4; if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = (0, _slice["default"])(_context4 = Object.prototype.toString.call(o)).call(_context4, 8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return (0, _from["default"])(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

var isObject = function isObject(value) {
  return (0, _typeof2["default"])(value) === 'object' && !(0, _isArray["default"])(value);
};

exports.isObject = isObject;

var isNumber = function isNumber(value) {
  return typeof value === 'number' && !isNaN(value);
};

exports.isNumber = isNumber;

var isString = function isString(value) {
  return typeof value === 'string';
};

exports.isString = isString;

var isFunction = function isFunction(value) {
  return typeof value === 'function';
}; // the compiler cannot deduce from isFunction() that it covers the StyleFunction as well


exports.isFunction = isFunction;

var isStyleFunction = function isStyleFunction(value) {
  return typeof value === 'function';
};

exports.isStyleFunction = isStyleFunction;

var isArray = function isArray(value) {
  return (0, _isArray["default"])(value);
};

exports.isArray = isArray;

var merge = function merge(a, b) {
  var result = (0, _assign["default"])({}, a, b);

  for (var _key in a) {
    if (!a[_key] || (0, _typeof2["default"])(b[_key]) !== 'object') {
      continue;
    }

    (0, _assign["default"])(result, (0, _defineProperty3["default"])({}, _key, (0, _assign["default"])(a[_key], b[_key])));
  }

  return result;
};

exports.merge = merge;

var sort = function sort(obj) {
  var _context, _context2;

  var next = {};
  (0, _forEach["default"])(_context = (0, _sort["default"])(_context2 = (0, _keys["default"])(obj)).call(_context2)).call(_context, function (key) {
    next[key] = obj[key];
  });
  return next;
};

exports.sort = sort;

var getFromKeyPath = function getFromKeyPath(obj, keyPath, defaultValue) {
  if (typeof keyPath === 'undefined') {
    return defaultValue;
  }

  var keys = keyPath && isString(keyPath) ? keyPath.split('.') : [keyPath];
  var currentObj = obj;

  var _iterator = _createForOfIteratorHelper(keys),
      _step;

  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var k = _step.value;

      if (typeof currentObj === 'undefined') {
        break;
      }

      if ((0, _typeof2["default"])(currentObj) !== 'object' || currentObj === null) {
        currentObj = undefined;
        break;
      }

      if (!hasKey(currentObj, k)) {
        currentObj = undefined;
        break;
      }

      currentObj = currentObj[k];
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }

  return currentObj === undefined ? defaultValue : currentObj;
}; // from https://dev.to/kingdaro/indexing-objects-in-typescript-1cgi


exports.getFromKeyPath = getFromKeyPath;

var hasKey = function hasKey(obj, key) {
  return key in obj;
};
/** Returns an object without all keys with value "undefined" removed */


exports.hasKey = hasKey;

var removeUndefined = function removeUndefined(obj) {
  var _context3;

  (0, _forEach["default"])(_context3 = (0, _keys["default"])(obj)).call(_context3, function (key) {
    if (typeof obj[key] === 'undefined') {
      delete obj[key];
    }
  });
  return obj;
};
/** Splits the provided object in two parts, one with the props having the keys of keysToExtract, and one with the remaining props  */


exports.removeUndefined = removeUndefined;

var extractProps = function extractProps(obj, keysToExtract) {
  var extractedProps = {};

  var remainingProps = _objectSpread({}, obj);

  (0, _forEach["default"])(keysToExtract).call(keysToExtract, function (k) {
    var v = obj[k];

    if (typeof v !== 'undefined') {
      extractedProps[k] = v;
    }

    delete remainingProps[k];
  });
  return {
    extractedProps: extractedProps,
    remainingProps: remainingProps
  };
};

exports.extractProps = extractProps;