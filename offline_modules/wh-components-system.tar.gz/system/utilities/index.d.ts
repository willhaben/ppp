import { StyleFunction } from '..';
export declare const isObject: (value: unknown) => value is Record<string, unknown>;
export declare const isNumber: (value: unknown) => value is number;
export declare const isString: (value: unknown) => value is string;
export declare const isFunction: (value: unknown) => value is (...args: unknown[]) => unknown;
export declare const isStyleFunction: (value: unknown) => value is StyleFunction;
export declare const isArray: (value: unknown) => value is unknown[];
export declare const merge: <T extends Record<string, unknown>, U extends Record<string, unknown>>(a: T, b: U) => T & U;
export declare const sort: <T extends Record<string, unknown>>(obj: T) => T;
export declare const getFromKeyPath: (obj: unknown, keyPath: string | number | undefined, defaultValue?: unknown) => unknown;
export declare const hasKey: <O>(obj: O, key: keyof any) => key is keyof O;
/** Returns an object without all keys with value "undefined" removed */
export declare const removeUndefined: <T>(obj: {
    [key: string]: T | undefined;
}) => {
    [key: string]: T;
};
/** Splits the provided object in two parts, one with the props having the keys of keysToExtract, and one with the remaining props  */
export declare const extractProps: <InputProps extends ExtractedProps, ExtractedProps>(obj: InputProps, keysToExtract: readonly (keyof ExtractedProps)[]) => {
    extractedProps: ExtractedProps;
    remainingProps: Pick<InputProps, Exclude<keyof InputProps, keyof ExtractedProps>>;
};
