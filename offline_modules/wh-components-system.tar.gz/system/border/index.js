"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.border = exports.borderPropKeys = void 0;

var _ = require("..");

var borderPropKeys = ['border', 'borderWidth', 'borderStyle', 'borderColor', 'borderRadius', 'borderTop', 'borderTopWidth', 'borderTopStyle', 'borderTopColor', 'borderTopRadius', 'borderTopLeftRadius', 'borderTopRightRadius', 'borderRight', 'borderRightWidth', 'borderRightStyle', 'borderRightColor', 'borderRightRadius', 'borderBottom', 'borderBottomWidth', 'borderBottomStyle', 'borderBottomColor', 'borderBottomRadius', 'borderBottomLeftRadius', 'borderBottomRightRadius', 'borderLeft', 'borderLeftWidth', 'borderLeftStyle', 'borderLeftColor', 'borderLeftRadius', 'borderHorizontal', 'borderVertical'];
exports.borderPropKeys = borderPropKeys;
var border = (0, _.system)({
  border: {
    property: 'border',
    scale: 'borders'
  },
  borderWidth: true,
  borderStyle: true,
  borderColor: {
    property: 'borderColor',
    scale: 'colors'
  },
  borderRadius: {
    property: 'borderRadius',
    scale: 'borderRadii'
  },
  borderTop: {
    property: 'borderTop',
    scale: 'borders'
  },
  borderTopWidth: true,
  borderTopStyle: true,
  borderTopColor: {
    property: 'borderTopColor',
    scale: 'colors'
  },
  borderTopRadius: {
    properties: ['borderTopLeftRadius', 'borderTopRightRadius'],
    scale: 'borderRadii'
  },
  borderTopLeftRadius: {
    property: 'borderTopLeftRadius',
    scale: 'borderRadii'
  },
  borderTopRightRadius: {
    property: 'borderTopRightRadius',
    scale: 'borderRadii'
  },
  borderRight: {
    property: 'borderRight',
    scale: 'borders'
  },
  borderRightWidth: true,
  borderRightStyle: true,
  borderRightColor: {
    property: 'borderRightColor',
    scale: 'colors'
  },
  borderRightRadius: {
    properties: ['borderTopRightRadius', 'borderBottomRightRadius'],
    scale: 'borderRadii'
  },
  borderBottom: {
    property: 'borderBottom',
    scale: 'borders'
  },
  borderBottomWidth: true,
  borderBottomStyle: true,
  borderBottomColor: {
    property: 'borderBottomColor',
    scale: 'colors'
  },
  borderBottomRadius: {
    properties: ['borderBottomLeftRadius', 'borderBottomRightRadius'],
    scale: 'borderRadii'
  },
  borderBottomLeftRadius: {
    property: 'borderBottomLeftRadius',
    scale: 'borderRadii'
  },
  borderBottomRightRadius: {
    property: 'borderBottomRightRadius',
    scale: 'borderRadii'
  },
  borderLeft: {
    property: 'borderLeft',
    scale: 'borders'
  },
  borderLeftWidth: true,
  borderLeftStyle: true,
  borderLeftColor: {
    property: 'borderLeftColor',
    scale: 'colors'
  },
  borderLeftRadius: {
    properties: ['borderTopLeftRadius', 'borderBottomLeftRadius'],
    scale: 'borderRadii'
  },
  borderHorizontal: {
    properties: ['borderLeft', 'borderRight'],
    scale: 'borders'
  },
  borderVertical: {
    properties: ['borderTop', 'borderBottom'],
    scale: 'borders'
  }
});
exports.border = border;