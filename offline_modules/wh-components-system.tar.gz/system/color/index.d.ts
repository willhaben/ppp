import { ResponsiveValue, Value } from '..';
export interface ColorProps<T extends Value> {
    color?: ResponsiveValue<T>;
    backgroundColor?: ResponsiveValue<T>;
    opacity?: ResponsiveValue<number>;
}
export declare const colorPropKeys: Readonly<(keyof ColorProps<any>)[]>;
export declare const color: import("..").ParserFunction;
