"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.color = exports.colorPropKeys = void 0;

var _ = require("..");

var colorPropKeys = ['color', 'backgroundColor', 'opacity'];
exports.colorPropKeys = colorPropKeys;
var color = (0, _.system)({
  color: {
    property: 'color',
    scale: 'colors'
  },
  backgroundColor: {
    property: 'backgroundColor',
    scale: 'colors'
  },
  opacity: true
});
exports.color = color;