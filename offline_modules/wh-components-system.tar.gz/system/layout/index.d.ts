import { ResponsiveValue, SystemValue } from '..';
import { DisplayProperty, VisibilityProperty, OverflowProperty } from 'csstype';
export interface HeightProps {
    height?: ResponsiveValue<SystemValue>;
    minHeight?: ResponsiveValue<SystemValue>;
    maxHeight?: ResponsiveValue<SystemValue>;
}
export declare const heightPropKeys: Readonly<(keyof HeightProps)[]>;
export declare const height: import("..").ParserFunction;
export interface WidthProps {
    width?: ResponsiveValue<SystemValue>;
    minWidth?: ResponsiveValue<SystemValue>;
    maxWidth?: ResponsiveValue<SystemValue>;
}
export declare const widthPropKeys: Readonly<(keyof WidthProps)[]>;
export declare const width: import("..").ParserFunction;
export interface DisplayProps {
    display?: ResponsiveValue<DisplayProperty>;
    visibility?: ResponsiveValue<VisibilityProperty>;
}
export declare const displayPropKeys: Readonly<(keyof DisplayProps)[]>;
export declare const display: import("..").ParserFunction;
export interface OverflowProps {
    overflow?: ResponsiveValue<OverflowProperty>;
    overflowX?: ResponsiveValue<OverflowProperty>;
    overflowY?: ResponsiveValue<OverflowProperty>;
}
export declare const overflowPropKeys: Readonly<(keyof OverflowProps)[]>;
export declare const overflow: import("..").ParserFunction;
export declare type LayoutProps = HeightProps & WidthProps & DisplayProps & OverflowProps;
export declare const layoutPropKeys: Readonly<(keyof LayoutProps)[]>;
export declare const layout: import("..").ParserFunction;
