"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.layout = exports.layoutPropKeys = exports.overflow = exports.overflowPropKeys = exports.display = exports.displayPropKeys = exports.width = exports.widthPropKeys = exports.height = exports.heightPropKeys = void 0;

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _ = require("..");

var _utilities = require("../utilities");

var _context;

var getWidth = function getWidth(n, scale) {
  if ((0, _utilities.isString)(n) || (0, _utilities.isNumber)(n)) {
    return (0, _utilities.getFromKeyPath)(scale, n, !(0, _utilities.isNumber)(n) || n > 1 ? n : "".concat(n * 100, "%"));
  } else {
    return n;
  }
};

var heightPropKeys = ['height', 'minHeight', 'maxHeight'];
exports.heightPropKeys = heightPropKeys;
var height = (0, _.system)({
  height: {
    property: 'height',
    scale: 'sizes'
  },
  minHeight: {
    property: 'minHeight',
    scale: 'sizes'
  },
  maxHeight: {
    property: 'maxHeight',
    scale: 'sizes'
  }
});
exports.height = height;
var widthPropKeys = ['width', 'minWidth', 'maxWidth'];
exports.widthPropKeys = widthPropKeys;
var width = (0, _.system)({
  width: {
    property: 'width',
    scale: 'sizes',
    transform: getWidth
  },
  minWidth: {
    property: 'minWidth',
    scale: 'sizes'
  },
  maxWidth: {
    property: 'maxWidth',
    scale: 'sizes'
  }
});
exports.width = width;
var displayPropKeys = ['display', 'visibility'];
exports.displayPropKeys = displayPropKeys;
var display = (0, _.system)({
  display: true,
  visibility: true
});
exports.display = display;
var overflowPropKeys = ['overflow', 'overflowX', 'overflowY'];
exports.overflowPropKeys = overflowPropKeys;
var overflow = (0, _.system)({
  overflow: true,
  overflowX: true,
  overflowY: true
});
exports.overflow = overflow;
var layoutPropKeys = (0, _concat["default"])(_context = []).call(_context, heightPropKeys, widthPropKeys, displayPropKeys, overflowPropKeys);
exports.layoutPropKeys = layoutPropKeys;
var layout = (0, _.compose)(height, width, display, overflow);
exports.layout = layout;