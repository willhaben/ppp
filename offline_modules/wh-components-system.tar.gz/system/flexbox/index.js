"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.flexbox = exports.flexboxPropKeys = exports.flexItem = exports.flexItemPropKeys = exports.flexContainer = exports.flexboxContainerPropKeys = void 0;

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _ = require("..");

var _context;

var flexboxContainerPropKeys = ['flexDirection', 'flexWrap', 'alignItems', 'alignContent', 'justifyItems', 'justifyContent'];
exports.flexboxContainerPropKeys = flexboxContainerPropKeys;
var flexContainer = (0, _.system)({
  flexDirection: true,
  flexWrap: true,
  alignItems: true,
  alignContent: true,
  justifyItems: true,
  justifyContent: true
});
exports.flexContainer = flexContainer;
var flexItemPropKeys = ['order', 'flex', 'flexGrow', 'flexShrink', 'flexBasis', 'alignSelf', 'justifySelf'];
exports.flexItemPropKeys = flexItemPropKeys;
var flexItem = (0, _.system)({
  order: true,
  flex: true,
  flexGrow: true,
  flexShrink: true,
  flexBasis: true,
  alignSelf: true,
  justifySelf: true
});
exports.flexItem = flexItem;
var flexboxPropKeys = (0, _concat["default"])(_context = []).call(_context, flexboxContainerPropKeys, flexItemPropKeys);
exports.flexboxPropKeys = flexboxPropKeys;
var flexbox = (0, _.compose)(flexContainer, flexItem);
exports.flexbox = flexbox;