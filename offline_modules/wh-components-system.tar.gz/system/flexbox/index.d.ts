import { ResponsiveValue, SystemValue } from '..';
import { FlexDirectionProperty, FlexWrapProperty, AlignItemsProperty, AlignContentProperty, JustifyItemsProperty, JustifyContentProperty, FlexProperty, AlignSelfProperty, JustifySelfProperty } from 'csstype';
export interface FlexContainerProps {
    flexDirection?: ResponsiveValue<FlexDirectionProperty>;
    flexWrap?: ResponsiveValue<FlexWrapProperty>;
    alignItems?: ResponsiveValue<AlignItemsProperty>;
    alignContent?: ResponsiveValue<AlignContentProperty>;
    justifyItems?: ResponsiveValue<JustifyItemsProperty>;
    justifyContent?: ResponsiveValue<JustifyContentProperty>;
}
export declare const flexboxContainerPropKeys: Readonly<(keyof FlexContainerProps)[]>;
export declare const flexContainer: import("..").ParserFunction;
export interface FlexItemProps {
    order?: ResponsiveValue<SystemValue>;
    flex?: ResponsiveValue<FlexProperty<SystemValue>>;
    flexGrow?: ResponsiveValue<SystemValue>;
    flexShrink?: ResponsiveValue<SystemValue>;
    flexBasis?: ResponsiveValue<SystemValue>;
    alignSelf?: ResponsiveValue<AlignSelfProperty>;
    justifySelf?: ResponsiveValue<JustifySelfProperty>;
}
export declare const flexItemPropKeys: Readonly<(keyof FlexItemProps)[]>;
export declare const flexItem: import("..").ParserFunction;
export declare type FlexboxProps = FlexContainerProps & FlexItemProps;
export declare const flexboxPropKeys: Readonly<(keyof FlexboxProps)[]>;
export declare const flexbox: import("..").ParserFunction;
