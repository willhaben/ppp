"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.typography = exports.typographyPropKeys = void 0;

var _ = require("..");

var typographyPropKeys = ['fontFamily', 'fontSize', 'fontWeight', 'lineHeight', 'letterSpacing', 'textAlign', 'fontStyle'];
exports.typographyPropKeys = typographyPropKeys;
var typography = (0, _.system)({
  fontFamily: {
    property: 'fontFamily',
    scale: 'fontFamilies'
  },
  fontSize: {
    property: 'fontSize',
    scale: 'fontSizes'
  },
  fontWeight: {
    property: 'fontWeight',
    scale: 'fontWeights'
  },
  lineHeight: {
    property: 'lineHeight',
    scale: 'lineHeights'
  },
  letterSpacing: true,
  textAlign: true,
  fontStyle: true
});
exports.typography = typography;