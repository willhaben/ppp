import { ResponsiveValue, SystemValue } from '..';
import { TextAlignProperty, FontStyleProperty } from 'csstype';
export interface TypographyProps {
    fontFamily?: ResponsiveValue<SystemValue>;
    fontSize?: ResponsiveValue<SystemValue>;
    fontWeight?: ResponsiveValue<SystemValue>;
    lineHeight?: ResponsiveValue<SystemValue>;
    letterSpacing?: ResponsiveValue<SystemValue>;
    textAlign?: ResponsiveValue<TextAlignProperty>;
    fontStyle?: ResponsiveValue<FontStyleProperty>;
}
export declare const typographyPropKeys: Readonly<(keyof TypographyProps)[]>;
export declare const typography: import("..").ParserFunction;
