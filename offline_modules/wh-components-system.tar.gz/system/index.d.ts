import { CSSObject } from 'styled-components';
export declare type AnyObject = Record<string, unknown>;
declare type Cache = {
    breakpoints?: {
        [key: string]: string;
    };
};
interface PrintOptions {
    breakpoint: string;
}
export declare type Value = string | number | boolean | any[] | null;
export declare type ValueObject<V extends Value> = Record<string, V | undefined>;
export declare type ResponsiveValue<V extends Value> = V | ValueObject<V>;
/**
 * Note that every key in the ValueObject that is not contained in the theme breakpoints is used unconditionally without @media,
 * therefore we use 'phone' here as fallback since we don't expect this to ever be a used breakpoint name.
 *
 * We use this fallback to have a guaranteed base value for responsive css rules.
 */
export declare type ResponsiveGuaranteedValue<V extends Value> = V | (ValueObject<V> & {
    phone: V;
});
/**
 * This type guarantees always a value both on server-side-rendering and client-side-rendering.
 *
 * It should be used for values that are used in js code and not for responsive css rules.
 *
 * The 'phone' client-side-rendering fallback is defined to have a guaranteed base value for responsive css rules.
 */
export declare type ResponsiveGuaranteedValueWithSSRFallback<V extends Value> = V | {
    ssr: V;
    csr: ValueObject<V> & {
        phone: V;
    };
};
export declare type RawObject = ResponsiveValue<Value>;
export declare const isValue: <V extends Value>(object: ResponsiveValue<V>) => object is V;
export declare const isValueObject: <V extends Value>(object: ResponsiveValue<V>) => object is Record<string, V | undefined>;
export interface Theme {
    [key: string]: unknown;
    disableStyledSystemCache?: boolean;
    print: PrintOptions;
}
export declare type Props = {
    theme: Theme;
};
export interface ParserConfig {
    [key: string]: StyleFunction;
}
export declare type ParserFunction = {
    (props: Props): CSSObject;
    [key: string]: ParserFunction | Cache | ParserConfig | string[];
    config: ParserConfig;
    propNames: string[];
    cache: Cache;
};
export declare const createParser: (config: ParserConfig) => ParserFunction;
export interface CreateStyleFunctionScaleOptions {
    scale?: string;
    transform?: (n: RawObject, scale: unknown, props: Props & {
        [key: string]: unknown;
    }) => unknown;
    defaultScale?: number[];
}
export interface CreateStyleFunctionPropertyOptions extends CreateStyleFunctionScaleOptions {
    property: string;
}
export interface CreateStyleFunctionPropertiesOptions extends CreateStyleFunctionScaleOptions {
    properties: string[];
}
declare type CreateStyleFunctionOptions = CreateStyleFunctionPropertyOptions | CreateStyleFunctionPropertiesOptions;
export declare type StyleFunction = {
    (value: RawObject, scale: string | undefined, props: Props & {
        [key: string]: unknown;
    }): unknown;
    scale?: string;
    defaults?: number[] | string[];
    prop?: string | string[];
};
export declare const createStyleFunction: (config: CreateStyleFunctionOptions) => StyleFunction;
interface SystemConfig {
    [key: string]: CreateStyleFunctionOptions | StyleFunction | true;
}
export declare const system: (args?: SystemConfig) => ParserFunction;
export declare const compose: (...parsers: ParserFunction[]) => ParserFunction;
export declare type SystemValue = string | 0 | number;
export declare const objectMap: <K extends string, V1 extends unknown, V2 extends unknown>(object: { [k in K]: V1; }, callbackfn: (value: V1) => V2) => { [k_1 in K]: V2; };
export declare const responsiveMap: <V1 extends Value, V2 extends Value>(value: ResponsiveValue<V1>, callbackfn: (value: V1) => V2) => V2 | {
    [x: string]: V2 | undefined;
};
/** ignores undefined values */
export declare const responsiveSome: <V extends Value>(value: ResponsiveValue<V>, callbackfn: (value: V) => boolean) => boolean;
/** use in combination with useSortedThemeBreakpoints to fill up missing breakpoints in either of the responsive values */
export declare const responsiveCartesianProduct: <V1 extends Value, V2 extends Value>(responsiveValue1: V1 | Record<string, V1 | undefined> | undefined, responsiveValue2: V2 | Record<string, V2 | undefined> | undefined, sortedThemeBreakpoints: string[]) => ResponsiveValue<[V1 | undefined, V2 | undefined]>;
export {};
