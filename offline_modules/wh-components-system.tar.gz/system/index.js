"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty2 = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

var _sortInstanceProperty2 = require("@babel/runtime-corejs3/core-js-stable/instance/sort");

_Object$defineProperty2(exports, "__esModule", {
  value: true
});

exports.responsiveCartesianProduct = exports.responsiveSome = exports.responsiveMap = exports.objectMap = exports.compose = exports.system = exports.createStyleFunction = exports.createParser = exports.isValueObject = exports.isValue = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/define-property"));

var _defineProperties = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/define-properties"));

var _getOwnPropertyDescriptors = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors"));

var _getOwnPropertyDescriptor = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor"));

var _getOwnPropertySymbols = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols"));

var _reduce = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/reduce"));

var _findIndex = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/find-index"));

var _sort = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/sort"));

var _set = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/set"));

var _from = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/array/from"));

var _values = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/values"));

var _some = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/some"));

var _defineProperty3 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/defineProperty"));

var _forEach = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/for-each"));

var _filter = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/filter"));

var _keys = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/keys"));

var _assign = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/assign"));

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/toConsumableArray"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var _includes = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/includes"));

var _utilities = require("./utilities");

function ownKeys(object, enumerableOnly) { var keys = (0, _keys["default"])(object); if (_getOwnPropertySymbols["default"]) { var symbols = (0, _getOwnPropertySymbols["default"])(object); if (enumerableOnly) symbols = (0, _filter["default"])(symbols).call(symbols, function (sym) { return (0, _getOwnPropertyDescriptor["default"])(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context8; (0, _forEach["default"])(_context8 = ownKeys(Object(source), true)).call(_context8, function (key) { (0, _defineProperty3["default"])(target, key, source[key]); }); } else if (_getOwnPropertyDescriptors["default"]) { (0, _defineProperties["default"])(target, (0, _getOwnPropertyDescriptors["default"])(source)); } else { var _context9; (0, _forEach["default"])(_context9 = ownKeys(Object(source))).call(_context9, function (key) { (0, _defineProperty2["default"])(target, key, (0, _getOwnPropertyDescriptor["default"])(source, key)); }); } } return target; }

var printMediaQuery = "@media print";

var createMediaQuery = function createMediaQuery(width) {
  return "@media screen and (min-width: ".concat(width, "px)");
};

var createPrintMediaQuery = function createPrintMediaQuery(width) {
  return "@media screen and (min-width: ".concat(width, "px), print");
};

var getValue = function getValue(n, scale) {
  if ((0, _utilities.isString)(n)) {
    return (0, _utilities.getFromKeyPath)(scale, n, n);
  }

  return n;
};

var isValue = function isValue(object) {
  return !(0, _utilities.isObject)(object);
};

exports.isValue = isValue;

var isValueObject = function isValueObject(object) {
  return (0, _utilities.isObject)(object);
};

exports.isValueObject = isValueObject;

var createParser = function createParser(config) {
  var _context3;

  var cache = {
    breakpoints: undefined
  };

  var parse = function parse(props) {
    var multiProps = [];
    var styles = {};
    var shouldSort = false;
    var isCacheDisabled = props.theme && props.theme.disableStyledSystemCache;
    var print = props.theme && props.theme.print;

    for (var _key in props) {
      var _context;

      if (!config[_key]) {
        continue;
      }

      if ((0, _includes["default"])(multiProps).call(multiProps, _key)) {
        continue;
      }

      var _sx = config[_key]; // TODO avoid force cast

      var _raw = (0, _utilities.isArray)(_sx.prop) ? (0, _map["default"])(_context = _sx.prop).call(_context, function (p) {
        return props[p];
      }) : props[_key];

      if ((0, _utilities.isArray)(_sx.prop)) {
        var _context2;

        multiProps = (0, _concat["default"])(_context2 = []).call(_context2, (0, _toConsumableArray2["default"])(multiProps), (0, _toConsumableArray2["default"])(_sx.prop));
      } // TODO avoid force cast


      var _scale = (0, _utilities.getFromKeyPath)(props.theme, _sx.scale, _sx.defaults);

      if (isValueObject(_raw)) {
        // TODO avoid force cast
        var _breakpoints = !isCacheDisabled && cache.breakpoints || (0, _utilities.getFromKeyPath)(props.theme, 'breakpoints', {});

        cache.breakpoints = _breakpoints;

        if (_raw !== null) {
          styles = (0, _utilities.merge)(styles, parseResponsiveObject(_breakpoints, _sx, _scale, _raw, props, print));
          shouldSort = true;
        }

        continue;
      }

      (0, _assign["default"])(styles, _sx(_raw, _scale, props));
    }

    if (shouldSort) {
      styles = (0, _sortInstanceProperty2(_utilities))(styles);
    }

    return styles;
  }; // Cast needed to add index signature


  parse.config = config;
  parse.propNames = (0, _keys["default"])(config);
  parse.cache = cache;
  var keys = (0, _filter["default"])(_context3 = (0, _keys["default"])(config)).call(_context3, function (k) {
    return k !== 'config';
  });

  if (keys.length > 1) {
    (0, _forEach["default"])(keys).call(keys, function (key) {
      parse[key] = createParser((0, _defineProperty3["default"])({}, key, config[key]));
    });
  }

  return parse;
};

exports.createParser = createParser;

var parseResponsiveObject = function parseResponsiveObject(breakpoints, sx, scale, raw, props, print) {
  var printBreakpoint = print.breakpoint;
  var styles = {};

  for (var _key2 in raw) {
    if (!Object.prototype.hasOwnProperty.call(raw, _key2)) {
      continue;
    }

    var breakpoint = breakpoints[_key2];
    var _value = raw[_key2];

    if (typeof _value === 'undefined') {
      continue;
    }

    var style = sx(_value, scale, props);

    if (_key2 === printBreakpoint) {
      (0, _assign["default"])(styles, (0, _defineProperty3["default"])({}, printMediaQuery, (0, _assign["default"])({}, styles[printMediaQuery], style)));
    } else if (!breakpoint) {
      (0, _assign["default"])(styles, style);
    } else {
      var media = raw[printBreakpoint] === undefined ? createPrintMediaQuery(breakpoint) : createMediaQuery(breakpoint);
      (0, _assign["default"])(styles, (0, _defineProperty3["default"])({}, media, (0, _assign["default"])({}, styles[media], style)));
    }
  }

  return styles;
};

var configHasProperties = function configHasProperties(config) {
  return config.properties !== undefined;
};

var createStyleFunction = function createStyleFunction(config) {
  var scale = config.scale,
      _config$transform = config.transform,
      transform = _config$transform === void 0 ? getValue : _config$transform,
      defaultScale = config.defaultScale;
  var keys = configHasProperties(config) ? config.properties : [config.property];
  /* eslint-disable-next-line no-shadow */

  var styleFunction = function styleFunction(value, scale, props) {
    var result = {}; // TODO avoid force cast

    var n = transform(value, scale, props);

    if (n === null) {
      return;
    }

    (0, _forEach["default"])(keys).call(keys, function (key) {
      result[key] = n;
    });
    return result;
  };

  styleFunction.scale = scale;
  styleFunction.defaults = defaultScale;
  return styleFunction;
};

exports.createStyleFunction = createStyleFunction;

var system = function system() {
  var _context4;

  var args = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var config = {};
  (0, _forEach["default"])(_context4 = (0, _keys["default"])(args)).call(_context4, function (key) {
    var conf = args[key];

    if (conf === true) {
      config[key] = createStyleFunction({
        property: key,
        scale: key
      });
    } else if ((0, _utilities.isStyleFunction)(conf)) {
      config[key] = conf;
    } else {
      config[key] = createStyleFunction(conf);
    }
  });
  return createParser(config);
};

exports.system = system;

var compose = function compose() {
  var config = {};

  for (var _len = arguments.length, parsers = new Array(_len), _key3 = 0; _key3 < _len; _key3++) {
    parsers[_key3] = arguments[_key3];
  }

  (0, _forEach["default"])(parsers).call(parsers, function (parser) {
    if (!parser || !parser.config) {
      return;
    }

    (0, _assign["default"])(config, parser.config);
  });
  return createParser(config);
};

exports.compose = compose;

var objectMap = function objectMap(object, callbackfn) {
  var keys = (0, _keys["default"])(object);
  var newObject = {};
  (0, _forEach["default"])(keys).call(keys, function (k) {
    newObject[k] = callbackfn(object[k]);
  });
  return newObject;
};

exports.objectMap = objectMap;

var responsiveMap = function responsiveMap(value, callbackfn) {
  if (isValue(value)) {
    return callbackfn(value);
  } else {
    return objectMap(value, function (v) {
      return typeof v === 'undefined' ? undefined : callbackfn(v);
    });
  }
};
/** ignores undefined values */


exports.responsiveMap = responsiveMap;

var responsiveSome = function responsiveSome(value, callbackfn) {
  if (isValue(value)) {
    return callbackfn(value);
  } else {
    var _context5;

    return (0, _some["default"])(_context5 = (0, _values["default"])(value)).call(_context5, function (v) {
      return typeof v === 'undefined' ? false : callbackfn(v);
    });
  }
}; // a breakpoint not contained in the theme is used as fallback breakpoint by the system


exports.responsiveSome = responsiveSome;

var containsBreakpointNotContainedInTheme = function containsBreakpointNotContainedInTheme(responsiveValue, sortedThemeBreakpoints) {
  var _context6;

  return isValue(responsiveValue) ? true : (0, _some["default"])(_context6 = (0, _keys["default"])(responsiveValue)).call(_context6, function (b) {
    return !(0, _includes["default"])(sortedThemeBreakpoints).call(sortedThemeBreakpoints, b);
  });
};
/** use in combination with useSortedThemeBreakpoints to fill up missing breakpoints in either of the responsive values */


var responsiveCartesianProduct = function responsiveCartesianProduct(responsiveValue1, responsiveValue2, sortedThemeBreakpoints) {
  var _context7;

  if (typeof responsiveValue1 === 'undefined' || isValue(responsiveValue1)) {
    if (typeof responsiveValue2 !== 'undefined') {
      if (containsBreakpointNotContainedInTheme(responsiveValue2, sortedThemeBreakpoints)) {
        return responsiveMap(responsiveValue2, function (v2) {
          return [responsiveValue1, v2];
        });
      } else {
        // in case responsiveValue1 is a simple value and responsiveValue2 does not contain a fallback breakpoint, we have to manually inject the fallback breakpoint - its name is not important as long as it is no regular breakpoint (we use 'fallback' here)
        return _objectSpread(_objectSpread({}, responsiveMap(responsiveValue2, function (v2) {
          return [responsiveValue1, v2];
        })), {}, {
          fallback: [responsiveValue1, undefined]
        });
      }
    } else {
      return [responsiveValue1, responsiveValue2];
    }
  }

  if (typeof responsiveValue2 === 'undefined' || isValue(responsiveValue2)) {
    if (containsBreakpointNotContainedInTheme(responsiveValue1, sortedThemeBreakpoints)) {
      return responsiveMap(responsiveValue1, function (v1) {
        return [v1, responsiveValue2];
      });
    } else {
      // in case responsiveValue2 is a simple value and responsiveValue1 does not contain a fallback breakpoint, we have to manually inject the fallback breakpoint - its name is not important as long as it is no regular breakpoint (we use 'fallback' here)
      return _objectSpread(_objectSpread({}, responsiveMap(responsiveValue1, function (v1) {
        return [v1, responsiveValue2];
      })), {}, {
        fallback: [undefined, responsiveValue2]
      });
    }
  }

  var breakpoints1 = (0, _keys["default"])(responsiveValue1);
  var breakpoints2 = (0, _keys["default"])(responsiveValue2);
  var combinedBreakpoints = (0, _from["default"])(new _set["default"]((0, _concat["default"])(_context7 = []).call(_context7, (0, _toConsumableArray2["default"])(breakpoints1), (0, _toConsumableArray2["default"])(breakpoints2)))); // breakpoints not contained in sortedThemeBreakpoints (like 'phone') will be sorted first, because findIndex returns -1 for not found elements

  var sortedResponsiveValueBreakpoints = (0, _sort["default"])(combinedBreakpoints).call(combinedBreakpoints, function (a, b) {
    return (0, _findIndex["default"])(sortedThemeBreakpoints).call(sortedThemeBreakpoints, function (element) {
      return element === a;
    }) - (0, _findIndex["default"])(sortedThemeBreakpoints).call(sortedThemeBreakpoints, function (element) {
      return element === b;
    });
  }); // TypeScript workaround, so reduce can access the responsive values as Record, which is actually already known here but forgotten because of the closure

  var responsiveValueObject1 = responsiveValue1;
  var responsiveValueObject2 = responsiveValue2;
  var result = (0, _reduce["default"])(sortedResponsiveValueBreakpoints).call(sortedResponsiveValueBreakpoints, function (previousValue, currentValue) {
    var currentValue1 = typeof responsiveValueObject1[currentValue] === 'undefined' ? previousValue.lastValue1 : responsiveValueObject1[currentValue];
    var currentValue2 = typeof responsiveValueObject2[currentValue] === 'undefined' ? previousValue.lastValue2 : responsiveValueObject2[currentValue];
    previousValue.result[currentValue] = [currentValue1, currentValue2];
    previousValue.lastValue1 = currentValue1;
    previousValue.lastValue2 = currentValue2;
    return previousValue;
  }, {
    result: {},
    lastValue1: undefined,
    lastValue2: undefined
  }).result;
  return result;
};

exports.responsiveCartesianProduct = responsiveCartesianProduct;