import { ResponsiveValue } from '..';
export interface AnimationProps {
    transition?: ResponsiveValue<string>;
}
export declare const animationPropKeys: Readonly<(keyof AnimationProps)[]>;
export declare const animation: import("..").ParserFunction;
