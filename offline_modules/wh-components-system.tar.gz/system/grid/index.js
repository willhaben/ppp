"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.grid = exports.gridPropKeys = void 0;

var _ = require("..");

var gridPropKeys = ['gridGap', 'gridColumnGap', 'gridRowGap', 'gridColumn', 'gridRow', 'gridAutoFlow', 'gridAutoColumns', 'gridAutoRows', 'gridTemplateColumns', 'gridTemplateRows', 'gridTemplateAreas', 'gridArea'];
exports.gridPropKeys = gridPropKeys;
var grid = (0, _.system)({
  gridGap: {
    property: 'gridGap',
    scale: 'space'
  },
  gridColumnGap: {
    property: 'gridColumnGap',
    scale: 'space'
  },
  gridRowGap: {
    property: 'gridRowGap',
    scale: 'space'
  },
  gridColumn: true,
  gridRow: true,
  gridAutoFlow: true,
  gridAutoColumns: true,
  gridAutoRows: true,
  gridTemplateColumns: true,
  gridTemplateRows: true,
  gridTemplateAreas: true,
  gridArea: true
});
exports.grid = grid;