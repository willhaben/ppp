import { ResponsiveValue, SystemValue } from '..';
export interface GridProps {
    gridGap?: ResponsiveValue<SystemValue>;
    gridColumnGap?: ResponsiveValue<SystemValue>;
    gridRowGap?: ResponsiveValue<SystemValue>;
    gridColumn?: ResponsiveValue<SystemValue>;
    gridRow?: ResponsiveValue<SystemValue>;
    gridAutoFlow?: ResponsiveValue<SystemValue>;
    gridAutoColumns?: ResponsiveValue<SystemValue>;
    gridAutoRows?: ResponsiveValue<SystemValue>;
    gridTemplateColumns?: ResponsiveValue<SystemValue>;
    gridTemplateRows?: ResponsiveValue<SystemValue>;
    gridTemplateAreas?: ResponsiveValue<SystemValue>;
    gridArea?: ResponsiveValue<SystemValue>;
}
export declare const gridPropKeys: Readonly<(keyof GridProps)[]>;
export declare const grid: import("..").ParserFunction;
