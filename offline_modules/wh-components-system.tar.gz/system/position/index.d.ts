import { ResponsiveValue, SystemValue } from '..';
import { PositionProperty } from 'csstype';
export interface PositionProps {
    position?: ResponsiveValue<PositionProperty>;
    zIndex?: ResponsiveValue<SystemValue>;
    top?: ResponsiveValue<SystemValue>;
    right?: ResponsiveValue<SystemValue>;
    bottom?: ResponsiveValue<SystemValue>;
    left?: ResponsiveValue<SystemValue>;
}
export declare const positionPropKeys: Readonly<(keyof PositionProps)[]>;
export declare const position: import("..").ParserFunction;
