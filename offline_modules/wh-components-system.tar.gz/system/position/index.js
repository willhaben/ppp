"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.position = exports.positionPropKeys = void 0;

var _ = require("..");

var positionPropKeys = ['zIndex', 'position', 'top', 'right', 'bottom', 'left'];
exports.positionPropKeys = positionPropKeys;
var position = (0, _.system)({
  position: true,
  zIndex: {
    property: 'zIndex',
    scale: 'zIndices'
  },
  top: {
    property: 'top',
    scale: 'space'
  },
  right: {
    property: 'right',
    scale: 'space'
  },
  bottom: {
    property: 'bottom',
    scale: 'space'
  },
  left: {
    property: 'left',
    scale: 'space'
  }
});
exports.position = position;