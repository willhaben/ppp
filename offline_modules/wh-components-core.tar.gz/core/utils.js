"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.wait = exports.getFocusableElements = void 0;

var _setTimeout2 = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/set-timeout"));

var _promise = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/promise"));

var _filter = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/filter"));

var _from = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/array/from"));

var focusableElList = ['a[href]', 'button:not([disabled])', '*[tabindex]:not([disabled]):not([aria-disabled])'];

var getFocusableElements = function getFocusableElements(container) {
  var elements = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : focusableElList;
  var keyboardOnly = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

  if (container) {
    var focusableElements = (0, _from["default"])(container.querySelectorAll(elements.join())); // filter out elements with display: none

    focusableElements = (0, _filter["default"])(focusableElements).call(focusableElements, function (el) {
      return window.getComputedStyle(el).display !== 'none';
    });

    if (keyboardOnly) {
      // filter out elements that are not reachable by pressing tab
      focusableElements = (0, _filter["default"])(focusableElements).call(focusableElements, function (el) {
        return el.getAttribute('tabindex') !== '-1';
      });
    }

    return focusableElements;
  }

  return [];
};

exports.getFocusableElements = getFocusableElements;

var wait = function wait(milliseconds) {
  return new _promise["default"](function (resolve) {
    return (0, _setTimeout2["default"])(resolve, milliseconds);
  });
};

exports.wait = wait;