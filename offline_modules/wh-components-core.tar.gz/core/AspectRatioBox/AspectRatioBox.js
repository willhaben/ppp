"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.AspectRatioBox = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _Box = require("../Box/Box");

var AspectRatioBox = function AspectRatioBox(_ref) {
  var _ref$ratio = _ref.ratio,
      ratio = _ref$ratio === void 0 ? 4 / 3 : _ref$ratio,
      children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["ratio", "children"]);
  return /*#__PURE__*/_react["default"].createElement(Container, (0, _extends2["default"])({}, props, {
    ratio: ratio
  }), /*#__PURE__*/_react["default"].cloneElement(children, {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      height: '100%',
      width: '100%'
    }
  }));
};

exports.AspectRatioBox = AspectRatioBox;
AspectRatioBox.defaultProps = {
  position: 'relative'
};
var Container = (0, _styledComponents["default"])(_Box.Box).withConfig({
  displayName: "AspectRatioBox__Container",
  componentId: "pw812s-0"
})(["&:before{content:'';height:0;display:block;padding-bottom:", "%;}"], function (p) {
  return 1 / p.ratio * 100;
});