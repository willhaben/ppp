import { FunctionComponent, ReactElement } from 'react';
import { TestProps } from '../common';
import { SpaceProps } from '@wh-components/system/space';
import { WidthProps, DisplayProps } from '@wh-components/system/layout';
import { PositionProps } from '@wh-components/system/position';
import { FlexItemProps } from '@wh-components/system/flexbox';
import { BorderProps } from '@wh-components/system/border';
interface AspectRatioProps extends TestProps, SpaceProps, WidthProps, DisplayProps, PositionProps, FlexItemProps, BorderProps {
    ratio: number;
    children: ReactElement;
}
export declare const AspectRatioBox: FunctionComponent<AspectRatioProps>;
export {};
