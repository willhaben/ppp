export declare const ExternalStyle: import("styled-components").GlobalStyleComponent<{}, import("styled-components").DefaultTheme>;
