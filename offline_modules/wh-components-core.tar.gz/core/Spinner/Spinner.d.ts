import { ResponsiveValue } from '@wh-components/system';
import { TestProps } from '../common';
import { SpaceProps } from '@wh-components/system/space';
import { DisplayProps } from '@wh-components/system/layout';
import { PositionProps } from '@wh-components/system/position';
import { FlexboxProps } from '@wh-components/system/flexbox';
export declare type SpinnerSizeType = 'small' | 'medium' | 'large';
export declare type SpinnerColorTypes = 'primary' | 'secondary' | 'complimentary' | 'accent';
export declare type SpinnerSpeedTypes = 'slow' | 'medium' | 'fast';
interface SpinnerProps extends TestProps, SpaceProps, DisplayProps, PositionProps, FlexboxProps {
    size?: ResponsiveValue<SpinnerSizeType>;
    color?: SpinnerColorTypes;
    speed?: SpinnerSpeedTypes;
}
export declare const Spinner: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {
    'data-testid': string | undefined;
} & SpinnerProps, "data-testid">;
export {};
