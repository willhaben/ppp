"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Spinner = void 0;

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _variant = _interopRequireDefault(require("@wh-components/system/variant"));

var _system = require("@wh-components/system");

var _common = require("../common");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _position = require("@wh-components/system/position");

var _flexbox = require("@wh-components/system/flexbox");

var spinnerSizes = (0, _variant["default"])({
  scale: 'components.spinner.sizes',
  prop: 'size'
});
var spinnerColors = (0, _variant["default"])({
  scale: 'components.spinner.colors',
  prop: 'color'
});
var spinnerSpeeds = (0, _variant["default"])({
  scale: 'components.spinner.speeds',
  prop: 'speed'
});
var rotate = (0, _styledComponents.keyframes)(["to{transform:rotate(360deg);}"]);

var Spinner = _styledComponents["default"].div.attrs(_common.testIdAttribute).withConfig({
  displayName: "Spinner",
  componentId: "sc-1wl2oxn-0"
})(["border-radius:50%;border:4px solid ", ";border-left-color:", ";animation:", " 1s linear infinite;", ""], function (p) {
  return p.theme.colors.palette.dove;
}, function (p) {
  return p.theme.colors.palette.primary.main;
}, rotate, (0, _system.compose)(spinnerSizes, spinnerColors, spinnerSpeeds, _space.space, _layout.display, _position.position, _flexbox.flexbox));

exports.Spinner = Spinner;
Spinner.defaultProps = {
  size: 'medium',
  color: 'primary',
  speed: 'medium'
};