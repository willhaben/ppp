export declare const useActiveIndex: (focusableItems: HTMLElement[]) => {
    activeIndex: number;
    focusOnFirstItem: () => void;
    focusAtIndex: (index: number) => void;
    focusOnLastItem: () => void;
    handleKeyDown: (event: React.KeyboardEvent) => void;
};
