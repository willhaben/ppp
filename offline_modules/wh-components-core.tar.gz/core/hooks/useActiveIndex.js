"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.useActiveIndex = void 0;

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/slicedToArray"));

var _react = require("react");

var useActiveIndex = function useActiveIndex(focusableItems) {
  var _useState = (0, _react.useState)(-1),
      _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
      activeIndex = _useState2[0],
      setActiveIndex = _useState2[1];

  (0, _react.useEffect)(function () {
    if (activeIndex >= 0) {
      var _focusableItems$activ;

      (_focusableItems$activ = focusableItems[activeIndex]) === null || _focusableItems$activ === void 0 ? void 0 : _focusableItems$activ.focus();
    }
  });

  var focusOnFirstItem = function focusOnFirstItem() {
    setActiveIndex(0);
  };

  var focusAtIndex = function focusAtIndex(index) {
    setActiveIndex(index);
  };

  var focusOnLastItem = function focusOnLastItem() {
    setActiveIndex(focusableItems.length - 1);
  };

  var handleKeyDown = function handleKeyDown(event) {
    var count = focusableItems.length;
    var nextIndex;

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      nextIndex = (activeIndex + 1) % count;
      focusAtIndex(nextIndex);
    } else if (event.key === 'ArrowUp') {
      event.preventDefault();
      nextIndex = (activeIndex - 1 + count) % count;
      focusAtIndex(nextIndex);
    } else if (event.key === 'Home') {
      focusOnFirstItem();
    } else if (event.key === 'End') {
      focusOnLastItem();
    } else if (event.key === 'Tab') {
      event.preventDefault();
    }
  };

  return {
    activeIndex: activeIndex,
    focusOnFirstItem: focusOnFirstItem,
    focusAtIndex: focusAtIndex,
    focusOnLastItem: focusOnLastItem,
    handleKeyDown: handleKeyDown
  };
};

exports.useActiveIndex = useActiveIndex;