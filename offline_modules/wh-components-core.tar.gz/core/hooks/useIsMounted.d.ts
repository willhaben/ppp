export declare const useIsMounted: () => import("react").MutableRefObject<boolean>;
