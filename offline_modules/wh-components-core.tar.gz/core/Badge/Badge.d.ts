import { FunctionComponent } from 'react';
import { IconType } from '@wh-components/icons/utilities/createSvgIcon';
import { TestProps } from '../common';
import { SpaceProps } from '@wh-components/system/space';
import { DisplayProps } from '@wh-components/system/layout';
import { PositionProps } from '@wh-components/system/position';
import { TypographyProps } from '@wh-components/system/typography';
import { FlexContainerProps } from '@wh-components/system/flexbox';
export declare type BadgeColorType = string;
export declare type BadgeVariantType = 'solid' | 'outline';
interface BadgeProps {
    /** Main color of the badge. For solid variant, this is the background color, for outline variant, this is the border and text color. */
    color1?: BadgeColorType;
    /** Secondary color of the badge. For solid variant, this is the text color, for outline variant, this is the background color. */
    color2?: BadgeColorType;
    variant?: BadgeVariantType;
    Icon?: IconType;
    children: string;
}
declare type ContainerProps = TestProps & SpaceProps & DisplayProps & PositionProps & TypographyProps & FlexContainerProps;
export declare const Badge: FunctionComponent<BadgeProps & ContainerProps>;
export {};
