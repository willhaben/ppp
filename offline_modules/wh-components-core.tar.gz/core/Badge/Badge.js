"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Badge = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _system = require("@wh-components/system");

var _common = require("../common");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _position = require("@wh-components/system/position");

var _typography = require("@wh-components/system/typography");

var _flexbox = require("@wh-components/system/flexbox");

var badgeColorSolid = (0, _system.system)({
  color1: {
    properties: ['borderColor', 'background'],
    scale: 'colors'
  },
  color2: {
    property: 'color',
    scale: 'colors'
  }
});
var badgeColorOutline = (0, _system.system)({
  color1: {
    properties: ['borderColor', 'color'],
    scale: 'colors'
  },
  color2: {
    property: 'background',
    scale: 'colors'
  }
});
var badgeVariantColorMap = {
  solid: badgeColorSolid,
  outline: badgeColorOutline
};

var Container = _styledComponents["default"].span.attrs(_common.testIdAttribute).withConfig({
  displayName: "Badge__Container",
  componentId: "sc-1s9pvno-0"
})(["display:inline-flex;align-items:center;padding:0.25em 0.75em;border:1px solid;border-radius:2em;user-select:none;", " ", ""], (0, _system.compose)(_space.space, _layout.display, _position.position, _typography.typography, _flexbox.flexContainer), function (p) {
  return badgeVariantColorMap[p.variant];
});

var Badge = function Badge(_ref) {
  var _ref$color = _ref.color1,
      color1 = _ref$color === void 0 ? 'palette.primary.main' : _ref$color,
      _ref$color2 = _ref.color2,
      color2 = _ref$color2 === void 0 ? 'palette.white' : _ref$color2,
      _ref$variant = _ref.variant,
      variant = _ref$variant === void 0 ? 'solid' : _ref$variant,
      _ref$fontSize = _ref.fontSize,
      fontSize = _ref$fontSize === void 0 ? 's' : _ref$fontSize,
      Icon = _ref.Icon,
      children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["color1", "color2", "variant", "fontSize", "Icon", "children"]);
  var iconProps = {
    color: 'inherit',
    marginRight: 'xs',
    'aria-hidden': true
  };
  return /*#__PURE__*/_react["default"].createElement(Container, (0, _extends2["default"])({}, props, {
    color1: color1,
    color2: color2,
    variant: variant,
    fontSize: fontSize
  }), Icon && /*#__PURE__*/(0, _react.createElement)(Icon, iconProps), children);
};

exports.Badge = Badge;