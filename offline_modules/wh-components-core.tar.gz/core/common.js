"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.idPropKeys = exports.classNamePropKeys = exports.testIdAttribute = void 0;

var testIdAttribute = function testIdAttribute(props) {
  return {
    'data-testid': props.testId
  };
};

exports.testIdAttribute = testIdAttribute;
var classNamePropKeys = ['className'];
exports.classNamePropKeys = classNamePropKeys;
var idPropKeys = ['id'];
exports.idPropKeys = idPropKeys;