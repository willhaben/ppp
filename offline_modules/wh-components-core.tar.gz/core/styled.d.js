"use strict";

require("styled-components");