"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Grid = void 0;

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/slicedToArray"));

var _values = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/values"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/toConsumableArray"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var _keys = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/keys"));

var _forEach = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/for-each"));

var _from = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/array/from"));

var _react = _interopRequireDefault(require("react"));

var _Box = require("../Box/Box");

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _layout = require("@wh-components/system/layout");

var _system = require("@wh-components/system");

var _breakpoints = require("../theme/breakpoints");

var _utilities = require("@wh-components/system/utilities");

var _animation = require("@wh-components/system/animation");

var _background = require("@wh-components/system/background");

var _border = require("@wh-components/system/border");

var _color = require("@wh-components/system/color");

var _flexbox = require("@wh-components/system/flexbox");

var _position = require("@wh-components/system/position");

var _shadow = require("@wh-components/system/shadow");

var _space = require("@wh-components/system/space");

var _typography = require("@wh-components/system/typography");

var generateIndexArray = function generateIndexArray(from, to) {
  if (from > to) {
    ;
    var _ref = [to, from];
    from = _ref[0];
    to = _ref[1];
  }

  return (0, _from["default"])({
    length: to - from + 1
  }, function (_, i) {
    return i + from;
  });
};

var generateRowTemplateArea = function generateRowTemplateArea(row, columnCount) {
  // in css gridTemplateAreas, all rows need to have the same column count
  row.length = columnCount;
  return "\"".concat((0, _from["default"])(row, function (item) {
    return item || '.';
  }).join(' '), "\"");
};

var generateCssGridTemplateAreas = function generateCssGridTemplateAreas(areaTemplate) {
  var _context;

  var areas = [];
  var maxColumnCount = 0;
  (0, _forEach["default"])(_context = (0, _keys["default"])(areaTemplate)).call(_context, function (a) {
    var spans = areaTemplate[a];
    maxColumnCount = spans ? Math.max(maxColumnCount, Math.max(spans.startColumn, spans.endColumn)) : maxColumnCount;
    var columns = spans ? generateIndexArray(spans.startColumn, spans.endColumn) : [0];
    var rows = spans ? generateIndexArray(spans.startRow, spans.endRow) : [0];
    (0, _forEach["default"])(columns).call(columns, function (c) {
      (0, _forEach["default"])(rows).call(rows, function (r) {
        if (!areas[r - 1]) {
          areas[r - 1] = [];
        }

        areas[r - 1][c - 1] = a;
      });
    });
  });
  return (0, _map["default"])(areas).call(areas, function (areaRow) {
    return generateRowTemplateArea(areaRow, maxColumnCount);
  }).join('\n');
};

var findMaximumColumn = function findMaximumColumn(areaTemplate) {
  var _context2;

  return Math.max.apply(Math, (0, _toConsumableArray2["default"])((0, _map["default"])(_context2 = (0, _values["default"])(areaTemplate)).call(_context2, function (v) {
    return v ? Math.max(v.startColumn, v.endColumn) : 0;
  })));
};

var findMaximumRow = function findMaximumRow(areaTemplate) {
  var _context3;

  return Math.max.apply(Math, (0, _toConsumableArray2["default"])((0, _map["default"])(_context3 = (0, _values["default"])(areaTemplate)).call(_context3, function (v) {
    return v ? Math.max(v.startRow, v.endRow) : 0;
  })));
}; // always applying grid gap workaround on IE11 for simplicity


var msGapCorrection = function msGapCorrection(indexOrSpan, useGridGap) {
  return useGridGap ? indexOrSpan * 2 - 1 : indexOrSpan;
};

var msGridRow = function msGridRow(startRow, endRow, useGridGap) {
  return msGapCorrection(Math.min(startRow, endRow), useGridGap);
};

var msGridRowSpan = function msGridRowSpan(startRow, endRow, useGridGap) {
  return msGapCorrection(Math.abs(endRow - startRow) + 1, useGridGap);
};

var msGridColumn = function msGridColumn(startColumn, endColumn, useGridGap) {
  return msGapCorrection(Math.min(startColumn, endColumn), useGridGap);
};

var msGridColumnSpan = function msGridColumnSpan(startColumn, endColumn, useGridGap) {
  return msGapCorrection(Math.abs(endColumn - startColumn) + 1, useGridGap);
};

var msGridContainerRowsCss = (0, _system.system)({
  responsiveRowSizesAndGridGap: {
    property: '-ms-grid-rows',
    scale: 'space',
    transform: function transform(n, _scale, _props) {
      var _ref2 = n,
          _ref3 = (0, _slicedToArray2["default"])(_ref2, 2),
          rowSizes = _ref3[0],
          gridGap = _ref3[1];

      return (rowSizes !== null && rowSizes !== void 0 ? rowSizes : []).join(" ".concat(parseGridGap(_scale, gridGap), " "));
    }
  }
});
var msGridContainerColumnsCss = (0, _system.system)({
  responsiveColumnSizesAndGridGap: {
    property: '-ms-grid-columns',
    scale: 'space',
    transform: function transform(n, _scale, _props) {
      var _ref4 = n,
          _ref5 = (0, _slicedToArray2["default"])(_ref4, 2),
          columnSizes = _ref5[0],
          gridGap = _ref5[1];

      return (columnSizes !== null && columnSizes !== void 0 ? columnSizes : []).join(" ".concat(parseGridGap(_scale, gridGap), " "));
    }
  }
});

var parseGridGap = function parseGridGap(_scale, gridGap) {
  if (typeof gridGap === 'undefined') {
    return '0px';
  }

  var scaledGap = (0, _utilities.getFromKeyPath)(_scale, gridGap);

  if (typeof scaledGap !== 'undefined') {
    return "".concat(scaledGap, "px");
  }

  return gridGap;
};

var msGridAreaRowCss = (0, _system.system)({
  areaTemplate: {
    property: '-ms-grid-row',
    transform: function transform(n, _scale, props) {
      var _props$area;

      var areaTemplate = n[0];
      var area = (_props$area = props === null || props === void 0 ? void 0 : props.area) !== null && _props$area !== void 0 ? _props$area : [];
      var areaTemplateArea = areaTemplate[area];
      var result = areaTemplateArea ? msGridRow(areaTemplateArea.startRow, areaTemplateArea.endRow, true) : undefined;

      if (!result) {
        return undefined;
      } else {
        return "".concat(result); // avoid styled-components appending "px"
      }
    }
  }
});
var msGridAreaRowSpanCss = (0, _system.system)({
  areaTemplate: {
    property: '-ms-grid-row-span',
    transform: function transform(n, _scale, props) {
      var _props$area2;

      var areaTemplate = n[0];
      var area = (_props$area2 = props === null || props === void 0 ? void 0 : props.area) !== null && _props$area2 !== void 0 ? _props$area2 : [];
      var areaTemplateArea = areaTemplate[area];
      var result = areaTemplateArea ? msGridRowSpan(areaTemplateArea.startRow, areaTemplateArea.endRow, true) : undefined;

      if (!result) {
        return undefined;
      } else {
        return "".concat(result); // avoid styled-components appending "px"
      }
    }
  }
});
var msGridAreaColumnCss = (0, _system.system)({
  areaTemplate: {
    property: '-ms-grid-column',
    transform: function transform(n, _scale, props) {
      var _props$area3;

      var areaTemplate = n[0];
      var area = (_props$area3 = props === null || props === void 0 ? void 0 : props.area) !== null && _props$area3 !== void 0 ? _props$area3 : [];
      var areaTemplateArea = areaTemplate[area];
      var result = areaTemplateArea ? msGridColumn(areaTemplateArea.startColumn, areaTemplateArea.endColumn, true) : undefined;

      if (!result) {
        return undefined;
      } else {
        return "".concat(result); // avoid styled-components appending "px"
      }
    }
  }
});
var msGridAreaColumnSpanCss = (0, _system.system)({
  areaTemplate: {
    property: '-ms-grid-column-span',
    transform: function transform(n, _scale, props) {
      var _props$area4;

      var areaTemplate = n[0];
      var area = (_props$area4 = props === null || props === void 0 ? void 0 : props.area) !== null && _props$area4 !== void 0 ? _props$area4 : [];
      var areaTemplateArea = areaTemplate[area];
      var result = areaTemplateArea ? msGridColumnSpan(areaTemplateArea.startColumn, areaTemplateArea.endColumn, true) : undefined;

      if (!result) {
        return undefined;
      } else {
        return "".concat(result); // avoid styled-components appending "px"
      }
    }
  }
});
var hideArea = (0, _system.system)({
  areaTemplate: {
    property: 'display',
    transform: function transform(n, _scale, props) {
      var _props$area5;

      var areaTemplate = n[0];
      var area = (_props$area5 = props === null || props === void 0 ? void 0 : props.area) !== null && _props$area5 !== void 0 ? _props$area5 : [];
      var areaTemplateArea = areaTemplate[area];

      if (areaTemplateArea) {
        return 'block';
      } else {
        return 'none';
      }
    }
  }
});
var GridContainer = (0, _styledComponents["default"])(_Box.Box).withConfig({
  displayName: "Grid__GridContainer",
  componentId: "dtcl2s-0"
})(["display:-ms-grid;", " ", ""], msGridContainerRowsCss, msGridContainerColumnsCss);
var GridArea = (0, _styledComponents["default"])(_Box.Box).withConfig({
  displayName: "Grid__GridArea",
  componentId: "dtcl2s-1"
})(["", " ", " ", " ", " ", ""], msGridAreaRowCss, msGridAreaRowSpanCss, msGridAreaColumnCss, msGridAreaColumnSpanCss, hideArea);

var Grid = function Grid(_ref6) {
  var _context4;

  var areaComponents = _ref6.areaComponents,
      areaTemplate = _ref6.areaTemplate,
      rowSizes = _ref6.rowSizes,
      columnSizes = _ref6.columnSizes,
      gridGap = _ref6.gridGap,
      testId = _ref6.testId,
      className = _ref6.className,
      layoutProps = (0, _objectWithoutProperties2["default"])(_ref6, ["areaComponents", "areaTemplate", "rowSizes", "columnSizes", "gridGap", "testId", "className"]);
  var sortedBreakpoints = (0, _breakpoints.useSortedThemeBreakpoints)();
  var responsiveRowSizesAndGridGap = (0, _system.responsiveCartesianProduct)(rowSizes, gridGap, sortedBreakpoints);
  var responsiveColumnSizesAndGridGap = (0, _system.responsiveCartesianProduct)(columnSizes, gridGap, sortedBreakpoints);
  var responsiveAreaTemplateAndRowSizes = (0, _system.responsiveCartesianProduct)(areaTemplate, rowSizes, sortedBreakpoints);

  if ((0, _system.responsiveSome)(responsiveAreaTemplateAndRowSizes, function (_ref7) {
    var _ref8 = (0, _slicedToArray2["default"])(_ref7, 2),
        areaTemplate2 = _ref8[0],
        rowSizes2 = _ref8[1];

    var maxRow = typeof areaTemplate2 === 'undefined' ? 0 : findMaximumRow(areaTemplate2[0]);
    return typeof rowSizes2 === 'undefined' || maxRow > rowSizes2.length;
  })) {
    console.error('rowSizes needs to have enough elements to cover all elements in the areaTemplate for every breakpoint');
    return null;
  }

  var responsiveAreaTemplateAndColumnSizes = (0, _system.responsiveCartesianProduct)(areaTemplate, columnSizes, sortedBreakpoints);

  if ((0, _system.responsiveSome)(responsiveAreaTemplateAndColumnSizes, function (_ref9) {
    var _ref10 = (0, _slicedToArray2["default"])(_ref9, 2),
        areaTemplate2 = _ref10[0],
        columnSizes2 = _ref10[1];

    var maxColumn = typeof areaTemplate2 === 'undefined' ? 0 : findMaximumColumn(areaTemplate2[0]);
    return typeof columnSizes2 === 'undefined' || maxColumn > columnSizes2.length;
  })) {
    console.error('columnSizes needs to have enough elements to cover all elements in the areaTemplate for every breakpoint');
    return null;
  }

  var _separateWrapperAndRe = separateWrapperAndRemainingProps(layoutProps),
      wrapperProps = _separateWrapperAndRe.wrapperProps;

  return /*#__PURE__*/_react["default"].createElement(GridContainer, (0, _extends2["default"])({}, wrapperProps, {
    display: "grid",
    gridTemplateAreas: (0, _system.responsiveMap)(areaTemplate, function (at) {
      return generateCssGridTemplateAreas(at[0]);
    }),
    gridTemplateRows: (0, _system.responsiveMap)(rowSizes, function (s) {
      return s.join(' ');
    }),
    gridTemplateColumns: (0, _system.responsiveMap)(columnSizes, function (s) {
      return s.join(' ');
    }),
    gridGap: gridGap,
    rowSizes: rowSizes,
    columnSizes: columnSizes,
    responsiveRowSizesAndGridGap: responsiveRowSizesAndGridGap,
    responsiveColumnSizesAndGridGap: responsiveColumnSizesAndGridGap,
    testId: testId,
    className: className
  }), (0, _map["default"])(_context4 = (0, _keys["default"])(areaComponents)).call(_context4, function (area) {
    return (
      /*#__PURE__*/
      // INFO we do not render the areaComponents directly as children, but wrap them in a div, so the passed areaComponents can have any stylings of their own - don't forget to use height:100% for areaComponents to fill out the grid areas
      _react["default"].createElement(GridArea, {
        key: area,
        gridArea: area,
        area: area,
        areaTemplate: areaTemplate
      }, areaComponents[area])
    );
  }));
}; // this avoids setting props like `name` on the wrapper div


exports.Grid = Grid;

var separateWrapperAndRemainingProps = function separateWrapperAndRemainingProps(props) {
  var _context5;

  var extract = (0, _concat["default"])(_context5 = []).call(_context5, (0, _toConsumableArray2["default"])(_animation.animationPropKeys), (0, _toConsumableArray2["default"])(_background.backgroundPropKeys), (0, _toConsumableArray2["default"])(_border.borderPropKeys), (0, _toConsumableArray2["default"])(_color.colorPropKeys), (0, _toConsumableArray2["default"])(_flexbox.flexboxPropKeys), (0, _toConsumableArray2["default"])(_layout.heightPropKeys), (0, _toConsumableArray2["default"])(_layout.widthPropKeys), (0, _toConsumableArray2["default"])(_layout.overflowPropKeys), (0, _toConsumableArray2["default"])(_position.positionPropKeys), (0, _toConsumableArray2["default"])(_shadow.shadowPropKeys), (0, _toConsumableArray2["default"])(_space.spacePropKeys), (0, _toConsumableArray2["default"])(_typography.typographyPropKeys));

  var _extractProps = (0, _utilities.extractProps)(props, extract),
      wrapperProps = _extractProps.extractedProps,
      remainingProps = _extractProps.remainingProps;

  return {
    wrapperProps: wrapperProps,
    remainingProps: remainingProps
  };
};