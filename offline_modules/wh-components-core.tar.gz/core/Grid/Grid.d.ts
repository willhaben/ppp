import { ReactElement } from 'react';
import { BoxProps } from '../Box/Box';
import { NoChildrenProps, TestProps } from '../common';
import { DisplayProps } from '@wh-components/system/layout';
import { GridProps as SystemGridProps } from '@wh-components/system/grid';
import { ResponsiveValue, ResponsiveGuaranteedValue } from '@wh-components/system';
export interface GridProps<Area extends string> extends NoChildrenProps, LayoutProps, TestProps {
    areaComponents: {
        [a in Area]: ReactElement;
    };
    areaTemplate: ResponsiveGuaranteedValue<[AreaTemplate<Area>]>;
    rowSizes: ResponsiveGuaranteedValue<string[]>;
    columnSizes: ResponsiveGuaranteedValue<string[]>;
    gridGap?: ResponsiveValue<string>;
    className?: string;
}
declare type LayoutProps = Omit<BoxProps, keyof DisplayProps | keyof SystemGridProps>;
export declare type AreaTemplate<Area extends string> = {
    [a in Area]: {
        startColumn: number;
        endColumn: number;
        startRow: number;
        endRow: number;
    } | null;
};
export declare const Grid: <Area extends string>({ areaComponents, areaTemplate, rowSizes, columnSizes, gridGap, testId, className, ...layoutProps }: GridProps<Area>) => JSX.Element | null;
export {};
