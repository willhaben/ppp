"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Stack = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/defineProperty"));

var _startsWith = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/starts-with"));

var _endsWith = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/ends-with"));

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/slicedToArray"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var _filter = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/filter"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _react = _interopRequireDefault(require("react"));

var _system = require("@wh-components/system");

var _breakpoints = require("../theme/breakpoints");

var _Flex = require("../Flex/Flex");

var _StyledFlex = (0, _styledComponents["default"])(_Flex.Flex).withConfig({
  displayName: "Stack___StyledFlex",
  componentId: "dqwciw-0"
})(["> *:last-child{margin:0;}"]);

var Stack = function Stack(_ref) {
  var _context;

  var spacing = _ref.spacing,
      _ref$flexDirection = _ref.flexDirection,
      flexDirection = _ref$flexDirection === void 0 ? 'row' : _ref$flexDirection,
      children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["spacing", "flexDirection", "children"]);
  var validChildren = (0, _filter["default"])(_context = _react["default"].Children.toArray(children)).call(_context, _react["default"].isValidElement); // we cannot use useResponsiveValue since that would break layout before hydration

  var sortedBreakpoints = (0, _breakpoints.useSortedThemeBreakpoints)();
  var responsiveFlexDirectionAndSpacing = (0, _system.responsiveCartesianProduct)(flexDirection, spacing, sortedBreakpoints);
  var marginTop = getMarginForSide(responsiveFlexDirectionAndSpacing, 'marginTop');
  var marginRight = getMarginForSide(responsiveFlexDirectionAndSpacing, 'marginRight');
  var marginBottom = getMarginForSide(responsiveFlexDirectionAndSpacing, 'marginBottom');
  var marginLeft = getMarginForSide(responsiveFlexDirectionAndSpacing, 'marginLeft');

  if (validChildren.length === 0) {
    return null;
  }

  return /*#__PURE__*/_react["default"].createElement(_StyledFlex, (0, _extends2["default"])({
    flexDirection: flexDirection
  }, props), (0, _map["default"])(validChildren).call(validChildren, function (child) {
    var spacingProps = {
      marginTop: marginTop,
      marginRight: marginRight,
      marginBottom: marginBottom,
      marginLeft: marginLeft
    };
    return /*#__PURE__*/_react["default"].cloneElement(child, spacingProps);
  }));
};

exports.Stack = Stack;

var getMarginForSide = function getMarginForSide(responsiveFlexDirectionAndSpacing, marginSide) {
  return (0, _system.responsiveMap)(responsiveFlexDirectionAndSpacing, function (_ref2) {
    var _margins$marginTop, _margins$marginRight, _margins$marginBottom, _margins$marginLeft;

    var _ref3 = (0, _slicedToArray2["default"])(_ref2, 2),
        dir = _ref3[0],
        spac = _ref3[1];

    var isReversed = dir === null || dir === void 0 ? void 0 : (0, _endsWith["default"])(dir).call(dir, 'reverse');
    var isRow = dir === null || dir === void 0 ? void 0 : (0, _startsWith["default"])(dir).call(dir, 'row');
    var margins = isRow ? (0, _defineProperty2["default"])({}, isReversed ? 'marginLeft' : 'marginRight', spac) : (0, _defineProperty2["default"])({}, isReversed ? 'marginTop' : 'marginBottom', spac); // we need to use reset the margin to 0 explicitly, as undefined would not reset the value in styled system, but it is necessary since we use multiple attributes

    var margin = {
      marginTop: (_margins$marginTop = margins.marginTop) !== null && _margins$marginTop !== void 0 ? _margins$marginTop : 0,
      marginRight: (_margins$marginRight = margins.marginRight) !== null && _margins$marginRight !== void 0 ? _margins$marginRight : 0,
      marginBottom: (_margins$marginBottom = margins.marginBottom) !== null && _margins$marginBottom !== void 0 ? _margins$marginBottom : 0,
      marginLeft: (_margins$marginLeft = margins.marginLeft) !== null && _margins$marginLeft !== void 0 ? _margins$marginLeft : 0
    }[marginSide];
    return margin;
  });
};