import { FunctionComponent } from 'react';
import { ResponsiveValue, SystemValue } from '@wh-components/system';
import { BoxProps } from '../Box/Box';
interface StackProps extends BoxProps {
    spacing?: ResponsiveValue<SystemValue>;
}
export declare const Stack: FunctionComponent<StackProps>;
export {};
