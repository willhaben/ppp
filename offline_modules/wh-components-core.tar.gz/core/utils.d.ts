export declare const getFocusableElements: (container: HTMLElement | null, elements?: string[], keyboardOnly?: boolean) => HTMLElement[];
export declare const wait: (milliseconds: number) => Promise<unknown>;
