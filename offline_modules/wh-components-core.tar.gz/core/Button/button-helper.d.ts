declare type ButtonType = 'button' | 'iconButton';
export declare const convertSize: (size: "medium" | "large" | "small" | "xsmall" | Record<string, "medium" | "large" | "small" | "xsmall" | undefined> | undefined, type: ButtonType) => string | number | Record<string, import("csstype").AnimationIterationCountProperty>;
export {};
