"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.IconButton = exports.Button = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _system = require("@wh-components/system");

var _variant = require("@wh-components/system/variant");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _position = require("@wh-components/system/position");

var _flexbox = require("@wh-components/system/flexbox");

var _common = require("../common");

var _buttonHelper = require("./button-helper");

/* eslint-disable no-shadow */
var buttonVariant = (0, _variant.variant)({
  scale: 'components.button.colors',
  prop: ['color', 'variant']
});
var buttonSize = (0, _variant.variant)({
  scale: 'components.button.sizes',
  prop: 'size'
});
var iconButtonSize = (0, _variant.variant)({
  scale: 'components.iconButton.sizes',
  prop: 'size'
});

var ButtonContainer = _styledComponents["default"].button.attrs(_common.testIdAttribute).withConfig({
  displayName: "Button__ButtonContainer",
  componentId: "sc-3uaafx-0"
})(["padding:0;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;border:1px solid transparent;border-radius:", "px;line-height:1.5;font-weight:", ";text-decoration:none;outline:none;user-select:none;white-space:nowrap;vertical-align:middle;transition:all 0.2s;cursor:pointer;", " ", ""], function (p) {
  return p.theme.borderRadii.m;
}, function (p) {
  return p.theme.fontWeights.bold;
}, function (p) {
  return (0, _system.compose)(p.buttonSize, buttonVariant);
}, (0, _system.compose)(_space.space, _layout.layout, _position.position, _flexbox.flexItem));

var Button = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var _ref$type = _ref.type,
      type = _ref$type === void 0 ? 'button' : _ref$type,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'medium' : _ref$size,
      _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'primary' : _ref$color,
      _ref$variant = _ref.variant,
      variant = _ref$variant === void 0 ? 'solid' : _ref$variant,
      Icon = _ref.Icon,
      children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["type", "size", "color", "variant", "Icon", "children"]);
  var iconProps = {
    size: (0, _buttonHelper.convertSize)(size, children ? 'button' : 'iconButton'),
    color: 'inherit',
    marginRight: children && 'xs'
  };
  return /*#__PURE__*/_react["default"].createElement(ButtonContainer, (0, _extends2["default"])({}, props, {
    type: type,
    size: size,
    color: color,
    variant: variant,
    buttonSize: children ? buttonSize : iconButtonSize,
    ref: ref
  }), Icon && /*#__PURE__*/(0, _react.createElement)(Icon, iconProps), children);
});
exports.Button = Button;
var IconButton = /*#__PURE__*/(0, _react.forwardRef)(function (_ref2, ref) {
  var _ref2$type = _ref2.type,
      type = _ref2$type === void 0 ? 'button' : _ref2$type,
      _ref2$size = _ref2.size,
      size = _ref2$size === void 0 ? 'medium' : _ref2$size,
      _ref2$color = _ref2.color,
      color = _ref2$color === void 0 ? 'primary' : _ref2$color,
      _ref2$variant = _ref2.variant,
      variant = _ref2$variant === void 0 ? 'solid' : _ref2$variant,
      Icon = _ref2.Icon,
      props = (0, _objectWithoutProperties2["default"])(_ref2, ["type", "size", "color", "variant", "Icon"]);
  var iconProps = {
    size: (0, _buttonHelper.convertSize)(size, 'iconButton'),
    color: 'inherit'
  };
  return /*#__PURE__*/_react["default"].createElement(ButtonContainer, (0, _extends2["default"])({}, props, {
    type: type,
    size: size,
    color: color,
    variant: variant,
    buttonSize: iconButtonSize,
    ref: ref
  }), Icon && /*#__PURE__*/(0, _react.createElement)(Icon, iconProps));
});
exports.IconButton = IconButton;