"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.ButtonWithLinkStyle = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _system = require("@wh-components/system");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _position = require("@wh-components/system/position");

var _flexbox = require("@wh-components/system/flexbox");

var _typography = require("@wh-components/system/typography");

var _color = require("@wh-components/system/color");

var _common = require("../common");

var ButtonWithLinkStyle = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var Icon = _ref.Icon,
      children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["Icon", "children"]);
  var iconProps = {
    size: '1em',
    color: 'inherit',
    marginRight: 'xxs'
  };
  return /*#__PURE__*/_react["default"].createElement(Link, (0, _extends2["default"])({}, props, {
    ref: ref,
    as: "button"
  }), Icon && /*#__PURE__*/(0, _react.createElement)(Icon, iconProps), children);
});
exports.ButtonWithLinkStyle = ButtonWithLinkStyle;

var Link = _styledComponents["default"].a.attrs(_common.testIdAttribute).withConfig({
  displayName: "ButtonWithLinkStyle__Link",
  componentId: "sc-14yljnj-0"
})(["padding:0;display:inline-flex;align-items:center;border:0;background:transparent;white-space:nowrap;cursor:pointer;&:hover{text-decoration:underline;}&:focus{outline-color:", ";}", ""], function (p) {
  return p.theme.colors.palette.primary.main;
}, (0, _system.compose)(_space.space, _layout.display, _position.position, _flexbox.flexItem, _typography.typography, _color.color));

Link.defaultProps = {
  type: 'button',
  fontSize: 's',
  color: 'palette.primary.main'
};