"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.convertSize = void 0;

var _keys = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/keys"));

var _forEach = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/for-each"));

var _utilities = require("@wh-components/system/utilities");

var convertMap = {
  button: {
    large: 'medium',
    medium: 'small',
    small: 'xsmall',
    xsmall: 12
  },
  iconButton: {
    large: 'xlarge',
    medium: 'medium',
    small: 'small',
    xsmall: 'xsmall'
  }
};

var convertSize = function convertSize() {
  var size = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'medium';
  var type = arguments.length > 1 ? arguments[1] : undefined;

  if ((0, _utilities.isObject)(size)) {
    var _context;

    var iconSize = {};
    (0, _forEach["default"])(_context = (0, _keys["default"])(size)).call(_context, function (key) {
      var convertedSize = size[key];

      if (convertedSize) {
        iconSize[key] = convertMap[type][convertedSize];
      }
    });
    return iconSize;
  } else {
    return convertMap[type][size];
  }
};

exports.convertSize = convertSize;