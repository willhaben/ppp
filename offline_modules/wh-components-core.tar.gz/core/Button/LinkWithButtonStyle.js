"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.LinkWithIconButtonStyle = exports.LinkWithButtonStyle = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _Button = require("./Button");

var LinkWithButtonStyle = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var disabled = _ref.disabled,
      href = _ref.href,
      onClick = _ref.onClick,
      children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["disabled", "href", "onClick", "children"]);
  return /*#__PURE__*/_react["default"].createElement(_Button.Button, (0, _extends2["default"])({
    as: "a"
  }, props, {
    disabled: disabled,
    href: disabled ? undefined : href,
    onClick: disabled ? undefined : onClick,
    ref: ref
  }), children);
});
exports.LinkWithButtonStyle = LinkWithButtonStyle;
var LinkWithIconButtonStyle = /*#__PURE__*/(0, _react.forwardRef)(function (_ref2, ref) {
  var disabled = _ref2.disabled,
      href = _ref2.href,
      onClick = _ref2.onClick,
      props = (0, _objectWithoutProperties2["default"])(_ref2, ["disabled", "href", "onClick"]);
  return /*#__PURE__*/_react["default"].createElement(_Button.IconButton, (0, _extends2["default"])({
    as: "a"
  }, props, {
    disabled: disabled,
    href: disabled ? undefined : href,
    onClick: disabled ? undefined : onClick,
    ref: ref
  }));
});
exports.LinkWithIconButtonStyle = LinkWithIconButtonStyle;