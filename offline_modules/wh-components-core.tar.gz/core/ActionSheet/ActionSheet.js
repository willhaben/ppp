"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.ActionSheet = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _responsive = require("../utilities/responsive");

var _Dropdown = require("../Dropdown/Dropdown");

var _Drawer = require("../Drawer/Drawer");

var ActionSheet = function ActionSheet(_ref) {
  var _ref$renderAs = _ref.renderAs,
      renderAs = _ref$renderAs === void 0 ? {
    phone: 'drawer',
    tablet: 'dropdown'
  } : _ref$renderAs,
      dropdownPlacement = _ref.dropdownPlacement,
      drawerPlacement = _ref.drawerPlacement,
      children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["renderAs", "dropdownPlacement", "drawerPlacement", "children"]);
  var renderAsValue = (0, _responsive.useResponsiveValue)(renderAs, undefined);
  return renderAsValue === 'dropdown' ? /*#__PURE__*/_react["default"].createElement(_Dropdown.Dropdown, (0, _extends2["default"])({}, props, {
    placement: dropdownPlacement
  }), children) : /*#__PURE__*/_react["default"].createElement(_react.Fragment, null, children, /*#__PURE__*/_react["default"].createElement(_Drawer.Drawer, (0, _extends2["default"])({}, props, {
    placement: drawerPlacement
  })));
};

exports.ActionSheet = ActionSheet;