import { FunctionComponent } from 'react';
import { ResponsiveValue } from '@wh-components/system';
import { DropdownItemType, DropdownProps } from '../Dropdown/Dropdown';
import { DrawerItemType, DrawerProps } from '../Drawer/Drawer';
declare type CompatibleDropdownProps = Omit<DropdownProps, 'children' | 'placement'>;
declare type CompatibleDrawerProps = Omit<DrawerProps, 'children' | 'placement'>;
declare type MenuRenderAs = 'dropdown' | 'drawer';
export declare type ActionSheetItemType = DropdownItemType & DrawerItemType;
export interface ActionSheetProps extends CompatibleDropdownProps, CompatibleDrawerProps {
    renderAs?: ResponsiveValue<MenuRenderAs>;
    dropdownPlacement?: DropdownProps['placement'];
    drawerPlacement?: DrawerProps['placement'];
    items: ActionSheetItemType[];
    onRequestClose?: () => void;
    children: JSX.Element;
}
export declare const ActionSheet: FunctionComponent<ActionSheetProps>;
export {};
