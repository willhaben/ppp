import { FunctionComponent, ReactNode } from 'react';
import { WidthProps, HeightProps } from '@wh-components/system/layout';
import { ResponsiveValue } from '@wh-components/system';
import { BaseModalProps } from './BaseModal';
export interface ModalProps extends BaseModalProps, WidthProps, HeightProps {
    header?: string;
    footer?: ReactNode;
    fullScreen?: ResponsiveValue<boolean>;
    fullHeightContent?: ResponsiveValue<boolean>;
}
export declare const Modal: FunctionComponent<ModalProps>;
