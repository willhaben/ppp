import { FunctionComponent } from 'react';
import { Props as ReactModalProps } from 'react-modal';
export declare type BaseModalProps = Pick<ReactModalProps, 'contentLabel' | 'isOpen' | 'onAfterOpen' | 'onAfterClose' | 'onRequestClose' | 'shouldCloseOnEsc' | 'shouldCloseOnOverlayClick' | 'testId'>;
export declare const BaseModal: FunctionComponent<BaseModalProps> & {
    setAppElement: (appElement: string | HTMLElement) => void;
};
