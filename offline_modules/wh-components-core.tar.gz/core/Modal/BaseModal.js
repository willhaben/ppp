"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.BaseModal = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _reactModal = _interopRequireDefault(require("react-modal"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _theme = require("../theme");

var _BlockBodyScroll = require("../BlockBodyScroll/BlockBodyScroll");

var BaseModal = function BaseModal(_ref) {
  var children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["children"]);
  return /*#__PURE__*/_react["default"].createElement(_react.Fragment, null, /*#__PURE__*/_react["default"].createElement(_BlockBodyScroll.BlockBodyScroll, null), /*#__PURE__*/_react["default"].createElement(StyledReactModal, (0, _extends2["default"])({}, props, {
    aria: {
      modal: true
    },
    ariaHideApp: false,
    bodyOpenClassName: null
  }), children));
};
/**
 * Call this to properly hide your application from assistive screenreaders
 * and other assistive technologies while the modal is open.
 */


exports.BaseModal = BaseModal;

BaseModal.setAppElement = function (appElement) {
  _reactModal["default"].setAppElement(appElement);
};

var StyledReactModal = (0, _styledComponents["default"])(_reactModal["default"]).withConfig({
  displayName: "BaseModal__StyledReactModal",
  componentId: "nhdif2-0"
})(["background-color:", ";outline:0;z-index:", ";box-shadow:0 4px 16px 0 ", ";"], function (p) {
  return p.theme.colors.palette.white;
}, function (p) {
  return p.theme.zIndices.modal;
}, function (p) {
  return p.theme.colors.palette.grey;
});
_reactModal["default"].defaultStyles = {
  overlay: {
    position: 'fixed',
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    zIndex: _theme.theme.zIndices.wash
  }
};