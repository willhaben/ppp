"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Modal = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _layout = require("@wh-components/system/layout");

var _responsive = require("../utilities/responsive");

var _BaseModal = require("./BaseModal");

var _CloseButton = require("../CloseButton/CloseButton");

var _Box = require("../Box/Box");

var _Text = require("../Text/Text");

var Modal = function Modal(_ref) {
  var header = _ref.header,
      footer = _ref.footer,
      fullScreen = _ref.fullScreen,
      fullHeightContent = _ref.fullHeightContent,
      isOpen = _ref.isOpen,
      onRequestClose = _ref.onRequestClose,
      testId = _ref.testId,
      children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["header", "footer", "fullScreen", "fullHeightContent", "isOpen", "onRequestClose", "testId", "children"]);
  var fullScreenValue = (0, _responsive.useResponsiveValue)(fullScreen, undefined);
  var fullHeightContentValue = (0, _responsive.useResponsiveValue)(fullHeightContent, undefined);
  return isOpen ? /*#__PURE__*/_react["default"].createElement(StyledModal, (0, _extends2["default"])({}, props, {
    fullScreen: fullScreenValue,
    isOpen: isOpen,
    onRequestClose: onRequestClose,
    testId: testId
  }), header && /*#__PURE__*/_react["default"].createElement(_Box.Box, {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexShrink: 0,
    marginHorizontal: fullScreenValue ? undefined : 'l',
    paddingHorizontal: fullScreenValue ? 'm' : undefined,
    paddingTop: fullScreenValue ? 's' : 'l',
    paddingBottom: "s",
    borderBottom: "owl"
  }, /*#__PURE__*/_react["default"].createElement(_Text.Text, {
    fontSize: "xl",
    fontWeight: "bold",
    color: "palette.primary.main"
  }, header), /*#__PURE__*/_react["default"].createElement(_CloseButton.CloseButton, {
    size: "small",
    position: fullScreenValue ? undefined : 'absolute',
    top: 0,
    right: 0,
    "aria-label": "Fenster schlie\xDFen",
    testId: testId && "".concat(testId, "-close-button"),
    onClick: onRequestClose
  })), /*#__PURE__*/_react["default"].createElement(_Box.Box, {
    paddingHorizontal: fullScreenValue ? 'm' : 'l',
    paddingTop: header ? 'm' : 'l',
    paddingBottom: footer ? 0 : fullScreenValue ? 'm' : 'l',
    height: fullHeightContentValue ? '100%' : undefined,
    overflowY: fullHeightContentValue ? undefined : 'auto'
  }, children), footer && /*#__PURE__*/_react["default"].createElement(_react.Fragment, null, /*#__PURE__*/_react["default"].createElement(_Box.Box, {
    flexGrow: 1
  }), /*#__PURE__*/_react["default"].createElement(_Box.Box, {
    padding: fullScreenValue ? 'm' : 'l',
    paddingTop: "m",
    flexShrink: 0
  }, footer))) : null;
};

exports.Modal = Modal;
var normalStyles = (0, _styledComponents.css)(["position:relative;max-height:calc(100% - 64px);min-width:400px;margin:32px;border-radius:", "px;"], function (p) {
  return p.theme.borderRadii.m;
});
var fullScreenStyles = (0, _styledComponents.css)(["position:absolute;top:0;right:0;bottom:0;left:0;"]);
var StyledModal = (0, _styledComponents["default"])(_BaseModal.BaseModal).withConfig({
  displayName: "Modal__StyledModal",
  componentId: "gg9gle-0"
})(["display:flex;flex-direction:column;overflow-y:auto;", " ", " ", ""], function (p) {
  return p.fullScreen ? fullScreenStyles : normalStyles;
}, _layout.width, _layout.height);