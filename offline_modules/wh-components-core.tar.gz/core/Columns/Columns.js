"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Columns = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _system = require("@wh-components/system");

var _Box = require("../Box/Box");

var columns = (0, _system.system)({
  columns: {
    property: 'columns'
  },
  gap: {
    property: 'column-gap',
    scale: 'space'
  }
});
var Columns = (0, _styledComponents["default"])(_Box.Box).withConfig({
  displayName: "Columns",
  componentId: "sc-1kewbr2-0"
})(columns);
exports.Columns = Columns;