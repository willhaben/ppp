import { ResponsiveValue, SystemValue } from '@wh-components/system';
interface ColumnsProps {
    columns: ResponsiveValue<number>;
    gap?: ResponsiveValue<SystemValue>;
}
export declare const Columns: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {
    'data-testid': string | undefined;
} & import("../common").TestProps & import("@wh-components/system/animation").AnimationProps & import("@wh-components/system/background").BackgroundProps & import("@wh-components/system/border").BorderProps & import("@wh-components/system/color").ColorProps<any> & import("@wh-components/system/flexbox").FlexContainerProps & import("@wh-components/system/flexbox").FlexItemProps & import("@wh-components/system/grid").GridProps & import("@wh-components/system/layout").HeightProps & import("@wh-components/system/layout").WidthProps & import("@wh-components/system/layout").DisplayProps & import("@wh-components/system/layout").OverflowProps & import("@wh-components/system/position").PositionProps & import("@wh-components/system/shadow").ShadowProps & import("@wh-components/system/space").MarginProps & import("@wh-components/system/space").PaddingProps & import("@wh-components/system/typography").TypographyProps & ColumnsProps, "data-testid">;
export {};
