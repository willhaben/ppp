import { CSSObject } from 'styled-components';
export declare const buttonComponentTheme: {
    button: {
        sizes: {
            xsmall: {
                height: number;
                minWidth: number;
                paddingLeft: number;
                paddingRight: number;
                fontSize: number;
            };
            small: {
                height: number;
                minWidth: number;
                paddingLeft: number;
                paddingRight: number;
                fontSize: number;
            };
            medium: {
                height: number;
                minWidth: number;
                paddingLeft: number;
                paddingRight: number;
                fontSize: number;
            };
            large: {
                height: number;
                minWidth: number;
                paddingLeft: number;
                paddingRight: number;
                fontSize: number;
            };
        };
        colors: Record<string, CSSObject>;
    };
    iconButton: {
        sizes: {
            xsmall: {
                height: number;
                width: number;
            };
            small: {
                height: number;
                width: number;
            };
            medium: {
                height: number;
                width: number;
            };
            large: {
                height: number;
                width: number;
            };
        };
    };
};
