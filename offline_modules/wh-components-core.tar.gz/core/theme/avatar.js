"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.avatarComponentTheme = void 0;
var avatarComponentTheme = {
  avatar: {
    sizes: {
      xsmall: 32,
      small: 48,
      medium: 64,
      large: 80,
      xlarge: 96
    }
  }
};
exports.avatarComponentTheme = avatarComponentTheme;