export declare const spaceTheme: {
    space: {
        xxs: number;
        xs: number;
        s: number;
        sm: number;
        m: number;
        l: number;
        xl: number;
        xxl: number;
        xxxl: number;
        xxxxl: number;
    };
};
