export declare const alertComponentTheme: {
    alert: {
        colors: {
            info: {
                color: string;
                backgroundColor: string;
            };
            success: {
                color: string;
                backgroundColor: string;
            };
            warning: {
                color: string;
                backgroundColor: string;
            };
            error: {
                color: string;
                backgroundColor: string;
            };
        };
    };
};
