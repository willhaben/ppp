"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.buttonComponentTheme = void 0;

var _system = require("../utilities/system");

var _palette = require("../theme/palette");

var buttonStates = function buttonStates() {
  var states = {};
  (0, _system.objectKeyMap)(_palette.buttonPalette, function (type) {
    var color = _palette.buttonPalette[type];
    states["".concat(type, "solid")] = {
      color: _palette.palette.white,
      borderColor: color.normal,
      backgroundColor: color.normal,
      ':active': {
        borderColor: color.active,
        backgroundColor: color.active
      },
      ':disabled, &[disabled]': {
        borderColor: color.disabled,
        backgroundColor: color.disabled,
        cursor: 'not-allowed'
      },
      ':not(:disabled):not([disabled]):hover': {
        borderColor: color.hover,
        backgroundColor: color.hover
      },
      ':focus': {
        boxShadow: "0 0 0 3px ".concat(color.shadow)
      }
    };
    states["".concat(type, "outline")] = {
      color: color.normal,
      borderColor: color.normal,
      backgroundColor: _palette.palette.white,
      ':active': {
        color: color.active,
        borderColor: color.active
      },
      ':disabled, &[disabled]': {
        color: color.disabled,
        borderColor: color.disabled,
        cursor: 'not-allowed'
      },
      ':not(:disabled):not([disabled]):hover': {
        color: color.hover,
        borderColor: color.hover,
        backgroundColor: _palette.palette.babyseal
      },
      ':focus': {
        boxShadow: "0 0 0 3px ".concat(color.shadow)
      }
    };
    states["".concat(type, "transparent")] = {
      color: color.normal,
      borderColor: 'transparent',
      backgroundColor: 'transparent',
      ':disabled, &[disabled]': {
        color: color.disabled,
        cursor: 'not-allowed'
      },
      ':focus': {
        boxShadow: "0 0 0 3px ".concat(color.shadow)
      }
    };
  });
  return states;
};

var buttonComponentTheme = {
  button: {
    sizes: {
      xsmall: {
        height: 24,
        minWidth: 24,
        paddingLeft: 6,
        paddingRight: 6,
        fontSize: 11
      },
      small: {
        height: 32,
        minWidth: 32,
        paddingLeft: 8,
        paddingRight: 8,
        fontSize: 12
      },
      medium: {
        height: 40,
        minWidth: 40,
        paddingLeft: 12,
        paddingRight: 12,
        fontSize: 14
      },
      large: {
        height: 48,
        minWidth: 48,
        paddingLeft: 16,
        paddingRight: 16,
        fontSize: 14
      }
    },
    colors: buttonStates()
  },
  iconButton: {
    sizes: {
      xsmall: {
        height: 24,
        width: 24
      },
      small: {
        height: 32,
        width: 32
      },
      medium: {
        height: 40,
        width: 40
      },
      large: {
        height: 48,
        width: 48
      }
    }
  }
};
exports.buttonComponentTheme = buttonComponentTheme;