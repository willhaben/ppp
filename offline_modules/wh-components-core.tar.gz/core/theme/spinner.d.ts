export declare const spinnerComponentTheme: {
    spinner: {
        sizes: {
            small: {
                height: number;
                width: number;
                borderWidth: number;
            };
            medium: {
                height: number;
                width: number;
                borderWidth: number;
            };
            large: {
                height: number;
                width: number;
                borderWidth: number;
            };
        };
        colors: {
            primary: {
                borderLeftColor: string;
            };
            secondary: {
                borderLeftColor: string;
            };
            complimentary: {
                borderLeftColor: string;
            };
            accent: {
                borderLeftColor: string;
            };
        };
        speeds: {
            slow: {
                animationDuration: string;
            };
            medium: {
                animationDuration: string;
            };
            fast: {
                animationDuration: string;
            };
        };
    };
};
