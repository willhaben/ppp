export declare const breakpointsTheme: {
    breakpoints: {
        tablet: number;
        desktop: number;
    };
    print: {
        breakpoint: string;
    };
};
export declare type ResponsiveBreakpoints = 'phone' | 'tablet' | 'desktop' | 'print';
/** returns breakpoint names sorted ascending by browser width
 *  excludes lowest fallback-breakpoint
 *  e.g. ['tablet', 'desktop']
 */
export declare const useSortedThemeBreakpoints: () => string[];
