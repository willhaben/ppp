"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.spinnerComponentTheme = void 0;

var _palette = require("../theme/palette");

var spinnerComponentTheme = {
  spinner: {
    sizes: {
      small: {
        height: 32,
        width: 32,
        borderWidth: 4
      },
      medium: {
        height: 48,
        width: 48,
        borderWidth: 6
      },
      large: {
        height: 64,
        width: 64,
        borderWidth: 6
      }
    },
    colors: {
      primary: {
        borderLeftColor: _palette.buttonPalette.primary.normal
      },
      secondary: {
        borderLeftColor: _palette.buttonPalette.secondary.normal
      },
      complimentary: {
        borderLeftColor: _palette.buttonPalette.complimentary.normal
      },
      accent: {
        borderLeftColor: _palette.buttonPalette.accent.normal
      }
    },
    speeds: {
      slow: {
        animationDuration: '1.25s'
      },
      medium: {
        animationDuration: '1s'
      },
      fast: {
        animationDuration: '0.75s'
      }
    }
  }
};
exports.spinnerComponentTheme = spinnerComponentTheme;