export declare const palette: {
    primary: {
        main: string;
        active: string;
        hover: string;
        disabled: string;
    };
    secondary: {
        main: string;
        active: string;
        hover: string;
        disabled: string;
    };
    accent: {
        primary: {
            main: string;
            active: string;
            hover: string;
            disabled: string;
        };
        secondary: {
            main: string;
            active: string;
            hover: string;
            disabled: string;
        };
    };
    signal: {
        red: string;
        orange: string;
        green: string;
    };
    coral: string;
    tangerine: string;
    jungle: string;
    lavender: string;
    petrol: string;
    lagoon: string;
    honeydew: string;
    panther: string;
    raccoon: string;
    elephant: string;
    koala: string;
    seal: string;
    owl: string;
    dove: string;
    babyseal: string;
    polarbear: string;
    black: string;
    verydarkgrey: string;
    darkgrey: string;
    grey: string;
    lightgrey: string;
    verylightgrey: string;
    white: string;
};
export declare const buttonPalette: {
    primary: {
        normal: string;
        active: string;
        hover: string;
        disabled: string;
        shadow: string;
    };
    complimentary: {
        normal: string;
        active: string;
        hover: string;
        disabled: string;
        shadow: string;
    };
    secondary: {
        normal: string;
        active: string;
        hover: string;
        disabled: string;
        shadow: string;
    };
    accent: {
        normal: string;
        active: string;
        hover: string;
        disabled: string;
        shadow: string;
    };
};
export declare const alertPalette: {
    info: {
        main: string;
        background: string;
    };
    success: {
        main: string;
        background: string;
    };
    warning: {
        main: string;
        background: string;
    };
    error: {
        main: string;
        background: string;
    };
};
