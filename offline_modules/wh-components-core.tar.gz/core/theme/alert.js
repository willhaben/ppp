"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.alertComponentTheme = void 0;

var _palette = require("./palette");

var alertComponentTheme = {
  alert: {
    colors: {
      info: {
        color: _palette.alertPalette.info.main,
        backgroundColor: _palette.alertPalette.info.background
      },
      success: {
        color: _palette.alertPalette.success.main,
        backgroundColor: _palette.alertPalette.success.background
      },
      warning: {
        color: _palette.alertPalette.warning.main,
        backgroundColor: _palette.alertPalette.warning.background
      },
      error: {
        color: _palette.alertPalette.error.main,
        backgroundColor: _palette.alertPalette.error.background
      }
    }
  }
};
exports.alertComponentTheme = alertComponentTheme;