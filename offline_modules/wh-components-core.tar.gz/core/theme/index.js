"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty2 = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty2(exports, "__esModule", {
  value: true
});

exports.theme = exports.baseFontSize = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/define-property"));

var _defineProperties = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/define-properties"));

var _getOwnPropertyDescriptors = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors"));

var _forEach = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/for-each"));

var _getOwnPropertyDescriptor = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor"));

var _filter = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/filter"));

var _getOwnPropertySymbols = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols"));

var _keys = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/keys"));

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _defineProperty3 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/defineProperty"));

var _space = require("./space");

var _breakpoints = require("./breakpoints");

var _palette = require("./palette");

var _button = require("./button");

var _icon = require("./icon");

var _checkbox = require("./FormElements/checkbox");

var _radio = require("./FormElements/radio");

var _alert = require("./alert");

var _spinner = require("./spinner");

var _input = require("./FormElements/input");

var _select = require("./FormElements/select");

var _toggle = require("./FormElements/toggle");

var _textarea = require("./FormElements/textarea");

var _avatar = require("./avatar");

var _range = require("./FormElements/range");

var _context;

function ownKeys(object, enumerableOnly) { var keys = (0, _keys["default"])(object); if (_getOwnPropertySymbols["default"]) { var symbols = (0, _getOwnPropertySymbols["default"])(object); if (enumerableOnly) symbols = (0, _filter["default"])(symbols).call(symbols, function (sym) { return (0, _getOwnPropertyDescriptor["default"])(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context2; (0, _forEach["default"])(_context2 = ownKeys(Object(source), true)).call(_context2, function (key) { (0, _defineProperty3["default"])(target, key, source[key]); }); } else if (_getOwnPropertyDescriptors["default"]) { (0, _defineProperties["default"])(target, (0, _getOwnPropertyDescriptors["default"])(source)); } else { var _context3; (0, _forEach["default"])(_context3 = ownKeys(Object(source))).call(_context3, function (key) { (0, _defineProperty2["default"])(target, key, (0, _getOwnPropertyDescriptor["default"])(source, key)); }); } } return target; }

var baseFontSize = 14;
exports.baseFontSize = baseFontSize;
var breakpoints = {
  tablet: 768,
  desktop: 970
};

var theme = _objectSpread(_objectSpread(_objectSpread({
  components: _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, _button.buttonComponentTheme), _icon.iconComponentTheme), _checkbox.checkboxComponentTheme), _radio.radioComponentTheme), _alert.alertComponentTheme), _spinner.spinnerComponentTheme), _input.inputComponentTheme), _textarea.textareaComponentTheme), _select.selectComponentTheme), _toggle.toggleComponentTheme), _avatar.avatarComponentTheme), _range.rangeComponentTheme)
}, _space.spaceTheme), _breakpoints.breakpointsTheme), {}, {
  // Legacy below
  layout: 740,
  lineHeights: {
    paragraph: 1.5,
    heading: 1.25
  },
  fontWeights: {
    light: 300,
    regular: 400,
    semibold: 600,
    bold: 700,
    extrabold: 800
  },
  fontSizes: {
    xxxl: "".concat(28 / baseFontSize, "rem"),
    xxl: "".concat(24 / baseFontSize, "rem"),
    xl: "".concat(18 / baseFontSize, "rem"),
    l: "".concat(16 / baseFontSize, "rem"),
    m: "".concat(14 / baseFontSize, "rem"),
    s: "".concat(12 / baseFontSize, "rem"),
    xs: "".concat(10 / baseFontSize, "rem")
  },
  fontFamilies: {
    sansSerif: "'Open Sans', Helvetica, sans-serif"
  },
  borders: {
    panther: "1px solid ".concat(_palette.palette.panther),
    raccoon: "1px solid ".concat(_palette.palette.raccoon),
    elephant: "1px solid ".concat(_palette.palette.elephant),
    koala: "1px solid ".concat(_palette.palette.koala),
    seal: "1px solid ".concat(_palette.palette.seal),
    owl: "1px solid ".concat(_palette.palette.owl),
    dove: "1px solid ".concat(_palette.palette.dove),
    babyseal: "1px solid ".concat(_palette.palette.babyseal),
    polarbear: "1px solid ".concat(_palette.palette.polarbear)
  },
  borderRadii: {
    s: 2,
    m: 4,
    l: 8,
    xl: 16
  },
  borderRadius: 4,
  media: {
    tablet: "@media only screen and (min-width: ".concat(breakpoints.tablet, "px), print"),
    desktop: "@media only screen and (min-width: ".concat(breakpoints.desktop, "px), print"),
    print: "@media print",
    only: {
      phone: "@media only screen and (max-width: ".concat(breakpoints.tablet - 1, "px)"),
      tablet: (0, _concat["default"])(_context = "@media only screen and (min-width: ".concat(breakpoints.tablet, "px) and (max-width: ")).call(_context, breakpoints.desktop - 1, "px)")
    },
    browser: {
      ie11: "@media all and (-ms-high-contrast: none), (-ms-high-contrast: active)"
    }
  },
  colors: {
    palette: _palette.palette,
    adStatus: {
      active: _palette.palette.signal.green,
      inactive: _palette.palette.signal.orange,
      rejected: _palette.palette.signal.red,
      expired: _palette.palette.grey
    },
    socialMedia: {
      facebook: '#1877f2',
      // https://en.facebookbrand.com/advertisers-partners-guidelines
      google: '#ea4335',
      // https://design.google/library/evolving-google-identity
      instagram: '#c13584',
      // https://en.instagram-brand.com/assets/icons
      kununu: '#99c613',
      linkedin: '#2867b2',
      // https://brand.linkedin.com
      messenger: '#0084ff',
      // https://en.facebookbrand.com/assets/messenger
      twitch: '#6441a4',
      // https://www.twitch.tv/p/brand
      twitter: '#1da1f2',
      // https://about.twitter.com/de/company/brand-resources.html
      video: _palette.palette.black,
      vimeo: '#1ab7ea',
      // https://press.vimeo.com/brand-guidelines
      whatsapp: '#25d366',
      // https://whatsappbrand.com
      xing: '#026466',
      // https://dev.xing.com/logo_rules
      youtube: '#ff0000' // https://www.youtube.com/intl/de/yt/about/brand-resources/#logos-icons-colors

    },
    heatMap: {
      low: '#0283a0',
      middle: '#84c509',
      moderate: '#069306',
      high: '#ffd800',
      veryHigh: '#ff9000'
    },
    alert: {
      success: {
        main: _palette.palette.signal.green,
        background: '#e5f6e5'
      },
      warning: {
        main: _palette.palette.signal.orange,
        background: '#fff3e5'
      },
      error: {
        main: _palette.palette.signal.red,
        background: '#ffe5e5'
      },
      info: {
        main: _palette.palette.primary.main,
        background: '#e5f5fc'
      }
    },
    background: {
      "default": 'transparent'
    }
  },
  zIndices: {
    backgroundAd: -100,
    content: 0,
    popover: 100,
    stickyContent: 200,
    overlay: 300,
    header: 400,
    wash: 500,
    modal: 600,
    banner: 700,
    overlayAd: 800
  }
});

exports.theme = theme;