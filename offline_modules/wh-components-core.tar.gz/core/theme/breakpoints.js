"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.useSortedThemeBreakpoints = exports.breakpointsTheme = void 0;

var _sort = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/sort"));

var _keys = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/keys"));

var _react = require("react");

var _styledComponents = require("styled-components");

var breakpointsTheme = {
  breakpoints: {
    tablet: 768,
    desktop: 970
  },
  print: {
    breakpoint: 'print'
  }
};
exports.breakpointsTheme = breakpointsTheme;

/** returns breakpoint names sorted ascending by browser width
 *  excludes lowest fallback-breakpoint
 *  e.g. ['tablet', 'desktop']
 */
var useSortedThemeBreakpoints = function useSortedThemeBreakpoints() {
  // breakpoints might be different in client project, that's why we pull them out of the theme here
  var theme = (0, _react.useContext)(_styledComponents.ThemeContext);
  var breakpoints = (0, _keys["default"])(theme.breakpoints);
  var sortedBreakpoints = (0, _sort["default"])(breakpoints).call(breakpoints, function (a, b) {
    return theme.breakpoints[a] - theme.breakpoints[b];
  });
  return sortedBreakpoints;
};

exports.useSortedThemeBreakpoints = useSortedThemeBreakpoints;