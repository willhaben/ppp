"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.WillhabenThemeProvider = void 0;

var _react = _interopRequireDefault(require("react"));

var _ = require(".");

var _styledComponents = require("styled-components");

var WillhabenThemeProvider = function WillhabenThemeProvider(_ref) {
  var _ref$theme = _ref.theme,
      theme = _ref$theme === void 0 ? _.theme : _ref$theme,
      children = _ref.children;
  return /*#__PURE__*/_react["default"].createElement(_styledComponents.ThemeProvider, {
    theme: theme,
    children: children
  });
};

exports.WillhabenThemeProvider = WillhabenThemeProvider;