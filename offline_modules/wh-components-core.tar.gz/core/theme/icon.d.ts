export declare const iconComponentTheme: {
    icon: {
        size: {
            xxsmall: number;
            xsmall: number;
            small: number;
            medium: number;
            large: number;
            xlarge: number;
        };
    };
};
