"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.textareaComponentTheme = void 0;

var _input = require("./input");

var textareaComponentTheme = {
  textarea: {
    sizes: {
      small: {
        fontSize: _input.inputComponentTheme.input.sizes.small.fontSize
      },
      medium: {
        fontSize: _input.inputComponentTheme.input.sizes.medium.fontSize
      },
      large: {
        fontSize: _input.inputComponentTheme.input.sizes.large.fontSize
      }
    }
  }
};
exports.textareaComponentTheme = textareaComponentTheme;