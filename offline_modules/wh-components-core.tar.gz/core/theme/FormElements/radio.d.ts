export declare const radioComponentTheme: {
    radio: {
        sizes: {
            small: {
                height: number;
                width: number;
            };
            medium: {
                height: number;
                width: number;
            };
            large: {
                height: number;
                width: number;
            };
            xlarge: {
                height: number;
                width: number;
            };
        };
    };
    radioLabel: {
        sizes: {
            small: {
                [x: string]: number | {
                    height: number;
                    width: number;
                };
                height: number;
                paddingLeft: number;
                fontSize: number;
            };
            medium: {
                [x: string]: number | {
                    height: number;
                    width: number;
                };
                height: number;
                paddingLeft: number;
                fontSize: number;
            };
            large: {
                [x: string]: number | {
                    height: number;
                    width: number;
                };
                height: number;
                paddingLeft: number;
                fontSize: number;
            };
            xlarge: {
                [x: string]: number | {
                    height: number;
                    width: number;
                };
                height: number;
                paddingLeft: number;
                fontSize: number;
            };
        };
        borderColors: {
            normal: {
                [x: string]: {
                    borderColor: string;
                };
            };
            success: {
                [x: string]: {
                    borderColor: string;
                };
            };
            warning: {
                [x: string]: {
                    borderColor: string;
                };
            };
            error: {
                [x: string]: {
                    borderColor: string;
                };
            };
        };
    };
    radioGroupInlineLabel: {
        sizes: {
            small: {
                height: number;
            };
            medium: {
                height: number;
            };
            large: {
                height: number;
            };
            xlarge: {
                height: number;
            };
        };
    };
};
