export declare const rangeComponentTheme: {
    range: {
        sizes: {
            input: {
                small: {
                    height: number;
                };
                medium: {
                    height: number;
                };
                large: {
                    height: number;
                };
            };
            thumb: {
                small: {
                    height: number;
                    width: number;
                };
                medium: {
                    height: number;
                    width: number;
                };
                large: {
                    height: number;
                    width: number;
                };
            };
            track: {
                small: {
                    height: number;
                };
                medium: {
                    height: number;
                };
                large: {
                    height: number;
                };
            };
            chrome: {
                small: {
                    marginTop: number;
                };
                medium: {
                    marginTop: number;
                };
                large: {
                    marginTop: number;
                };
            };
            ie11: {
                small: {
                    borderTopWidth: number;
                    borderBottomWidth: number;
                };
                medium: {
                    borderTopWidth: number;
                    borderBottomWidth: number;
                };
                large: {
                    borderTopWidth: number;
                    borderBottomWidth: number;
                };
            };
        };
        colors: {
            primary: {
                backgroundColor: string;
            };
            secondary: {
                backgroundColor: string;
            };
            complimentary: {
                backgroundColor: string;
            };
            accent: {
                backgroundColor: string;
            };
        };
    };
};
