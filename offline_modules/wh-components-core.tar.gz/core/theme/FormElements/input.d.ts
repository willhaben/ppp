export declare const inputComponentTheme: {
    input: {
        sizes: {
            small: {
                height: number;
                fontSize: number;
            };
            medium: {
                height: number;
                fontSize: number;
            };
            large: {
                height: number;
                fontSize: number;
            };
        };
        colors: {
            normal: {
                borderColor: string;
            };
            success: {
                borderColor: string;
            };
            warning: {
                borderColor: string;
            };
            error: {
                borderColor: string;
            };
        };
        addon: {
            sizes: {
                small: {
                    minWidth: number;
                    fontSize: number;
                };
                medium: {
                    minWidth: number;
                    fontSize: number;
                };
                large: {
                    minWidth: number;
                    fontSize: number;
                };
            };
            colors: {
                normal: {
                    borderColor: string;
                    backgroundColor: string;
                };
                success: {
                    borderColor: string;
                    backgroundColor: string;
                };
                warning: {
                    borderColor: string;
                    backgroundColor: string;
                };
                error: {
                    borderColor: string;
                    backgroundColor: string;
                };
            };
        };
        iconButton: {
            button: {
                sizes: {
                    small: {
                        height: number;
                        width: number;
                    };
                    medium: {
                        height: number;
                        width: number;
                    };
                    large: {
                        height: number;
                        width: number;
                    };
                };
            };
            icon: {
                sizes: {
                    small: number;
                    medium: number;
                    large: number;
                };
            };
        };
        comment: {
            colors: {
                normal: {
                    color: string;
                };
                success: {
                    color: string;
                };
                warning: {
                    color: string;
                };
                error: {
                    color: string;
                };
            };
        };
    };
};
