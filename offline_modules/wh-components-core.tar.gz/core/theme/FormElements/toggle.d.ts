export declare const toggleComponentTheme: {
    toggle: {
        sizes: {
            small: {
                [x: string]: number | {
                    height: number;
                    width: number;
                };
                height: number;
                minWidth: number;
                borderRadius: number;
                fontSize: number;
            };
            medium: {
                [x: string]: number | {
                    height: number;
                    width: number;
                };
                height: number;
                minWidth: number;
                borderRadius: number;
                fontSize: number;
            };
            large: {
                [x: string]: number | {
                    height: number;
                    width: number;
                };
                height: number;
                minWidth: number;
                borderRadius: number;
                fontSize: number;
            };
        };
        colors: {
            primary: {
                backgroundColor: string;
            };
            secondary: {
                backgroundColor: string;
            };
            complimentary: {
                backgroundColor: string;
            };
            accent: {
                backgroundColor: string;
            };
            success: {
                backgroundColor: string;
            };
            warning: {
                backgroundColor: string;
            };
            error: {
                backgroundColor: string;
            };
        };
    };
};
