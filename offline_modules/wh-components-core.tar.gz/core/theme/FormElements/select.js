"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.selectComponentTheme = void 0;

var _palette = require("../palette");

var selectComponentTheme = {
  select: {
    sizes: {
      small: {
        height: 32,
        paddingRight: 'calc(32px + 0.75em)',
        fontSize: 12
      },
      medium: {
        height: 40,
        paddingRight: 'calc(40px + 0.75em)',
        fontSize: 14
      },
      large: {
        height: 48,
        paddingRight: 'calc(48px + 0.75em)',
        fontSize: 14
      }
    },
    colors: {
      normal: {
        borderColor: _palette.palette.koala
      },
      success: {
        borderColor: _palette.palette.signal.green
      },
      warning: {
        borderColor: _palette.palette.signal.orange
      },
      error: {
        borderColor: _palette.palette.signal.red
      }
    },
    icon: {
      sizes: {
        small: {
          backgroundSize: '16px 16px, 32px 32px',
          backgroundPosition: 'right 7px center, right'
        },
        medium: {
          backgroundSize: '20px 20px, 40px 40px',
          backgroundPosition: 'right 9px center, right'
        },
        large: {
          backgroundSize: '24px 24px, 48px 48px',
          backgroundPosition: 'right 11px center, right'
        }
      }
    }
  }
};
exports.selectComponentTheme = selectComponentTheme;