"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.inputComponentTheme = void 0;

var _palette = require("../palette");

var _icon = require("../icon");

var inputComponentTheme = {
  input: {
    sizes: {
      small: {
        height: 32 - 2,
        fontSize: 12
      },
      medium: {
        height: 40 - 2,
        fontSize: 14
      },
      large: {
        height: 48 - 2,
        fontSize: 14
      }
    },
    colors: {
      normal: {
        borderColor: _palette.palette.koala
      },
      success: {
        borderColor: _palette.palette.signal.green
      },
      warning: {
        borderColor: _palette.palette.signal.orange
      },
      error: {
        borderColor: _palette.palette.signal.red
      }
    },
    addon: {
      sizes: {
        small: {
          minWidth: 32,
          fontSize: 12
        },
        medium: {
          minWidth: 40,
          fontSize: 14
        },
        large: {
          minWidth: 48,
          fontSize: 16
        }
      },
      colors: {
        normal: {
          borderColor: _palette.palette.koala,
          backgroundColor: _palette.palette.polarbear
        },
        success: {
          borderColor: _palette.alertPalette.success.main,
          backgroundColor: _palette.alertPalette.success.background
        },
        warning: {
          borderColor: _palette.alertPalette.warning.main,
          backgroundColor: _palette.alertPalette.warning.background
        },
        error: {
          borderColor: _palette.alertPalette.error.main,
          backgroundColor: _palette.alertPalette.error.background
        }
      }
    },
    iconButton: {
      button: {
        sizes: {
          small: {
            height: 32 - 2,
            width: 32 - 2
          },
          medium: {
            height: 40 - 2,
            width: 40 - 2
          },
          large: {
            height: 48 - 2,
            width: 48 - 2
          }
        }
      },
      icon: {
        sizes: {
          small: _icon.iconComponentTheme.icon.size.xsmall,
          medium: _icon.iconComponentTheme.icon.size.small,
          large: _icon.iconComponentTheme.icon.size.medium
        }
      }
    },
    comment: {
      colors: {
        normal: {
          color: _palette.palette.elephant
        },
        success: {
          color: _palette.palette.signal.green
        },
        warning: {
          color: _palette.palette.signal.orange
        },
        error: {
          color: _palette.palette.signal.red
        }
      }
    }
  }
};
exports.inputComponentTheme = inputComponentTheme;