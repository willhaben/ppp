export declare const checkboxComponentTheme: {
    checkbox: {
        sizes: {
            small: {
                height: number;
                width: number;
            };
            medium: {
                height: number;
                width: number;
            };
            large: {
                height: number;
                width: number;
            };
            xlarge: {
                height: number;
                width: number;
            };
        };
    };
    checkboxLabel: {
        sizes: {
            small: {
                [x: string]: number | {
                    height: number;
                    width: number;
                };
                minHeight: number;
                paddingLeft: number;
                fontSize: number;
            };
            medium: {
                [x: string]: number | {
                    height: number;
                    width: number;
                };
                minHeight: number;
                paddingLeft: number;
                fontSize: number;
            };
            large: {
                [x: string]: number | {
                    height: number;
                    width: number;
                };
                minHeight: number;
                paddingLeft: number;
                fontSize: number;
            };
            xlarge: {
                [x: string]: number | {
                    height: number;
                    width: number;
                };
                minHeight: number;
                paddingLeft: number;
                fontSize: number;
            };
        };
        borderColors: {
            normal: {
                [x: string]: {
                    borderColor: string;
                };
            };
            success: {
                [x: string]: {
                    borderColor: string;
                };
            };
            warning: {
                [x: string]: {
                    borderColor: string;
                };
            };
            error: {
                [x: string]: {
                    borderColor: string;
                };
            };
        };
    };
    checkboxComment: {
        colors: {
            normal: {
                color: string;
            };
            success: {
                color: string;
            };
            warning: {
                color: string;
            };
            error: {
                color: string;
            };
        };
    };
    checkboxGroupInlineLabel: {
        sizes: {
            small: {
                height: number;
            };
            medium: {
                height: number;
            };
            large: {
                height: number;
            };
            xlarge: {
                height: number;
            };
        };
    };
};
