"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.radioComponentTheme = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/defineProperty"));

var _system = require("../../utilities/system");

var _palette = require("../palette");

var _small, _medium, _large, _xlarge;

var radioComponentTheme = {
  radio: {
    sizes: {
      small: {
        height: 16,
        width: 16
      },
      medium: {
        height: 20,
        width: 20
      },
      large: {
        height: 24,
        width: 24
      },
      xlarge: {
        height: 32,
        width: 32
      }
    }
  },
  radioLabel: {
    sizes: {
      small: (_small = {
        height: 16,
        paddingLeft: 16 + 4,
        fontSize: 12
      }, (0, _defineProperty2["default"])(_small, (0, _system.createPseudoSelector)('before'), {
        height: 16,
        width: 16
      }), (0, _defineProperty2["default"])(_small, (0, _system.createPseudoSelector)('after'), {
        height: 8,
        width: 8
      }), _small),
      medium: (_medium = {
        height: 20,
        paddingLeft: 20 + 6,
        fontSize: 14
      }, (0, _defineProperty2["default"])(_medium, (0, _system.createPseudoSelector)('before'), {
        height: 20,
        width: 20
      }), (0, _defineProperty2["default"])(_medium, (0, _system.createPseudoSelector)('after'), {
        height: 12,
        width: 12
      }), _medium),
      large: (_large = {
        height: 24,
        paddingLeft: 24 + 6,
        fontSize: 14
      }, (0, _defineProperty2["default"])(_large, (0, _system.createPseudoSelector)('before'), {
        height: 24,
        width: 24
      }), (0, _defineProperty2["default"])(_large, (0, _system.createPseudoSelector)('after'), {
        height: 16,
        width: 16
      }), _large),
      xlarge: (_xlarge = {
        height: 32,
        paddingLeft: 32 + 8,
        fontSize: 16
      }, (0, _defineProperty2["default"])(_xlarge, (0, _system.createPseudoSelector)('before'), {
        height: 32,
        width: 32
      }), (0, _defineProperty2["default"])(_xlarge, (0, _system.createPseudoSelector)('after'), {
        height: 24,
        width: 24
      }), _xlarge)
    },
    borderColors: {
      normal: (0, _defineProperty2["default"])({}, (0, _system.createPseudoSelector)('before'), {
        borderColor: _palette.palette.grey
      }),
      success: (0, _defineProperty2["default"])({}, (0, _system.createPseudoSelector)('before'), {
        borderColor: _palette.palette.signal.green
      }),
      warning: (0, _defineProperty2["default"])({}, (0, _system.createPseudoSelector)('before'), {
        borderColor: _palette.palette.signal.orange
      }),
      error: (0, _defineProperty2["default"])({}, (0, _system.createPseudoSelector)('before'), {
        borderColor: _palette.palette.signal.red
      })
    }
  },
  radioGroupInlineLabel: {
    sizes: {
      small: {
        height: 16 + 6 // the height values are all nudged into place, so the label is baseline aligned with the first radio label

      },
      medium: {
        height: 20 + 8
      },
      large: {
        height: 24 + 8
      },
      xlarge: {
        height: 32 + 8
      }
    }
  }
};
exports.radioComponentTheme = radioComponentTheme;