"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.rangeComponentTheme = void 0;

var _palette = require("../palette");

var rangeComponentTheme = {
  range: {
    sizes: {
      input: {
        small: {
          height: 16
        },
        medium: {
          height: 20
        },
        large: {
          height: 24
        }
      },
      thumb: {
        small: {
          height: 16,
          width: 16
        },
        medium: {
          height: 20,
          width: 20
        },
        large: {
          height: 24,
          width: 24
        }
      },
      track: {
        small: {
          height: 6
        },
        medium: {
          height: 8
        },
        large: {
          height: 8
        }
      },
      chrome: {
        small: {
          marginTop: -5
        },
        medium: {
          marginTop: -6
        },
        large: {
          marginTop: -8
        }
      },
      ie11: {
        small: {
          borderTopWidth: 5,
          borderBottomWidth: 5
        },
        medium: {
          borderTopWidth: 6,
          borderBottomWidth: 6
        },
        large: {
          borderTopWidth: 8,
          borderBottomWidth: 8
        }
      }
    },
    colors: {
      primary: {
        backgroundColor: _palette.buttonPalette.primary.normal
      },
      secondary: {
        backgroundColor: _palette.buttonPalette.secondary.normal
      },
      complimentary: {
        backgroundColor: _palette.buttonPalette.complimentary.normal
      },
      accent: {
        backgroundColor: _palette.buttonPalette.accent.normal
      }
    }
  }
};
exports.rangeComponentTheme = rangeComponentTheme;