"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.checkboxComponentTheme = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/defineProperty"));

var _system = require("../../utilities/system");

var _palette = require("../palette");

var checkboxComponentTheme = {
  checkbox: {
    sizes: {
      small: {
        height: 16,
        width: 16
      },
      medium: {
        height: 20,
        width: 20
      },
      large: {
        height: 24,
        width: 24
      },
      xlarge: {
        height: 32,
        width: 32
      }
    }
  },
  checkboxLabel: {
    sizes: {
      small: (0, _defineProperty2["default"])({
        minHeight: 16,
        paddingLeft: 16 + 4,
        fontSize: 12
      }, (0, _system.createPseudoSelector)('before'), {
        height: 16,
        width: 16
      }),
      medium: (0, _defineProperty2["default"])({
        minHeight: 20,
        paddingLeft: 20 + 6,
        fontSize: 14
      }, (0, _system.createPseudoSelector)('before'), {
        height: 20,
        width: 20
      }),
      large: (0, _defineProperty2["default"])({
        minHeight: 24,
        paddingLeft: 24 + 6,
        fontSize: 14
      }, (0, _system.createPseudoSelector)('before'), {
        height: 24,
        width: 24
      }),
      xlarge: (0, _defineProperty2["default"])({
        minHeight: 32,
        paddingLeft: 32 + 8,
        fontSize: 16
      }, (0, _system.createPseudoSelector)('before'), {
        height: 32,
        width: 32
      })
    },
    borderColors: {
      normal: (0, _defineProperty2["default"])({}, (0, _system.createPseudoSelector)('before'), {
        borderColor: _palette.palette.grey
      }),
      success: (0, _defineProperty2["default"])({}, (0, _system.createPseudoSelector)('before'), {
        borderColor: _palette.palette.signal.green
      }),
      warning: (0, _defineProperty2["default"])({}, (0, _system.createPseudoSelector)('before'), {
        borderColor: _palette.palette.signal.orange
      }),
      error: (0, _defineProperty2["default"])({}, (0, _system.createPseudoSelector)('before'), {
        borderColor: _palette.palette.signal.red
      })
    }
  },
  checkboxComment: {
    colors: {
      normal: {
        color: _palette.palette.elephant
      },
      success: {
        color: _palette.palette.signal.green
      },
      warning: {
        color: _palette.palette.signal.orange
      },
      error: {
        color: _palette.palette.signal.red
      }
    }
  },
  checkboxGroupInlineLabel: {
    sizes: {
      small: {
        height: 16 + 6 // the height values are all nudged into place, so the label is baseline aligned with the first radio label

      },
      medium: {
        height: 20 + 8
      },
      large: {
        height: 24 + 8
      },
      xlarge: {
        height: 32 + 8
      }
    }
  }
};
exports.checkboxComponentTheme = checkboxComponentTheme;