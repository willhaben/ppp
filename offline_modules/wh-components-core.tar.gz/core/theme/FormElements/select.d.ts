export declare const selectComponentTheme: {
    select: {
        sizes: {
            small: {
                height: number;
                paddingRight: string;
                fontSize: number;
            };
            medium: {
                height: number;
                paddingRight: string;
                fontSize: number;
            };
            large: {
                height: number;
                paddingRight: string;
                fontSize: number;
            };
        };
        colors: {
            normal: {
                borderColor: string;
            };
            success: {
                borderColor: string;
            };
            warning: {
                borderColor: string;
            };
            error: {
                borderColor: string;
            };
        };
        icon: {
            sizes: {
                small: {
                    backgroundSize: string;
                    backgroundPosition: string;
                };
                medium: {
                    backgroundSize: string;
                    backgroundPosition: string;
                };
                large: {
                    backgroundSize: string;
                    backgroundPosition: string;
                };
            };
        };
    };
};
