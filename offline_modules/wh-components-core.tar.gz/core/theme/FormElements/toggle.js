"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.toggleComponentTheme = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/defineProperty"));

var _system = require("../../utilities/system");

var _palette = require("../../theme/palette");

var toggleComponentTheme = {
  toggle: {
    sizes: {
      small: (0, _defineProperty2["default"])({
        height: 20,
        minWidth: 32,
        borderRadius: 10,
        fontSize: 10
      }, (0, _system.createPseudoSelector)('after'), {
        height: 12,
        width: 12
      }),
      medium: (0, _defineProperty2["default"])({
        height: 24,
        minWidth: 44,
        borderRadius: 12,
        fontSize: 12
      }, (0, _system.createPseudoSelector)('after'), {
        height: 16,
        width: 16
      }),
      large: (0, _defineProperty2["default"])({
        height: 32,
        minWidth: 64,
        borderRadius: 16,
        fontSize: 14
      }, (0, _system.createPseudoSelector)('after'), {
        height: 24,
        width: 24
      })
    },
    colors: {
      primary: {
        backgroundColor: _palette.buttonPalette.primary.normal
      },
      secondary: {
        backgroundColor: _palette.buttonPalette.secondary.normal
      },
      complimentary: {
        backgroundColor: _palette.buttonPalette.complimentary.normal
      },
      accent: {
        backgroundColor: _palette.buttonPalette.accent.normal
      },
      success: {
        backgroundColor: _palette.alertPalette.success.main
      },
      warning: {
        backgroundColor: _palette.alertPalette.warning.main
      },
      error: {
        backgroundColor: _palette.alertPalette.error.main
      }
    }
  }
};
exports.toggleComponentTheme = toggleComponentTheme;