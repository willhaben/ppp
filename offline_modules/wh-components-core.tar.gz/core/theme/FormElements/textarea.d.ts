export declare const textareaComponentTheme: {
    textarea: {
        sizes: {
            small: {
                fontSize: number;
            };
            medium: {
                fontSize: number;
            };
            large: {
                fontSize: number;
            };
        };
    };
};
