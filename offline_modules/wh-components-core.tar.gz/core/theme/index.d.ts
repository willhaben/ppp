export declare const baseFontSize = 14;
export declare const theme: {
    layout: number;
    lineHeights: {
        paragraph: number;
        heading: number;
    };
    fontWeights: {
        light: number;
        regular: number;
        semibold: number;
        bold: number;
        extrabold: number;
    };
    fontSizes: {
        xxxl: string;
        xxl: string;
        xl: string;
        l: string;
        m: string;
        s: string;
        xs: string;
    };
    fontFamilies: {
        sansSerif: string;
    };
    borders: {
        panther: string;
        raccoon: string;
        elephant: string;
        koala: string;
        seal: string;
        owl: string;
        dove: string;
        babyseal: string;
        polarbear: string;
    };
    borderRadii: {
        s: number;
        m: number;
        l: number;
        xl: number;
    };
    borderRadius: number;
    media: {
        tablet: string;
        desktop: string;
        print: string;
        only: {
            phone: string;
            tablet: string;
        };
        browser: {
            ie11: string;
        };
    };
    colors: {
        palette: {
            primary: {
                main: string;
                active: string;
                hover: string;
                disabled: string;
            };
            secondary: {
                main: string;
                active: string;
                hover: string;
                disabled: string;
            };
            accent: {
                primary: {
                    main: string;
                    active: string;
                    hover: string;
                    disabled: string;
                };
                secondary: {
                    main: string;
                    active: string;
                    hover: string;
                    disabled: string;
                };
            };
            signal: {
                red: string;
                orange: string;
                green: string;
            };
            coral: string;
            tangerine: string;
            jungle: string;
            lavender: string;
            petrol: string;
            lagoon: string;
            honeydew: string;
            panther: string;
            raccoon: string;
            elephant: string;
            koala: string;
            seal: string;
            owl: string;
            dove: string;
            babyseal: string;
            polarbear: string;
            black: string;
            verydarkgrey: string;
            darkgrey: string;
            grey: string;
            lightgrey: string;
            verylightgrey: string;
            white: string;
        };
        adStatus: {
            active: string;
            inactive: string;
            rejected: string;
            expired: string;
        };
        socialMedia: {
            facebook: string;
            google: string;
            instagram: string;
            kununu: string;
            linkedin: string;
            messenger: string;
            twitch: string;
            twitter: string;
            video: string;
            vimeo: string;
            whatsapp: string;
            xing: string;
            youtube: string;
        };
        heatMap: {
            low: string;
            middle: string;
            moderate: string;
            high: string;
            veryHigh: string;
        };
        alert: {
            success: {
                main: string;
                background: string;
            };
            warning: {
                main: string;
                background: string;
            };
            error: {
                main: string;
                background: string;
            };
            info: {
                main: string;
                background: string;
            };
        };
        background: {
            default: string;
        };
    };
    zIndices: {
        backgroundAd: number;
        content: number;
        popover: number;
        stickyContent: number;
        overlay: number;
        header: number;
        wash: number;
        modal: number;
        banner: number;
        overlayAd: number;
    };
    breakpoints: {
        tablet: number;
        desktop: number;
    };
    print: {
        breakpoint: string;
    };
    space: {
        xxs: number;
        xs: number;
        s: number;
        sm: number;
        m: number;
        l: number;
        xl: number;
        xxl: number;
        xxxl: number;
        xxxxl: number;
    };
    components: {
        range: {
            sizes: {
                input: {
                    small: {
                        height: number;
                    };
                    medium: {
                        height: number;
                    };
                    large: {
                        height: number;
                    };
                };
                thumb: {
                    small: {
                        height: number;
                        width: number;
                    };
                    medium: {
                        height: number;
                        width: number;
                    };
                    large: {
                        height: number;
                        width: number;
                    };
                };
                track: {
                    small: {
                        height: number;
                    };
                    medium: {
                        height: number;
                    };
                    large: {
                        height: number;
                    };
                };
                chrome: {
                    small: {
                        marginTop: number;
                    };
                    medium: {
                        marginTop: number;
                    };
                    large: {
                        marginTop: number;
                    };
                };
                ie11: {
                    small: {
                        borderTopWidth: number;
                        borderBottomWidth: number;
                    };
                    medium: {
                        borderTopWidth: number;
                        borderBottomWidth: number;
                    };
                    large: {
                        borderTopWidth: number;
                        borderBottomWidth: number;
                    };
                };
            };
            colors: {
                primary: {
                    backgroundColor: string;
                };
                secondary: {
                    backgroundColor: string;
                };
                complimentary: {
                    backgroundColor: string;
                };
                accent: {
                    backgroundColor: string;
                };
            };
        };
        avatar: {
            sizes: {
                xsmall: number;
                small: number;
                medium: number;
                large: number;
                xlarge: number;
            };
        };
        toggle: {
            sizes: {
                small: {
                    [x: string]: number | {
                        height: number;
                        width: number;
                    };
                    height: number;
                    minWidth: number;
                    borderRadius: number;
                    fontSize: number;
                };
                medium: {
                    [x: string]: number | {
                        height: number;
                        width: number;
                    };
                    height: number;
                    minWidth: number;
                    borderRadius: number;
                    fontSize: number;
                };
                large: {
                    [x: string]: number | {
                        height: number;
                        width: number;
                    };
                    height: number;
                    minWidth: number;
                    borderRadius: number;
                    fontSize: number;
                };
            };
            colors: {
                primary: {
                    backgroundColor: string;
                };
                secondary: {
                    backgroundColor: string;
                };
                complimentary: {
                    backgroundColor: string;
                };
                accent: {
                    backgroundColor: string;
                };
                success: {
                    backgroundColor: string;
                };
                warning: {
                    backgroundColor: string;
                };
                error: {
                    backgroundColor: string;
                };
            };
        };
        select: {
            sizes: {
                small: {
                    height: number;
                    paddingRight: string;
                    fontSize: number;
                };
                medium: {
                    height: number;
                    paddingRight: string;
                    fontSize: number;
                };
                large: {
                    height: number;
                    paddingRight: string;
                    fontSize: number;
                };
            };
            colors: {
                normal: {
                    borderColor: string;
                };
                success: {
                    borderColor: string;
                };
                warning: {
                    borderColor: string;
                };
                error: {
                    borderColor: string;
                };
            };
            icon: {
                sizes: {
                    small: {
                        backgroundSize: string;
                        backgroundPosition: string;
                    };
                    medium: {
                        backgroundSize: string;
                        backgroundPosition: string;
                    };
                    large: {
                        backgroundSize: string;
                        backgroundPosition: string;
                    };
                };
            };
        };
        textarea: {
            sizes: {
                small: {
                    fontSize: number;
                };
                medium: {
                    fontSize: number;
                };
                large: {
                    fontSize: number;
                };
            };
        };
        input: {
            sizes: {
                small: {
                    height: number;
                    fontSize: number;
                };
                medium: {
                    height: number;
                    fontSize: number;
                };
                large: {
                    height: number;
                    fontSize: number;
                };
            };
            colors: {
                normal: {
                    borderColor: string;
                };
                success: {
                    borderColor: string;
                };
                warning: {
                    borderColor: string;
                };
                error: {
                    borderColor: string;
                };
            };
            addon: {
                sizes: {
                    small: {
                        minWidth: number;
                        fontSize: number;
                    };
                    medium: {
                        minWidth: number;
                        fontSize: number;
                    };
                    large: {
                        minWidth: number;
                        fontSize: number;
                    };
                };
                colors: {
                    normal: {
                        borderColor: string;
                        backgroundColor: string;
                    };
                    success: {
                        borderColor: string;
                        backgroundColor: string;
                    };
                    warning: {
                        borderColor: string;
                        backgroundColor: string;
                    };
                    error: {
                        borderColor: string;
                        backgroundColor: string;
                    };
                };
            };
            iconButton: {
                button: {
                    sizes: {
                        small: {
                            height: number;
                            width: number;
                        };
                        medium: {
                            height: number;
                            width: number;
                        };
                        large: {
                            height: number;
                            width: number;
                        };
                    };
                };
                icon: {
                    sizes: {
                        small: number;
                        medium: number;
                        large: number;
                    };
                };
            };
            comment: {
                colors: {
                    normal: {
                        color: string;
                    };
                    success: {
                        color: string;
                    };
                    warning: {
                        color: string;
                    };
                    error: {
                        color: string;
                    };
                };
            };
        };
        spinner: {
            sizes: {
                small: {
                    height: number;
                    width: number;
                    borderWidth: number;
                };
                medium: {
                    height: number;
                    width: number;
                    borderWidth: number;
                };
                large: {
                    height: number;
                    width: number;
                    borderWidth: number;
                };
            };
            colors: {
                primary: {
                    borderLeftColor: string;
                };
                secondary: {
                    borderLeftColor: string;
                };
                complimentary: {
                    borderLeftColor: string;
                };
                accent: {
                    borderLeftColor: string;
                };
            };
            speeds: {
                slow: {
                    animationDuration: string;
                };
                medium: {
                    animationDuration: string;
                };
                fast: {
                    animationDuration: string;
                };
            };
        };
        alert: {
            colors: {
                info: {
                    color: string;
                    backgroundColor: string;
                };
                success: {
                    color: string;
                    backgroundColor: string;
                };
                warning: {
                    color: string;
                    backgroundColor: string;
                };
                error: {
                    color: string;
                    backgroundColor: string;
                };
            };
        };
        radio: {
            sizes: {
                small: {
                    height: number;
                    width: number;
                };
                medium: {
                    height: number;
                    width: number;
                };
                large: {
                    height: number;
                    width: number;
                };
                xlarge: {
                    height: number;
                    width: number;
                };
            };
        };
        radioLabel: {
            sizes: {
                small: {
                    [x: string]: number | {
                        height: number;
                        width: number;
                    };
                    height: number;
                    paddingLeft: number;
                    fontSize: number;
                };
                medium: {
                    [x: string]: number | {
                        height: number;
                        width: number;
                    };
                    height: number;
                    paddingLeft: number;
                    fontSize: number;
                };
                large: {
                    [x: string]: number | {
                        height: number;
                        width: number;
                    };
                    height: number;
                    paddingLeft: number;
                    fontSize: number;
                };
                xlarge: {
                    [x: string]: number | {
                        height: number;
                        width: number;
                    };
                    height: number;
                    paddingLeft: number;
                    fontSize: number;
                };
            };
            borderColors: {
                normal: {
                    [x: string]: {
                        borderColor: string;
                    };
                };
                success: {
                    [x: string]: {
                        borderColor: string;
                    };
                };
                warning: {
                    [x: string]: {
                        borderColor: string;
                    };
                };
                error: {
                    [x: string]: {
                        borderColor: string;
                    };
                };
            };
        };
        radioGroupInlineLabel: {
            sizes: {
                small: {
                    height: number;
                };
                medium: {
                    height: number;
                };
                large: {
                    height: number;
                };
                xlarge: {
                    height: number;
                };
            };
        };
        checkbox: {
            sizes: {
                small: {
                    height: number;
                    width: number;
                };
                medium: {
                    height: number;
                    width: number;
                };
                large: {
                    height: number;
                    width: number;
                };
                xlarge: {
                    height: number;
                    width: number;
                };
            };
        };
        checkboxLabel: {
            sizes: {
                small: {
                    [x: string]: number | {
                        height: number;
                        width: number;
                    };
                    minHeight: number;
                    paddingLeft: number;
                    fontSize: number;
                };
                medium: {
                    [x: string]: number | {
                        height: number;
                        width: number;
                    };
                    minHeight: number;
                    paddingLeft: number;
                    fontSize: number;
                };
                large: {
                    [x: string]: number | {
                        height: number;
                        width: number;
                    };
                    minHeight: number;
                    paddingLeft: number;
                    fontSize: number;
                };
                xlarge: {
                    [x: string]: number | {
                        height: number;
                        width: number;
                    };
                    minHeight: number;
                    paddingLeft: number;
                    fontSize: number;
                };
            };
            borderColors: {
                normal: {
                    [x: string]: {
                        borderColor: string;
                    };
                };
                success: {
                    [x: string]: {
                        borderColor: string;
                    };
                };
                warning: {
                    [x: string]: {
                        borderColor: string;
                    };
                };
                error: {
                    [x: string]: {
                        borderColor: string;
                    };
                };
            };
        };
        checkboxComment: {
            colors: {
                normal: {
                    color: string;
                };
                success: {
                    color: string;
                };
                warning: {
                    color: string;
                };
                error: {
                    color: string;
                };
            };
        };
        checkboxGroupInlineLabel: {
            sizes: {
                small: {
                    height: number;
                };
                medium: {
                    height: number;
                };
                large: {
                    height: number;
                };
                xlarge: {
                    height: number;
                };
            };
        };
        icon: {
            size: {
                xxsmall: number;
                xsmall: number;
                small: number;
                medium: number;
                large: number;
                xlarge: number;
            };
        };
        button: {
            sizes: {
                xsmall: {
                    height: number;
                    minWidth: number;
                    paddingLeft: number;
                    paddingRight: number;
                    fontSize: number;
                };
                small: {
                    height: number;
                    minWidth: number;
                    paddingLeft: number;
                    paddingRight: number;
                    fontSize: number;
                };
                medium: {
                    height: number;
                    minWidth: number;
                    paddingLeft: number;
                    paddingRight: number;
                    fontSize: number;
                };
                large: {
                    height: number;
                    minWidth: number;
                    paddingLeft: number;
                    paddingRight: number;
                    fontSize: number;
                };
            };
            colors: Record<string, import("styled-components").CSSObject>;
        };
        iconButton: {
            sizes: {
                xsmall: {
                    height: number;
                    width: number;
                };
                small: {
                    height: number;
                    width: number;
                };
                medium: {
                    height: number;
                    width: number;
                };
                large: {
                    height: number;
                    width: number;
                };
            };
        };
    };
};
export declare type ComponentsTheme = typeof theme;
