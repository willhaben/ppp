"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.iconComponentTheme = void 0;
var iconComponentTheme = {
  icon: {
    size: {
      xxsmall: 8,
      xsmall: 16,
      small: 20,
      medium: 24,
      large: 28,
      xlarge: 32
    }
  }
};
exports.iconComponentTheme = iconComponentTheme;