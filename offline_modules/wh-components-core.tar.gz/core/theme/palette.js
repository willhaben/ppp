"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.alertPalette = exports.buttonPalette = exports.palette = void 0;
var palette = {
  primary: {
    main: '#00a4e8',
    active: '#0083c3',
    hover: '#008fd2',
    disabled: '#98e2ff'
  },
  secondary: {
    main: '#aab4c7',
    active: '#8890a4',
    hover: '#9aa3b9',
    disabled: '#cad3e1'
  },
  accent: {
    primary: {
      main: '#efaa54',
      active: '#ce872d',
      hover: '#db954b',
      disabled: '#f2c182'
    },
    secondary: {
      main: '#f16373',
      active: '#b54f5c',
      hover: '#d55867',
      disabled: '#f6a1ab'
    }
  },
  signal: {
    red: '#ff0000',
    orange: '#ff9000',
    green: '#00aa00'
  },
  coral: '#f16373',
  tangerine: '#efaa54',
  jungle: '#1f9f7e',
  lavender: '#826eab',
  petrol: '#459ac6',
  lagoon: '#20c1ff',
  honeydew: '#e6fee4',
  // Greys
  panther: '#3c454c',
  raccoon: '#5d6675',
  elephant: '#8e99ac',
  koala: '#aab4c4',
  seal: '#cad3e1',
  owl: '#e0e6f0',
  dove: '#e9eef8',
  babyseal: '#f4f6fb',
  polarbear: '#f9fafd',
  // Pure Greys
  black: '#000000',
  verydarkgrey: '#333333',
  darkgrey: '#666666',
  grey: '#999999',
  lightgrey: '#cccccc',
  verylightgrey: '#eeeeee',
  white: '#ffffff'
};
exports.palette = palette;
var buttonPalette = {
  primary: {
    normal: palette.primary.main,
    active: '#0083c3',
    hover: '#008fd2',
    disabled: '#98e2ff',
    shadow: '#98e2ff'
  },
  complimentary: {
    normal: palette.koala,
    active: '#8890a4',
    hover: '#9aa3b9',
    disabled: '#cad3e1',
    shadow: '#98e2ff'
  },
  secondary: {
    normal: palette.tangerine,
    active: '#ce872d',
    hover: '#db954b',
    disabled: '#f2c182',
    shadow: '#f2c182'
  },
  accent: {
    normal: palette.coral,
    active: '#b54f5c',
    hover: '#d55867',
    disabled: '#f6a1ab',
    shadow: '#f6a1ab'
  }
};
exports.buttonPalette = buttonPalette;
var alertPalette = {
  info: {
    main: palette.primary.main,
    background: '#e5f5fc'
  },
  success: {
    main: palette.signal.green,
    background: '#e5f6e5'
  },
  warning: {
    main: palette.signal.orange,
    background: '#fff3e5'
  },
  error: {
    main: palette.signal.red,
    background: '#ffe5e5'
  }
};
exports.alertPalette = alertPalette;