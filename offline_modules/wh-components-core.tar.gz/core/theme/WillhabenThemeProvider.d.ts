import { ReactChild, FunctionComponent } from 'react';
import { DefaultTheme } from 'styled-components';
interface WillhabenThemeProviderProps {
    theme?: DefaultTheme;
    children?: ReactChild;
}
export declare const WillhabenThemeProvider: FunctionComponent<WillhabenThemeProviderProps>;
export {};
