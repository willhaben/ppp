export declare const avatarComponentTheme: {
    avatar: {
        sizes: {
            xsmall: number;
            small: number;
            medium: number;
            large: number;
            xlarge: number;
        };
    };
};
