"use strict";

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.spaceTheme = void 0;
var baseSpace = 8;
var spaceTheme = {
  space: {
    xxs: baseSpace * 0.25,
    xs: baseSpace * 0.5,
    s: baseSpace,
    sm: baseSpace * 1.5,
    m: baseSpace * 2.0,
    l: baseSpace * 3.0,
    xl: baseSpace * 4.0,
    xxl: baseSpace * 5.0,
    xxxl: baseSpace * 6.0,
    xxxxl: baseSpace * 7.0
  }
};
exports.spaceTheme = spaceTheme;