import { HTMLAttributes } from 'react';
export declare type Booleanish = boolean | 'true' | 'false';
export interface NoChildrenProps {
    children?: undefined;
}
export interface TestProps {
    testId?: string;
}
export declare const testIdAttribute: <T extends TestProps>(props: T) => {
    'data-testid': string | undefined;
};
export declare type ClassNameProps = Pick<HTMLAttributes<HTMLElement>, 'className'>;
export declare const classNamePropKeys: Readonly<(keyof ClassNameProps)[]>;
export declare type IdProps = Pick<HTMLAttributes<HTMLElement>, 'id'>;
export declare const idPropKeys: Readonly<(keyof IdProps)[]>;
export declare type InputSize = 'small' | 'medium' | 'large';
export declare type InputState = 'normal' | 'success' | 'warning' | 'error';
