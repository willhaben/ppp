import { TestProps } from '../common';
import { SpaceProps } from '@wh-components/system/space';
import { WidthProps, DisplayProps } from '@wh-components/system/layout';
import { FlexItemProps } from '@wh-components/system/flexbox';
import { ColorProps } from '@wh-components/system/color';
import { TypographyProps } from '@wh-components/system/typography';
export interface TextProps extends TestProps, SpaceProps, WidthProps, DisplayProps, FlexItemProps, TypographyProps, ColorProps<any> {
    breakWord?: boolean;
    lineClamp?: number;
    truncate?: boolean;
}
export declare const Text: import("styled-components").StyledComponent<"span", import("styled-components").DefaultTheme, {
    'data-testid': string | undefined;
} & TextProps, "data-testid">;
