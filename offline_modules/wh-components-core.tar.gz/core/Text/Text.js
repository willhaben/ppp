"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Text = void 0;

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _system = require("@wh-components/system");

var _common = require("../common");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _flexbox = require("@wh-components/system/flexbox");

var _color = require("@wh-components/system/color");

var _typography = require("@wh-components/system/typography");

var breakWordStyles = (0, _styledComponents.css)(["word-break:break-word;overflow-wrap:break-word;word-wrap:break-word;"]);

var lineClampStyles = function lineClampStyles(lines, background) {
  return (0, _styledComponents.css)(["display:inline-block;max-height:calc(1.5em * ", ");position:relative;overflow:hidden;padding-right:1em;text-align:justify;&:before{content:'...';position:absolute;bottom:0;right:0;}&:after{content:'';position:absolute;right:0;height:1.5em;width:1em;", "}@supports (-webkit-line-clamp:2){max-height:initial;position:initial;padding-right:initial;text-align:initial;display:-webkit-box;-webkit-line-clamp:", ";-webkit-box-orient:vertical;&:before,&:after{content:none;}}"], lines, background ? _color.color : "background-color: white;", lines);
};

var truncateStyles = (0, _styledComponents.css)(["display:inline-block;max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"]);

var Text = _styledComponents["default"].span.attrs(_common.testIdAttribute).withConfig({
  displayName: "Text",
  componentId: "sc-10o2fdq-0"
})(["margin:0;", " ", " ", " ", ""], function (p) {
  return p.breakWord && breakWordStyles;
}, function (p) {
  return p.lineClamp && (p.lineClamp > 1 ? lineClampStyles(p.lineClamp, !!p.backgroundColor) : truncateStyles);
}, function (p) {
  return p.truncate && !p.lineClamp && truncateStyles;
}, (0, _system.compose)(_space.space, _layout.width, _layout.display, _flexbox.flexItem, _typography.typography, _color.color));

exports.Text = Text;
Text.defaultProps = {
  lineHeight: 'paragraph'
};