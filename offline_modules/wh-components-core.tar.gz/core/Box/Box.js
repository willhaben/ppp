"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Box = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _system = require("@wh-components/system");

var _common = require("../common");

var _animation = require("@wh-components/system/animation");

var _background = require("@wh-components/system/background");

var _border = require("@wh-components/system/border");

var _color = require("@wh-components/system/color");

var _flexbox = require("@wh-components/system/flexbox");

var _grid = require("@wh-components/system/grid");

var _layout = require("@wh-components/system/layout");

var _position = require("@wh-components/system/position");

var _shadow = require("@wh-components/system/shadow");

var _space = require("@wh-components/system/space");

var _typography = require("@wh-components/system/typography");

var Box = _styledComponents["default"].div.attrs(_common.testIdAttribute).withConfig({
  displayName: "Box",
  componentId: "wfmb7k-0"
})((0, _system.compose)(_animation.animation, _background.background, _border.border, _color.color, _flexbox.flexbox, _grid.grid, _layout.layout, _position.position, _shadow.shadow, _space.space, _typography.typography));

exports.Box = Box;