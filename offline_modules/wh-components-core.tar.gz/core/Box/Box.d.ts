import { TestProps } from '../common';
import { AnimationProps } from '@wh-components/system/animation';
import { BackgroundProps } from '@wh-components/system/background';
import { BorderProps } from '@wh-components/system/border';
import { ColorProps } from '@wh-components/system/color';
import { FlexboxProps } from '@wh-components/system/flexbox';
import { GridProps } from '@wh-components/system/grid';
import { LayoutProps } from '@wh-components/system/layout';
import { PositionProps } from '@wh-components/system/position';
import { ShadowProps } from '@wh-components/system/shadow';
import { SpaceProps } from '@wh-components/system/space';
import { TypographyProps } from '@wh-components/system/typography';
export declare type BoxProps = TestProps & AnimationProps & BackgroundProps & BorderProps & ColorProps<any> & FlexboxProps & GridProps & LayoutProps & PositionProps & ShadowProps & SpaceProps & TypographyProps;
export declare const Box: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {
    'data-testid': string | undefined;
} & TestProps & AnimationProps & BackgroundProps & BorderProps & ColorProps<any> & import("@wh-components/system/flexbox").FlexContainerProps & import("@wh-components/system/flexbox").FlexItemProps & GridProps & import("@wh-components/system/layout").HeightProps & import("@wh-components/system/layout").WidthProps & import("@wh-components/system/layout").DisplayProps & import("@wh-components/system/layout").OverflowProps & PositionProps & ShadowProps & import("@wh-components/system/space").MarginProps & import("@wh-components/system/space").PaddingProps & TypographyProps, "data-testid">;
