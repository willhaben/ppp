"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Wash = exports.LoadingWash = void 0;

var _react = _interopRequireWildcard(require("react"));

var _reactDom = _interopRequireDefault(require("react-dom"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _common = require("../common");

var _useIsMounted = require("../hooks/useIsMounted");

var _Spinner = require("../Spinner/Spinner");

var _BlockBodyScroll = require("../BlockBodyScroll/BlockBodyScroll");

var LoadingWash = function LoadingWash(_ref) {
  var _ref$variant = _ref.variant,
      variant = _ref$variant === void 0 ? 'light' : _ref$variant,
      testId = _ref.testId;
  return (0, _useIsMounted.useIsMounted)() ? /*#__PURE__*/_reactDom["default"].createPortal( /*#__PURE__*/_react["default"].createElement(_react.Fragment, null, /*#__PURE__*/_react["default"].createElement(_BlockBodyScroll.BlockBodyScroll, null), /*#__PURE__*/_react["default"].createElement(Wash, {
    variant: variant,
    testId: testId || 'loading-wash'
  }, /*#__PURE__*/_react["default"].createElement(_Spinner.Spinner, null))), document.body) : null;
};

exports.LoadingWash = LoadingWash;

var Wash = _styledComponents["default"].div.attrs(_common.testIdAttribute).withConfig({
  displayName: "LoadingWash__Wash",
  componentId: "i3lhh3-0"
})(["display:flex;align-items:center;justify-content:center;position:fixed;top:0;right:0;bottom:0;left:0;background-color:", ";z-index:", ";"], function (p) {
  return p.variant === 'light' ? 'rgba(255, 255, 255, 0.6)' : 'rgba(0, 0, 0, 0.3)';
}, function (p) {
  return p.theme.zIndices.wash;
});

exports.Wash = Wash;
Wash.defaultProps = {
  variant: 'light'
};