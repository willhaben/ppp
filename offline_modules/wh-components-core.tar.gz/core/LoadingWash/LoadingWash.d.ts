import { FunctionComponent } from 'react';
import { TestProps } from '../common';
declare type WashVariant = 'light' | 'dark';
interface WashProps extends TestProps {
    variant?: WashVariant;
}
export declare const LoadingWash: FunctionComponent<WashProps>;
export declare const Wash: import("styled-components").StyledComponent<"div", import("styled-components").DefaultTheme, {
    'data-testid': string | undefined;
} & WashProps, "data-testid">;
export {};
