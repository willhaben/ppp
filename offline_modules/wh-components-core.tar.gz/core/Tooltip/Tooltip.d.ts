import { FunctionComponent, ReactChild } from 'react';
import { TypographyProps } from '@wh-components/system/typography';
import { WillhabenTippyProps } from './Tippy';
interface TooltipProps extends TypographyProps, Pick<WillhabenTippyProps, 'enabled' | 'maxWidth' | 'placement' | 'showOnCreate'> {
    content: ReactChild;
    children: JSX.Element;
    css?: never;
}
export declare const Tooltip: FunctionComponent<TooltipProps>;
export {};
