import { TippyProps as ReactTippyProps } from '@tippy.js/react';
import { Plugin, LifecycleHooks } from 'tippy.js';
interface CustomProps {
    testId: string;
    closeOnClick: boolean;
    closeOnEsc: boolean;
    focusButtonAfterClose: boolean;
}
declare type FilteredProps = Partial<CustomProps> & Omit<ReactTippyProps, keyof CustomProps | keyof LifecycleHooks>;
declare type ExtendedProps = FilteredProps & Partial<LifecycleHooks<FilteredProps>>;
export declare const testIdPlugin: Plugin<ExtendedProps>;
export declare const closeOnClickPlugin: Plugin<ExtendedProps>;
export declare const closeOnEscPlugin: Plugin<ExtendedProps>;
export declare const focusButtonAfterClosePlugin: Plugin<ExtendedProps>;
export declare type TippyPluginProps = Omit<ExtendedProps, 'plugins'> & {
    plugins?: Plugin<ExtendedProps>[];
};
export declare const TippyWithPluginProps: import("react").ForwardRefExoticComponent<TippyPluginProps>;
export {};
