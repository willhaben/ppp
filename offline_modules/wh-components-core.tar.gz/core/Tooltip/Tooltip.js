"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Tooltip = void 0;

var _includes = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/includes"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _typography = require("@wh-components/system/typography");

var _Tippy = require("./Tippy");

var Tooltip = function Tooltip(_ref) {
  var children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["children"]);
  return /*#__PURE__*/_react["default"].createElement(WillhabenTooltip, (0, _extends2["default"])({
    fontSize: "m"
  }, props), children);
};

exports.Tooltip = Tooltip;
var WillhabenTooltip = (0, _styledComponents["default"])(_Tippy.WillhabenTippy).withConfig({
  shouldForwardProp: function shouldForwardProp(prop) {
    var _context;

    return !(0, _includes["default"])(_context = _typography.typographyPropKeys).call(_context, prop);
  }
}).withConfig({
  displayName: "Tooltip__WillhabenTooltip",
  componentId: "lztikw-0"
})(["> .tippy-content{padding:", "px ", "px;", "}"], function (p) {
  return p.theme.space.s;
}, function (p) {
  return p.theme.space.sm;
}, _typography.typography);