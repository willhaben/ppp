"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.TippyWithPluginProps = exports.focusButtonAfterClosePlugin = exports.closeOnEscPlugin = exports.closeOnClickPlugin = exports.testIdPlugin = void 0;

var _react = _interopRequireDefault(require("@tippy.js/react"));

var testIdPlugin = {
  name: 'testId',
  fn: function fn(instance) {
    return {
      onCreate: function onCreate() {
        instance.props.testId && instance.popperChildren.tooltip.setAttribute('data-testid', instance.props.testId);
      }
    };
  }
};
exports.testIdPlugin = testIdPlugin;
var closeOnClickPlugin = {
  name: 'closeOnClick',
  defaultValue: true,
  fn: function fn(instance) {
    var handleOutsideClick = function handleOutsideClick(event) {
      if (instance.state.isShown && event.target !== instance.reference && !instance.popper.contains(event.target) && !instance.reference.contains(event.target)) {
        event.preventDefault();
        instance.hide();
      }
    };

    return {
      onCreate: function onCreate() {
        instance.props.closeOnClick && document.addEventListener('mousedown', handleOutsideClick);
      },
      onDestroy: function onDestroy() {
        instance.props.closeOnClick && document.removeEventListener('mousedown', handleOutsideClick);
      }
    };
  }
};
exports.closeOnClickPlugin = closeOnClickPlugin;
var closeOnEscPlugin = {
  name: 'closeOnEsc',
  defaultValue: true,
  fn: function fn(instance) {
    var handleKeyDown = function handleKeyDown(event) {
      if (event.keyCode === 27) {
        event.preventDefault();
        instance.hide();
      }
    };

    return {
      onCreate: function onCreate() {
        instance.props.closeOnEsc && instance.popperChildren.tooltip.addEventListener('keydown', handleKeyDown);
      },
      onDestroy: function onDestroy() {
        instance.props.closeOnEsc && instance.popperChildren.tooltip.removeEventListener('keydown', handleKeyDown);
      }
    };
  }
};
exports.closeOnEscPlugin = closeOnEscPlugin;
var focusButtonAfterClosePlugin = {
  name: 'focusButtonAfterClose',
  defaultValue: true,
  fn: function fn(instance) {
    return {
      onHidden: function onHidden() {
        var tippyIsOpen = document.getElementsByClassName('tippy-popper').length > 0;
        var modalIsOpen = window.getComputedStyle(document.body).getPropertyValue('overflow') === 'hidden';
        instance.props.focusButtonAfterClose && !tippyIsOpen && !modalIsOpen && instance.reference.focus();
      }
    };
  }
};
exports.focusButtonAfterClosePlugin = focusButtonAfterClosePlugin;
var TippyWithPluginProps = _react["default"];
exports.TippyWithPluginProps = TippyWithPluginProps;