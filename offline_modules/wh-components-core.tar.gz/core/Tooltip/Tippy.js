"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.WillhabenTippy = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _plugins = require("./plugins");

var WillhabenTippy = (0, _styledComponents["default"])(_plugins.TippyWithPluginProps).withConfig({
  displayName: "Tippy__WillhabenTippy",
  componentId: "sc-1kwb4hi-0"
})(["&.tippy-tooltip{color:", ";background-color:", ";box-shadow:0 0 16px 4px rgba(0,0,0,0.1),0 2px 4px rgba(0,0,0,0.15);z-index:", ";&[data-placement^='top'] > .tippy-arrow{border-top-color:#fff;}&[data-placement^='bottom'] > .tippy-arrow{border-bottom-color:#fff;}&[data-placement^='left'] > .tippy-arrow{border-left-color:#fff;}&[data-placement^='right'] > .tippy-arrow{border-right-color:#fff;}}"], function (p) {
  return p.theme.colors.palette.verydarkgrey;
}, function (p) {
  return p.theme.colors.palette.white;
}, function (p) {
  return p.theme.zIndices.popover;
});
exports.WillhabenTippy = WillhabenTippy;