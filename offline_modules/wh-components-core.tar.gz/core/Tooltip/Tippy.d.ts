import { TippyPluginProps } from './plugins';
export declare type WillhabenTippyProps = Omit<TippyPluginProps, 'animation' | 'className' | 'theme'>;
export declare const WillhabenTippy: import("styled-components").StyledComponent<import("react").ForwardRefExoticComponent<TippyPluginProps>, import("styled-components").DefaultTheme, {}, never>;
