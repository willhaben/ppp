"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Heading = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _Text = require("../Text/Text");

var Heading = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var _ref$level = _ref.level,
      level = _ref$level === void 0 ? 1 : _ref$level,
      text = _ref.text,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["level", "text"]);
  return /*#__PURE__*/_react["default"].createElement(_Text.Text, (0, _extends2["default"])({
    as: "h".concat(level)
  }, props, {
    ref: ref
  }), text);
});
exports.Heading = Heading;
Heading.defaultProps = {
  lineHeight: 'heading'
};