import React from 'react';
import { IdProps, NoChildrenProps } from '../common';
import { TextProps } from '../Text/Text';
export interface HeadingProps extends TextProps, IdProps, NoChildrenProps {
    level?: 1 | 2 | 3 | 4 | 5 | 6;
    text: string;
}
export declare const Heading: React.ForwardRefExoticComponent<HeadingProps & React.RefAttributes<HTMLHeadingElement>>;
