import { FunctionComponent, ReactElement, ReactNode } from 'react';
import { WillhabenTippyProps } from '../Tooltip/Tippy';
import { TestProps } from '@wh-components/icons/utilities/createSvgIcon';
import { WidthProps } from '@wh-components/system/layout';
export declare type DropdownItemType = {
    Icon?: ReactElement;
    label: ReactNode;
    onClick?: () => void;
} & TestProps;
declare type TippyDropdownProps = Pick<WillhabenTippyProps, 'arrow' | 'boundary' | 'distance' | 'flipBehavior' | 'placement'>;
declare type TippyLifecycleProps = Pick<WillhabenTippyProps, 'onCreate' | 'onDestroy' | 'onHidden' | 'onHide' | 'onMount' | 'onShow' | 'onShown'>;
export interface DropdownProps extends TestProps, WidthProps, TippyDropdownProps, TippyLifecycleProps {
    items: DropdownItemType[];
    header?: ReactNode;
    footer?: ReactNode;
    defaultActiveIndex?: number;
}
declare type DropdownRenderFunction = (isOpen: boolean, setIsOpen: (value: boolean) => void) => JSX.Element;
interface UncontrolledDropdownProps {
    children: DropdownRenderFunction;
    isOpen?: undefined;
    onRequestClose?: undefined;
}
interface ControlledDropdownProps {
    children: JSX.Element;
    isOpen: boolean;
    onRequestClose?: () => void;
}
export declare const Dropdown: FunctionComponent<DropdownProps & (UncontrolledDropdownProps | ControlledDropdownProps)>;
export {};
