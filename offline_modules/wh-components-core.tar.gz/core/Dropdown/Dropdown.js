"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Dropdown = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/slicedToArray"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _Tippy = require("../Tooltip/Tippy");

var _layout = require("@wh-components/system/layout");

var _useActiveIndex2 = require("../hooks/useActiveIndex");

var _plugins = require("../Tooltip/plugins");

var _utils = require("../utils");

var _Text = require("../Text/Text");

var _Box = require("../Box/Box");

/* eslint-disable no-shadow */
var isUnControlledDropdown = function isUnControlledDropdown(children) {
  return typeof children === 'function';
};

var Dropdown = function Dropdown(_ref) {
  var _ref$items = _ref.items,
      items = _ref$items === void 0 ? [] : _ref$items,
      header = _ref.header,
      footer = _ref.footer,
      _ref$defaultActiveInd = _ref.defaultActiveIndex,
      defaultActiveIndex = _ref$defaultActiveInd === void 0 ? 0 : _ref$defaultActiveInd,
      isOpen = _ref.isOpen,
      _onShow = _ref.onShow,
      _onHide = _ref.onHide,
      onRequestClose = _ref.onRequestClose,
      width = _ref.width,
      minWidth = _ref.minWidth,
      maxWidth = _ref.maxWidth,
      children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["items", "header", "footer", "defaultActiveIndex", "isOpen", "onShow", "onHide", "onRequestClose", "width", "minWidth", "maxWidth", "children"]);
  var listRef = (0, _react.useRef)(null);
  var focusableItems = (0, _react.useRef)([]);

  var _useActiveIndex = (0, _useActiveIndex2.useActiveIndex)(focusableItems.current),
      activeIndex = _useActiveIndex.activeIndex,
      focusAtIndex = _useActiveIndex.focusAtIndex,
      handleKeyDown = _useActiveIndex.handleKeyDown;

  var _useState = (0, _react.useState)(false),
      _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
      open = _useState2[0],
      setOpen = _useState2[1];

  var _open = isUnControlledDropdown(children) ? open : isOpen;

  var close = function close() {
    return isUnControlledDropdown(children) ? setOpen(false) : onRequestClose === null || onRequestClose === void 0 ? void 0 : onRequestClose();
  };

  var child = isUnControlledDropdown(children) ? children(open, function (value) {
    return setOpen(value);
  }) : children;
  return items.length ? /*#__PURE__*/_react["default"].createElement(_Box.Box, null, /*#__PURE__*/_react["default"].createElement(WillhabenDropdown, (0, _extends2["default"])({}, props, {
    hideOnClick: false,
    interactive: true,
    maxWidth: undefined,
    plugins: [_plugins.testIdPlugin, _plugins.closeOnClickPlugin, _plugins.closeOnEscPlugin, _plugins.focusButtonAfterClosePlugin],
    role: undefined,
    trigger: "manual",
    visible: _open,
    onShow: function onShow(instance) {
      focusableItems.current = (0, _utils.getFocusableElements)(listRef.current);
      focusAtIndex(defaultActiveIndex);
      _onShow === null || _onShow === void 0 ? void 0 : _onShow(instance);
    },
    onHide: function onHide(instance) {
      close();
      focusAtIndex(-1);
      _onHide === null || _onHide === void 0 ? void 0 : _onHide(instance);
    },
    content: /*#__PURE__*/_react["default"].createElement(_react.Fragment, null, header && /*#__PURE__*/_react["default"].createElement(HeaderFooterContainer, null, typeof header === 'string' ? /*#__PURE__*/_react["default"].createElement(_Text.Text, {
      fontSize: "s",
      fontWeight: "bold",
      color: "palette.verydarkgrey",
      truncate: true
    }, header) : header), /*#__PURE__*/_react["default"].createElement(List, {
      role: "menu",
      tabIndex: -1,
      width: width,
      minWidth: minWidth,
      maxWidth: maxWidth,
      onKeyDown: handleKeyDown,
      ref: listRef
    }, (0, _map["default"])(items).call(items, function (item, index) {
      return /*#__PURE__*/_react["default"].createElement(ListItem, {
        key: index,
        role: "menuitem",
        tabIndex: index === activeIndex ? 0 : -1,
        "data-testid": item.testId,
        onMouseEnter: function onMouseEnter() {
          focusAtIndex(index);
        },
        onMouseLeave: function onMouseLeave() {
          var _listRef$current;

          focusAtIndex(-1);
          (_listRef$current = listRef.current) === null || _listRef$current === void 0 ? void 0 : _listRef$current.focus();
        },
        onClick: function onClick() {
          var _item$onClick;

          (_item$onClick = item.onClick) === null || _item$onClick === void 0 ? void 0 : _item$onClick.call(item);
          close();
        },
        onKeyDown: function onKeyDown(event) {
          if (event.key === 'Enter' || event.key === ' ') {
            var _item$onClick2;

            event.preventDefault();
            (_item$onClick2 = item.onClick) === null || _item$onClick2 === void 0 ? void 0 : _item$onClick2.call(item);
            close();
          }
        }
      }, item.Icon, typeof item.label === 'string' ? /*#__PURE__*/_react["default"].createElement(_Text.Text, {
        truncate: true
      }, item.label) : item.label);
    })), footer && /*#__PURE__*/_react["default"].createElement(HeaderFooterContainer, null, footer))
  }), child)) : child;
};

exports.Dropdown = Dropdown;
Dropdown.defaultProps = {
  arrow: false,
  distance: 4,
  placement: 'bottom'
};
var WillhabenDropdown = (0, _styledComponents["default"])(_Tippy.WillhabenTippy).withConfig({
  displayName: "Dropdown__WillhabenDropdown",
  componentId: "sc-1xn6bg3-0"
})(["&.tippy-tooltip{border-radius:0;> .tippy-content{padding:0;}}"]);

var HeaderFooterContainer = _styledComponents["default"].div.withConfig({
  displayName: "Dropdown__HeaderFooterContainer",
  componentId: "sc-1xn6bg3-1"
})(["height:32px;display:flex;align-items:center;justify-content:center;padding:0 ", "px;background-color:", ";&:first-child{border-bottom:1px solid ", ";user-select:none;}&:last-child{border-top:1px solid ", ";}"], function (p) {
  return p.theme.space.sm;
}, function (p) {
  return p.theme.colors.palette.polarbear;
}, function (p) {
  return p.theme.colors.palette.owl;
}, function (p) {
  return p.theme.colors.palette.owl;
});

var List = _styledComponents["default"].div.withConfig({
  displayName: "Dropdown__List",
  componentId: "sc-1xn6bg3-2"
})(["max-height:", "px;overflow-y:auto;outline:0;", ""], 10 * 40, _layout.width);

var ListItem = _styledComponents["default"].button.withConfig({
  displayName: "Dropdown__ListItem",
  componentId: "sc-1xn6bg3-3"
})(["height:40px;width:100%;display:flex;align-items:center;padding:0 ", "px;background:transparent;border:0;font-size:", ";color:", ";outline:none;user-select:none;cursor:pointer;&:not(:last-child){border-bottom:1px solid ", ";}&:focus{background-color:", ";}"], function (p) {
  return p.theme.space.sm;
}, function (p) {
  return p.theme.fontSizes.m;
}, function (p) {
  return p.theme.colors.palette.verydarkgrey;
}, function (p) {
  return p.theme.colors.palette.owl;
}, function (p) {
  return p.theme.colors.palette.babyseal;
});