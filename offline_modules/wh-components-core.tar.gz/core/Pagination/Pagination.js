"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Pagination = void 0;

var _from = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/array/from"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _responsive = require("../utilities/responsive");

var _LinkWithButtonStyle = require("../Button/LinkWithButtonStyle");

var _Box = require("../Box/Box");

var _ArrowtinyLeft = _interopRequireDefault(require("@wh-components/icons/ArrowtinyLeft"));

var _ArrowtinyRight = _interopRequireDefault(require("@wh-components/icons/ArrowtinyRight"));

var Pagination = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var testId = _ref.testId,
      _ref$arrows = _ref.arrows,
      arrows = _ref$arrows === void 0 ? false : _ref$arrows,
      _ref$compact = _ref.compact,
      compact = _ref$compact === void 0 ? false : _ref$compact,
      currentPage = _ref.currentPage,
      _ref$disabled = _ref.disabled,
      disabled = _ref$disabled === void 0 ? false : _ref$disabled,
      _ref$ellipsis = _ref.ellipsis,
      ellipsis = _ref$ellipsis === void 0 ? false : _ref$ellipsis,
      _ref$endEllipsis = _ref.endEllipsis,
      endEllipsis = _ref$endEllipsis === void 0 ? false : _ref$endEllipsis,
      link = _ref.link,
      onClick = _ref.onClick,
      _ref$range = _ref.range,
      range = _ref$range === void 0 ? 2 : _ref$range,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'medium' : _ref$size,
      _ref$startEllipsis = _ref.startEllipsis,
      startEllipsis = _ref$startEllipsis === void 0 ? false : _ref$startEllipsis,
      totalPages = _ref.totalPages,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["testId", "arrows", "compact", "currentPage", "disabled", "ellipsis", "endEllipsis", "link", "onClick", "range", "size", "startEllipsis", "totalPages"]);
  var arrowsValue = (0, _responsive.useResponsiveGuaranteedValueWithSSRFallback)(arrows);
  var compactValue = (0, _responsive.useResponsiveGuaranteedValueWithSSRFallback)(compact);
  var rangeValue = (0, _responsive.useResponsiveGuaranteedValueWithSSRFallback)(range);
  var isPrevDisabled = disabled || currentPage === 1;
  var isNextDisabled = disabled || currentPage === totalPages;
  var pages = getRange(currentPage, totalPages, rangeValue, ellipsis || startEllipsis, ellipsis || endEllipsis);
  var onPageClick = (0, _react.useMemo)(function () {
    return function (page) {
      return function (event) {
        event.preventDefault();
        onClick === null || onClick === void 0 ? void 0 : onClick(page);
      };
    };
  }, [onClick]);
  var onEnterDown = (0, _react.useMemo)(function () {
    return function (page) {
      return function (event) {
        if (event.key === 'Enter') {
          event.preventDefault();
          onClick === null || onClick === void 0 ? void 0 : onClick(page);
        }
      };
    };
  }, [onClick]);
  return /*#__PURE__*/_react["default"].createElement(_Box.Box, (0, _extends2["default"])({
    as: "nav",
    display: "inline-block"
  }, props, {
    "aria-label": "pagination",
    testId: testId,
    ref: ref
  }), /*#__PURE__*/_react["default"].createElement(PaginationList, {
    compact: compactValue
  }, /*#__PURE__*/_react["default"].createElement("li", null, /*#__PURE__*/_react["default"].createElement(PaginationButton, {
    size: size,
    compact: compactValue,
    disabled: isPrevDisabled,
    tabIndex: !isPrevDisabled ? 0 : -1,
    href: link === null || link === void 0 ? void 0 : link(currentPage - 1),
    onClick: onPageClick(currentPage - 1),
    onKeyDown: onEnterDown(currentPage - 1),
    "aria-disabled": isPrevDisabled ? true : undefined,
    "aria-label": "Zur\xFCck zur vorigen Seite",
    testId: testId && "".concat(testId, "-previous-button")
  }, arrowsValue ? /*#__PURE__*/_react["default"].createElement(_ArrowtinyLeft["default"], {
    color: "inherit"
  }) : 'Zurück')), (0, _map["default"])(pages).call(pages, function (page, index) {
    var _context;

    return /*#__PURE__*/_react["default"].createElement("li", {
      key: index
    }, page > 0 ? /*#__PURE__*/_react["default"].createElement(PaginationItemButton, {
      size: size,
      compact: compactValue,
      disabled: disabled,
      tabIndex: !disabled ? 0 : -1,
      current: page === currentPage,
      href: page !== currentPage ? link === null || link === void 0 ? void 0 : link(page) : undefined,
      onClick: onPageClick(page),
      onKeyDown: onEnterDown(page),
      "aria-current": page === currentPage ? 'page' : undefined,
      "aria-disabled": disabled ? true : undefined,
      "aria-label": "Zur Seite ".concat(page),
      testId: testId && (0, _concat["default"])(_context = "".concat(testId, "-page-")).call(_context, page, "-button")
    }, page) : /*#__PURE__*/_react["default"].createElement(Ellipsis, {
      compact: compactValue,
      disabled: disabled,
      "data-testid": testId && "".concat(testId, "-ellipsis")
    }, "..."));
  }), /*#__PURE__*/_react["default"].createElement("li", null, /*#__PURE__*/_react["default"].createElement(PaginationButton, {
    size: size,
    compact: compactValue,
    disabled: isNextDisabled,
    tabIndex: !isNextDisabled ? 0 : -1,
    href: link === null || link === void 0 ? void 0 : link(currentPage + 1),
    onClick: onPageClick(currentPage + 1),
    onKeyDown: onEnterDown(currentPage + 1),
    "aria-disabled": isNextDisabled ? true : undefined,
    "aria-label": "Weiter zur n\xE4chsten Seite",
    testId: testId && "".concat(testId, "-next-button")
  }, arrowsValue ? /*#__PURE__*/_react["default"].createElement(_ArrowtinyRight["default"], {
    color: "inherit"
  }) : 'Weiter'))));
});
exports.Pagination = Pagination;

var PaginationList = _styledComponents["default"].ul.withConfig({
  displayName: "Pagination__PaginationList",
  componentId: "zvrf30-0"
})(["list-style:none;display:inline-flex;margin:0;padding:0;border:", ";background-color:", ";> li:not(:last-of-type){margin-right:", ";border-right:", ";}"], function (p) {
  return p.compact && "1px solid ".concat(p.theme.colors.palette.seal);
}, function (p) {
  return p.compact && p.theme.colors.palette.white;
}, function (p) {
  return !p.compact && '2px';
}, function (p) {
  return p.compact && "1px solid ".concat(p.theme.colors.palette.seal);
});

var PaginationButton = (0, _styledComponents["default"])(_LinkWithButtonStyle.LinkWithButtonStyle).attrs({
  variant: 'transparent'
}).withConfig({
  displayName: "Pagination__PaginationButton",
  componentId: "zvrf30-1"
})(["color:", ";border:", ";border-radius:", ";&:not([disabled]):hover{background-color:", ";}&[disabled]{color:", ";}"], function (p) {
  return p.theme.colors.palette.raccoon;
}, function (p) {
  return p.compact && 0;
}, function (p) {
  return p.compact && 0;
}, function (p) {
  return p.theme.colors.palette.owl;
}, function (p) {
  return p.theme.colors.palette.seal;
});
var PaginationItemButton = (0, _styledComponents["default"])(PaginationButton).withConfig({
  displayName: "Pagination__PaginationItemButton",
  componentId: "zvrf30-2"
})(["background-color:", ";border-color:", ";font-weight:", ";"], function (p) {
  return p.current && p.theme.colors.palette.babyseal;
}, function (p) {
  return p.current && p.theme.colors.palette.seal;
}, function (p) {
  return p.current ? 'bold' : 'normal';
});

var Ellipsis = _styledComponents["default"].div.withConfig({
  displayName: "Pagination__Ellipsis",
  componentId: "zvrf30-3"
})(["height:100%;display:inline-flex;align-items:center;padding:0 ", "px;color:", ";user-select:none;"], function (p) {
  return p.theme.space.s;
}, function (p) {
  return p.disabled ? p.theme.colors.palette.seal : p.theme.colors.palette.raccoon;
});

var getRange = function getRange(current, total) {
  var range = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 2;
  var startEllipsis = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
  var endEllipsis = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : false;
  var length = range * 2 + 1;
  length = Math.min(length, total);
  var start = current - range;
  start = Math.max(start, 1);
  start = Math.min(start, 1 + total - length);
  var pages = (0, _from["default"])({
    length: length
  }, function (_, i) {
    return start + i;
  });

  if (startEllipsis && pages.length && pages[0] !== 1) {
    pages.unshift(1, -1);
  }

  if (endEllipsis && pages.length && pages[pages.length - 1] !== total) {
    pages.push(-1, total);
  }

  return pages;
};