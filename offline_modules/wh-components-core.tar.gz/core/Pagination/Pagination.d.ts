import React from 'react';
import { IdProps, NoChildrenProps } from '../common';
import { ResponsiveValue, ResponsiveGuaranteedValueWithSSRFallback } from '@wh-components/system';
import { ButtonSizeType } from '../Button/Button';
import { TestProps } from '@wh-components/icons/utilities/createSvgIcon';
import { DisplayProps } from '@wh-components/system/layout';
import { PositionProps } from '@wh-components/system/position';
import { FlexItemProps } from '@wh-components/system/flexbox';
export interface PaginationProps extends IdProps, NoChildrenProps {
    arrows?: ResponsiveGuaranteedValueWithSSRFallback<boolean>;
    compact?: ResponsiveGuaranteedValueWithSSRFallback<boolean>;
    currentPage: number;
    disabled?: boolean;
    ellipsis?: boolean;
    endEllipsis?: boolean;
    link?: (page: number) => string;
    onClick?: (page: number) => void;
    range?: ResponsiveGuaranteedValueWithSSRFallback<number>;
    size?: ResponsiveValue<ButtonSizeType>;
    startEllipsis?: boolean;
    totalPages: number;
}
export declare const Pagination: React.ForwardRefExoticComponent<PaginationProps & TestProps & import("@wh-components/system/space").MarginProps & import("@wh-components/system/space").PaddingProps & DisplayProps & PositionProps & FlexItemProps & React.RefAttributes<HTMLDivElement>>;
