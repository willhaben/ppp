import { StyledProps } from 'styled-components';
export declare const createPseudoSelector: (selector: string | string[]) => string;
export declare const objectKeyMap: <U>(obj: U, callback: (value: keyof U, index: number, array: (keyof U)[]) => U) => U[];
declare type SpaceVals = keyof StyledProps<unknown>['theme']['space'];
export declare const spacing: (value: SpaceVals | SpaceVals[]) => (props: StyledProps<unknown>) => string;
export declare const isObject: (value: any) => value is Record<string, unknown>;
export declare const IE11OnlySelector = "@media (-ms-high-contrast: none), (-ms-high-contrast: active)";
export {};
