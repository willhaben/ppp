import { ResponsiveValue, Value, ResponsiveGuaranteedValueWithSSRFallback } from '@wh-components/system';
declare type ExtractResponsiveValue<T> = T extends ResponsiveValue<infer V> ? V : T;
export declare const useResponsiveValue: <V extends string | number | boolean | any[] | Record<string, string | number | boolean | any[] | null | undefined> | null | undefined, R extends string | number | boolean | any[] | null | undefined>(value: V, fallbackValue: R) => R | ExtractResponsiveValue<V>;
export declare const useResponsiveGuaranteedValueWithSSRFallback: <T extends Value>(value: ResponsiveGuaranteedValueWithSSRFallback<T>) => T;
export {};
