"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.useResponsiveGuaranteedValueWithSSRFallback = exports.useResponsiveValue = void 0;

var _sort = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/sort"));

var _entries = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/entries"));

var _stringify = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/json/stringify"));

var _forEach = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/for-each"));

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/slicedToArray"));

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _react = require("react");

var _styledComponents = require("styled-components");

var _system = require("@wh-components/system");

var _system2 = require("./system");

var createMediaQuery = function createMediaQuery(from, exclusiveMax) {
  var _context;

  return exclusiveMax ? (0, _concat["default"])(_context = "(min-width:".concat(from, "px) and (max-width:")).call(_context, exclusiveMax - 1, "px)") : "(min-width:".concat(from, "px)");
};

// The responsive values must not contain `undefined` as a value, since then the fallback value will be set!
var useResponsiveValue = function useResponsiveValue(value, fallbackValue) {
  var theme = (0, _react.useContext)(_styledComponents.ThemeContext);
  var mediaQueryRef = (0, _react.useRef)([]);

  var _useState = (0, _react.useState)(),
      _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
      responsiveValue = _useState2[0],
      setResponsiveValue = _useState2[1];

  (0, _react.useEffect)(function () {
    // this is a workaround for TypeScript since it does not remove undefined from V correctly after the typeof check in the next line - do not use this variable outside of the following if body, since value still could be undefined
    var nonUndefinedValue = value;

    if (typeof value !== 'undefined' && (0, _system.isValueObject)(nonUndefinedValue)) {
      var mediaQueries = createQueries(nonUndefinedValue, fallbackValue, theme.breakpoints);

      if (mediaQueries === null) {
        setResponsiveValue(fallbackValue);
      } else {
        (0, _forEach["default"])(mediaQueries).call(mediaQueries, function (_ref) {
          var mediaQuery = _ref.mediaQuery,
              mediaQueryValue = _ref.value;
          var mediaQueryList = window.matchMedia(mediaQuery);

          var listener = function listener(event) {
            if (event.matches) {
              setResponsiveValue(mediaQueryValue);
            }
          }; // IE needs addListener


          mediaQueryList.addListener(listener);

          if (responsiveValue === undefined) {
            listener(mediaQueryList);
          }

          mediaQueryRef.current.push({
            list: mediaQueryList,
            listener: listener
          });
        });
      }
    } else {
      var undefinedOrPlainValue = value;
      setResponsiveValue(undefinedOrPlainValue);
    }

    return function () {
      if (mediaQueryRef.current) {
        var _context2;

        (0, _forEach["default"])(_context2 = mediaQueryRef.current).call(_context2, function (_ref2) {
          var list = _ref2.list,
              listener = _ref2.listener;
          list.removeListener(listener);
        });
        mediaQueryRef.current = [];
      }
    }; // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fallbackValue, responsiveValue, theme.breakpoints, (0, _stringify["default"])(value)]);
  return typeof responsiveValue !== 'undefined' ? responsiveValue : fallbackValue;
};

exports.useResponsiveValue = useResponsiveValue;

var createQueries = function createQueries(value, fallbackValue, breakpoints) {
  var _context3;

  var defaultValue = fallbackValue;
  var breakpointList = []; // Search values for matching breakpoints

  (0, _forEach["default"])(_context3 = (0, _entries["default"])(value)).call(_context3, function (_ref3) {
    var _ref4 = (0, _slicedToArray2["default"])(_ref3, 2),
        breakpoint = _ref4[0],
        breakpointValue = _ref4[1];

    if (typeof breakpointValue === 'undefined') {
      return;
    }

    if (breakpoint in breakpoints) {
      breakpointList.push({
        name: breakpoint,
        value: breakpoints[breakpoint]
      });
    } else {
      defaultValue = breakpointValue;
    }
  });
  return breakpointsToMediaQueries(breakpointList, value, defaultValue);
};

var breakpointsToMediaQueries = function breakpointsToMediaQueries(breakpoints, values, defaultValue) {
  // Sort Breakpoints
  breakpoints = (0, _sort["default"])(breakpoints).call(breakpoints, function (left, right) {
    return left.value > right.value ? 1 : -1;
  });
  var mediaQueries = [];
  mediaQueries.push({
    mediaQuery: createMediaQuery(0, breakpoints.length ? breakpoints[0].value : 0),
    value: defaultValue
  });

  for (var i = 0; i < breakpoints.length; i += 1) {
    var _breakpoints$i = breakpoints[i],
        name = _breakpoints$i.name,
        breakpointValue = _breakpoints$i.value;
    var next = breakpoints[i + 1];
    var value = values[name];

    if (typeof value === 'undefined') {
      continue;
    }

    mediaQueries.push({
      mediaQuery: createMediaQuery(breakpointValue, next ? next.value : undefined),
      value: value
    });
  }

  return mediaQueries;
};

var isValueResponsiveGuaranteedValueObjectWithSSRFallback = function isValueResponsiveGuaranteedValueObjectWithSSRFallback(object) {
  return (0, _system2.isObject)(object);
};

var useResponsiveGuaranteedValueWithSSRFallback = function useResponsiveGuaranteedValueWithSSRFallback(value) {
  var ssr;
  var csr;

  if (isValueResponsiveGuaranteedValueObjectWithSSRFallback(value)) {
    ssr = value.ssr;
    csr = value.csr;
  } else {
    ssr = value;
    csr = value;
  }

  return useResponsiveValue(csr, ssr);
};

exports.useResponsiveGuaranteedValueWithSSRFallback = useResponsiveGuaranteedValueWithSSRFallback;