"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.IE11OnlySelector = exports.isObject = exports.spacing = exports.objectKeyMap = exports.createPseudoSelector = void 0;

var _typeof2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/typeof"));

var _isArray = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/array/is-array"));

var _keys = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/keys"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var _utilities = require("@wh-components/system/utilities");

var createPseudoSelector = function createPseudoSelector(selector) {
  return ":".concat((0, _utilities.isArray)(selector) ? selector.join(':') : selector);
};

exports.createPseudoSelector = createPseudoSelector;

var objectKeyMap = function objectKeyMap(obj, callback) {
  var _context;

  return (0, _map["default"])(_context = (0, _keys["default"])(obj)).call(_context, callback);
};

exports.objectKeyMap = objectKeyMap;

var spacing = function spacing(value) {
  if ((0, _isArray["default"])(value)) {
    return function (props) {
      return (0, _map["default"])(value).call(value, function (v) {
        return "".concat(props.theme.space[v], "px");
      }).join(' ');
    };
  }

  return function (props) {
    return "".concat(props.theme.space[value], "px");
  };
};

exports.spacing = spacing;

var isObject = function isObject(value) {
  return (0, _typeof2["default"])(value) === 'object' && !(0, _isArray["default"])(value);
};

exports.isObject = isObject;
var IE11OnlySelector = '@media (-ms-high-contrast: none), (-ms-high-contrast: active)';
exports.IE11OnlySelector = IE11OnlySelector;