"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.CloseButton = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _Button = require("../Button/Button");

var _Reset = _interopRequireDefault(require("@wh-components/icons/Reset"));

var CloseButton = (0, _styledComponents["default"])(_Button.IconButton).attrs({
  Icon: _Reset["default"],
  variant: 'transparent'
}).withConfig({
  displayName: "CloseButton",
  componentId: "sc-17yr24w-0"
})(["color:", ";"], function (p) {
  return p.theme.colors.palette.seal;
});
exports.CloseButton = CloseButton;