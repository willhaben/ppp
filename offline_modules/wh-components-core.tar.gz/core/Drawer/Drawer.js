"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Drawer = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _layout = require("@wh-components/system/layout");

var _responsive = require("../utilities/responsive");

var _useActiveIndex2 = require("../hooks/useActiveIndex");

var _utils = require("../utils");

var _BaseModal = require("../Modal/BaseModal");

var _CloseButton = require("../CloseButton/CloseButton");

var _Text = require("../Text/Text");

var _Box = require("../Box/Box");

var Drawer = function Drawer(_ref) {
  var _ref$items = _ref.items,
      items = _ref$items === void 0 ? [] : _ref$items,
      header = _ref.header,
      footer = _ref.footer,
      _ref$placement = _ref.placement,
      placement = _ref$placement === void 0 ? 'bottom' : _ref$placement,
      _ref$defaultActiveInd = _ref.defaultActiveIndex,
      defaultActiveIndex = _ref$defaultActiveInd === void 0 ? 0 : _ref$defaultActiveInd,
      isOpen = _ref.isOpen,
      _onAfterOpen = _ref.onAfterOpen,
      _onAfterClose = _ref.onAfterClose,
      onRequestClose = _ref.onRequestClose,
      testId = _ref.testId,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["items", "header", "footer", "placement", "defaultActiveIndex", "isOpen", "onAfterOpen", "onAfterClose", "onRequestClose", "testId"]);
  var placementValue = (0, _responsive.useResponsiveValue)(placement, undefined);
  var listRef = (0, _react.useRef)(null);
  var focusableItems = (0, _react.useRef)([]);

  var _useActiveIndex = (0, _useActiveIndex2.useActiveIndex)(focusableItems.current),
      activeIndex = _useActiveIndex.activeIndex,
      focusAtIndex = _useActiveIndex.focusAtIndex,
      handleKeyDown = _useActiveIndex.handleKeyDown;

  return isOpen && items.length ? /*#__PURE__*/_react["default"].createElement(StyledDrawer, (0, _extends2["default"])({}, props, {
    isOpen: isOpen,
    onAfterOpen: function onAfterOpen(options) {
      focusableItems.current = (0, _utils.getFocusableElements)(listRef.current);
      focusAtIndex(defaultActiveIndex);
      _onAfterOpen === null || _onAfterOpen === void 0 ? void 0 : _onAfterOpen(options);
    },
    onAfterClose: function onAfterClose() {
      _onAfterClose === null || _onAfterClose === void 0 ? void 0 : _onAfterClose();
      focusAtIndex(-1);
    },
    onRequestClose: onRequestClose,
    placement: placementValue,
    testId: testId
  }), header && typeof header === 'string' ? /*#__PURE__*/_react["default"].createElement(HeaderContainer, null, /*#__PURE__*/_react["default"].createElement(_Text.Text, {
    fontSize: "l",
    fontWeight: "bold",
    color: "palette.verydarkgrey",
    truncate: true
  }, header), /*#__PURE__*/_react["default"].createElement(_CloseButton.CloseButton, {
    size: "small",
    marginLeft: "s",
    "aria-label": "Men\xFC schlie\xDFen",
    testId: testId && "".concat(testId, "-close-button"),
    onClick: onRequestClose
  })) : header, /*#__PURE__*/_react["default"].createElement(List, {
    role: "menu",
    placement: placementValue,
    tabIndex: -1,
    onKeyDown: handleKeyDown,
    ref: listRef
  }, (0, _map["default"])(items).call(items, function (item, index) {
    return /*#__PURE__*/_react["default"].createElement(ListItem, {
      key: index,
      role: "menuitem",
      placement: placementValue,
      tabIndex: index === activeIndex ? 0 : -1,
      "data-testid": item.testId,
      onMouseEnter: function onMouseEnter() {
        focusAtIndex(index);
      },
      onMouseLeave: function onMouseLeave() {
        var _listRef$current;

        focusAtIndex(-1);
        (_listRef$current = listRef.current) === null || _listRef$current === void 0 ? void 0 : _listRef$current.focus();
      },
      onClick: function onClick(event) {
        var _item$onClick;

        (_item$onClick = item.onClick) === null || _item$onClick === void 0 ? void 0 : _item$onClick.call(item);
        onRequestClose === null || onRequestClose === void 0 ? void 0 : onRequestClose(event);
      },
      onKeyDown: function onKeyDown(event) {
        if (event.key === 'Enter' || event.key === ' ') {
          var _item$onClick2;

          event.preventDefault();
          (_item$onClick2 = item.onClick) === null || _item$onClick2 === void 0 ? void 0 : _item$onClick2.call(item);
          onRequestClose === null || onRequestClose === void 0 ? void 0 : onRequestClose(event);
        }
      }
    }, item.Icon, typeof item.label === 'string' ? /*#__PURE__*/_react["default"].createElement(_Text.Text, {
      truncate: true
    }, item.label) : item.label);
  })), footer && /*#__PURE__*/_react["default"].createElement(_react.Fragment, null, /*#__PURE__*/_react["default"].createElement(_Box.Box, {
    flexGrow: 1
  }), /*#__PURE__*/_react["default"].createElement(FooterContainer, null, footer))) : null;
};

exports.Drawer = Drawer;
var StyledDrawer = (0, _styledComponents["default"])(_BaseModal.BaseModal).withConfig({
  displayName: "Drawer__StyledDrawer",
  componentId: "sc-97tgue-0"
})(["position:absolute;display:flex;flex-direction:column;background-color:#fff;box-shadow:0 4px 16px 0 #999;outline:0;z-index:", ";", " ", " ", " ", " ", ""], function (p) {
  return p.theme.zIndices.modal;
}, function (p) {
  return p.placement === 'top' && TopPlacementStyle;
}, function (p) {
  return p.placement === 'right' && RightPlacementStyle;
}, function (p) {
  return p.placement === 'bottom' && BottomPlacementStyle;
}, function (p) {
  return p.placement === 'left' && LeftPlacementStyle;
}, function (p) {
  return (p.placement === 'left' || p.placement === 'right') && _layout.width;
});

var HeaderContainer = _styledComponents["default"].div.withConfig({
  displayName: "Drawer__HeaderContainer",
  componentId: "sc-97tgue-1"
})(["height:56px;display:flex;align-items:center;justify-content:space-between;padding:0 ", "px;background-color:", ";border-bottom:1px solid ", ";user-select:none;"], function (p) {
  return p.theme.space.sm;
}, function (p) {
  return p.theme.colors.palette.polarbear;
}, function (p) {
  return p.theme.colors.palette.owl;
});

var FooterContainer = _styledComponents["default"].div.withConfig({
  displayName: "Drawer__FooterContainer",
  componentId: "sc-97tgue-2"
})(["height:48px;display:flex;align-items:center;justify-content:center;padding:0 ", "px;border-top:1px solid ", ";"], function (p) {
  return p.theme.space.sm;
}, function (p) {
  return p.theme.colors.palette.owl;
});

var List = _styledComponents["default"].div.withConfig({
  displayName: "Drawer__List",
  componentId: "sc-97tgue-3"
})(["max-height:", "px;overflow-y:auto;outline:0;"], function (p) {
  return (p.placement === 'top' || p.placement === 'bottom') && 10 * 48;
});

var ListItem = _styledComponents["default"].button.withConfig({
  displayName: "Drawer__ListItem",
  componentId: "sc-97tgue-4"
})(["height:48px;width:100%;display:flex;align-items:center;padding:0 ", "px;background:transparent;border:0;font-size:", ";color:", ";outline:none;user-select:none;cursor:pointer;&:not(:last-child){border-bottom:1px solid ", ";}&:last-child{border-bottom:", ";}&:focus{background-color:", ";}"], function (p) {
  return p.theme.space.sm;
}, function (p) {
  return p.theme.fontSizes.m;
}, function (p) {
  return p.theme.colors.palette.verydarkgrey;
}, function (p) {
  return p.theme.colors.palette.owl;
}, function (p) {
  return (p.placement === 'left' || p.placement === 'right') && "1px solid ".concat(p.theme.colors.palette.owl);
}, function (p) {
  return p.theme.colors.palette.babyseal;
});

var TopPlacementStyle = (0, _styledComponents.css)(["top:0;right:0;left:0;"]);
var RightPlacementStyle = (0, _styledComponents.css)(["top:0;right:0;bottom:0;"]);
var BottomPlacementStyle = (0, _styledComponents.css)(["bottom:0;right:0;left:0;"]);
var LeftPlacementStyle = (0, _styledComponents.css)(["top:0;bottom:0;left:0;"]);