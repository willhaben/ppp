import { FunctionComponent, ReactElement, ReactNode } from 'react';
import { TestProps, NoChildrenProps } from '../common';
import { WidthProps } from '@wh-components/system/layout';
import { ResponsiveValue } from '@wh-components/system';
import { BaseModalProps } from '../Modal/BaseModal';
export declare type DrawerItemType = {
    Icon?: ReactElement;
    label: ReactNode;
    onClick?: () => void;
} & TestProps;
export declare type DrawerPlacement = 'top' | 'right' | 'bottom' | 'left';
export interface DrawerProps extends BaseModalProps, NoChildrenProps, WidthProps {
    items: DrawerItemType[];
    header?: ReactNode;
    footer?: ReactNode;
    placement?: ResponsiveValue<DrawerPlacement>;
    defaultActiveIndex?: number;
}
export declare const Drawer: FunctionComponent<DrawerProps>;
