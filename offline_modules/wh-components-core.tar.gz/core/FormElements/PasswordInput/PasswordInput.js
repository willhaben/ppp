"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.PasswordInput = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/slicedToArray"));

var _react = _interopRequireWildcard(require("react"));

var _Input = require("../Input/Input");

var _Eye = _interopRequireDefault(require("@wh-components/icons/Eye"));

var _EyeDisabled = _interopRequireDefault(require("@wh-components/icons/EyeDisabled"));

var PasswordInput = /*#__PURE__*/(0, _react.forwardRef)(function (props, ref) {
  var _useState = (0, _react.useState)(false),
      _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
      showPassword = _useState2[0],
      setShowPassword = _useState2[1];

  var toggleShowPassword = function toggleShowPassword() {
    return setShowPassword(function (oldShowPassword) {
      return !oldShowPassword;
    });
  };

  return /*#__PURE__*/_react["default"].createElement(_Input.Input, (0, _extends2["default"])({
    ref: ref
  }, props, {
    type: showPassword ? 'text' : 'password',
    Icon: showPassword ? _EyeDisabled["default"] : _Eye["default"],
    onIconClick: toggleShowPassword
  }));
});
exports.PasswordInput = PasswordInput;