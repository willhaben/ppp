"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Select = exports.BaseSelect = void 0;

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/toConsumableArray"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _react = _interopRequireWildcard(require("react"));

var _system = require("@wh-components/system");

var _variant = require("@wh-components/system/variant");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _flexbox = require("@wh-components/system/flexbox");

var _common = require("../../common");

var _Label = require("../Label/Label");

var _utilities = require("@wh-components/system/utilities");

/* eslint-disable no-shadow */
var selectSizes = (0, _variant.variant)({
  scale: 'components.select.sizes',
  prop: 'inputSize'
});
var borderColors = (0, _variant.variant)({
  scale: 'components.select.colors',
  prop: 'state'
});
var iconSizes = (0, _variant.variant)({
  scale: 'components.select.icon.sizes',
  prop: 'inputSize'
});

var SelectElement = _styledComponents["default"].select.attrs(_common.testIdAttribute).withConfig({
  displayName: "Select__SelectElement",
  componentId: "sc-1tddu31-0"
})(["padding:0 0.75em;border:1px solid;border-radius:", "px;background-color:", ";color:", ";transition:box-shadow 0.2s;appearance:none;&::-ms-expand{display:none;}background-image:url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCAyNCAyNCc+PHBhdGggZD0nTTEyIDE3LjUzYTEgMSAwIDAxLS43LS4yOWwtOS05YTEgMSAwIDAxMC0xLjQxIDEgMSAwIDAxMS40MSAwTDEyIDE1LjEybDguMy04LjI5YTEgMSAwIDAxMS40MSAwIDEgMSAwIDAxMCAxLjQxbC05IDlhMSAxIDAgMDEtLjcxLjI5eicgZmlsbD0nI2FhYjRjNCcgLz48L3N2Zz4='),linear-gradient(to right,#aab4c4 1px,#fff 1px);background-repeat:no-repeat;&:focus{outline:0;box-shadow:0 0 0 3px ", ";}&:disabled{background-color:", ";cursor:not-allowed;}", " ", " ", ""], function (p) {
  return p.theme.borderRadii.m;
}, function (p) {
  return p.theme.colors.palette.white;
}, function (p) {
  return p.theme.colors.palette.verydarkgrey;
}, function (p) {
  return p.theme.colors.palette.primary.disabled;
}, function (p) {
  return p.theme.colors.palette.babyseal;
}, selectSizes, iconSizes, borderColors);

var _StyledSelectElement = (0, _styledComponents["default"])(SelectElement).withConfig({
  displayName: "Select___StyledSelectElement",
  componentId: "sc-1tddu31-1"
})(["width:100%;"]);

var BaseSelectElement = (0, _styledComponents["default"])(SelectElement).withConfig({
  displayName: "Select__BaseSelectElement",
  componentId: "sc-1tddu31-2"
})(["", ""], (0, _system.compose)(_space.margin, _layout.width, _layout.display, _flexbox.flexItem));

var BaseSelect = function BaseSelect(_ref) {
  var id = _ref.id,
      testId = _ref.testId,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'medium' : _ref$size,
      _ref$state = _ref.state,
      state = _ref$state === void 0 ? 'normal' : _ref$state,
      items = _ref.items,
      disabled = _ref.disabled,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["id", "testId", "size", "state", "items", "disabled"]);
  return /*#__PURE__*/_react["default"].createElement(BaseSelectElement, (0, _extends2["default"])({}, props, {
    id: id,
    inputSize: size,
    state: disabled ? 'normal' : state,
    disabled: disabled,
    testId: testId
  }), (0, _map["default"])(items).call(items, function (item, key) {
    var _context;

    return /*#__PURE__*/_react["default"].createElement("option", {
      key: "option-".concat(key),
      value: item.value,
      "data-testid": (0, _concat["default"])(_context = "".concat(testId, "-option-")).call(_context, item.label.toLowerCase())
    }, item.label);
  }));
};

exports.BaseSelect = BaseSelect;
var Select = /*#__PURE__*/(0, _react.forwardRef)(function (_ref2, ref) {
  var _context2;

  var id = _ref2.id,
      testId = _ref2.testId,
      _ref2$size = _ref2.size,
      size = _ref2$size === void 0 ? 'large' : _ref2$size,
      _ref2$state = _ref2.state,
      state = _ref2$state === void 0 ? 'normal' : _ref2$state,
      _ref2$inline = _ref2.inline,
      inline = _ref2$inline === void 0 ? false : _ref2$inline,
      label = _ref2.label,
      showRequiredLabel = _ref2.showRequiredLabel,
      hint = _ref2.hint,
      comment = _ref2.comment,
      items = _ref2.items,
      disabled = _ref2.disabled,
      props = (0, _objectWithoutProperties2["default"])(_ref2, ["id", "testId", "size", "state", "inline", "label", "showRequiredLabel", "hint", "comment", "items", "disabled"]);

  var _separateWrapperAndRe = separateWrapperAndRemainingProps(props),
      wrapperProps = _separateWrapperAndRe.wrapperProps,
      inputProps = _separateWrapperAndRe.remainingProps;

  return /*#__PURE__*/_react["default"].createElement(_Label.Label, (0, _extends2["default"])({
    htmlFor: id,
    state: state,
    disabled: disabled,
    label: label,
    inline: inline,
    required: inputProps.required,
    showRequiredLabel: showRequiredLabel,
    hint: hint,
    comment: comment,
    testIdPrefix: testId
  }, wrapperProps), /*#__PURE__*/_react["default"].createElement(_StyledSelectElement, (0, _extends2["default"])({}, inputProps, {
    id: id,
    ref: ref,
    inputSize: size,
    state: disabled ? 'normal' : state,
    disabled: disabled,
    testId: testId,
    "aria-describedby": testId && (0, _concat["default"])(_context2 = "".concat(testId, "-hint ")).call(_context2, testId, "-comment")
  }), (0, _map["default"])(items).call(items, function (item, key) {
    var _context3;

    return /*#__PURE__*/_react["default"].createElement("option", {
      key: "option-".concat(key),
      value: item.value,
      "data-testid": (0, _concat["default"])(_context3 = "".concat(testId, "-option-")).call(_context3, item.label.toLowerCase())
    }, item.label);
  })));
}); // this avoids setting props like `name` on the wrapper div

exports.Select = Select;

var separateWrapperAndRemainingProps = function separateWrapperAndRemainingProps(props) {
  var _context4;

  var extract = (0, _concat["default"])(_context4 = []).call(_context4, (0, _toConsumableArray2["default"])(_space.marginPropKeys), (0, _toConsumableArray2["default"])(_layout.widthPropKeys), (0, _toConsumableArray2["default"])(_layout.displayPropKeys), (0, _toConsumableArray2["default"])(_flexbox.flexItemPropKeys), (0, _toConsumableArray2["default"])(_common.classNamePropKeys));

  var _extractProps = (0, _utilities.extractProps)(props, extract),
      wrapperProps = _extractProps.extractedProps,
      remainingProps = _extractProps.remainingProps;

  return {
    wrapperProps: wrapperProps,
    remainingProps: remainingProps
  };
};