"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Toggle = void 0;

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/toConsumableArray"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _common = require("../../common");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _flexbox = require("@wh-components/system/flexbox");

var _variant = require("@wh-components/system/variant");

var _Box = require("../../Box/Box");

var _utilities = require("@wh-components/system/utilities");

var Toggle = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var id = _ref.id,
      testId = _ref.testId,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'medium' : _ref$size,
      _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'primary' : _ref$color,
      children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["id", "testId", "size", "color", "children"]);

  var _separateWrapperAndRe = separateWrapperAndRemainingProps(props),
      _separateWrapperAndRe2 = _separateWrapperAndRe.wrapperProps,
      display = _separateWrapperAndRe2.display,
      wrapperProps = (0, _objectWithoutProperties2["default"])(_separateWrapperAndRe2, ["display"]),
      inputProps = _separateWrapperAndRe.remainingProps;

  return /*#__PURE__*/_react["default"].createElement(_Box.Box, (0, _extends2["default"])({
    position: "relative",
    display: display || 'inline-block'
  }, wrapperProps), /*#__PURE__*/_react["default"].createElement(ToggleInput, (0, _extends2["default"])({}, inputProps, {
    type: "checkbox",
    color: color,
    id: id,
    "data-testid": testId,
    ref: ref
  })), /*#__PURE__*/_react["default"].createElement(ToggleLabel, {
    htmlFor: id,
    toggleSize: size,
    "data-testid": testId && "".concat(testId, "-label")
  }, children));
});
exports.Toggle = Toggle;
var toggleSize = (0, _variant.variant)({
  scale: 'components.toggle.sizes',
  prop: 'toggleSize'
});
var toggleColor = (0, _variant.variant)({
  scale: 'components.toggle.colors',
  prop: 'color'
});

var ToggleInput = _styledComponents["default"].input.withConfig({
  displayName: "Toggle__ToggleInput",
  componentId: "awwtrm-0"
})(["margin:0;position:absolute;top:0;left:0;opacity:0;&:checked + label{", " &:after{left:calc(100% - 4px);transform:translateX(-100%);}}&:disabled + label{background-color:", ";cursor:not-allowed;}&:focus + label{box-shadow:0 0 0 3px ", ";}"], toggleColor, function (p) {
  return p.theme.colors.palette.owl;
}, function (p) {
  return p.theme.colors.palette.primary.disabled;
});

var ToggleLabel = _styledComponents["default"].label.withConfig({
  displayName: "Toggle__ToggleLabel",
  componentId: "awwtrm-1"
})(["display:flex;align-items:center;padding:0 4px;background-color:", ";transition:box-shadow 0.2s;cursor:pointer;&:after{content:'';position:absolute;top:4px;left:4px;border-radius:50%;background-color:", ";transition:all 0.2s ease-in-out;}", ""], function (p) {
  return p.theme.colors.palette.elephant;
}, function (p) {
  return p.theme.colors.palette.white;
}, toggleSize); // this avoids setting props like `name` on the wrapper div


var separateWrapperAndRemainingProps = function separateWrapperAndRemainingProps(props) {
  var _context;

  var extract = (0, _concat["default"])(_context = []).call(_context, (0, _toConsumableArray2["default"])(_layout.widthPropKeys), (0, _toConsumableArray2["default"])(_space.marginPropKeys), (0, _toConsumableArray2["default"])(_layout.displayPropKeys), (0, _toConsumableArray2["default"])(_flexbox.flexItemPropKeys), (0, _toConsumableArray2["default"])(_common.classNamePropKeys));

  var _extractProps = (0, _utilities.extractProps)(props, extract),
      wrapperProps = _extractProps.extractedProps,
      remainingProps = _extractProps.remainingProps;

  return {
    wrapperProps: wrapperProps,
    remainingProps: remainingProps
  };
};