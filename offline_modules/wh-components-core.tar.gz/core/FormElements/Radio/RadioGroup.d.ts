import { ReactNode, FunctionComponent } from 'react';
import { ReactRadioProps, RadioSize } from './Radio';
import { InputState, TestProps } from '../../common';
import { SpaceProps } from '@wh-components/system/space';
import { LayoutProps } from '@wh-components/system/layout';
import { PositionProps } from '@wh-components/system/position';
import { FlexboxProps } from '@wh-components/system/flexbox';
export interface RadioGroupProps extends TestProps {
    label?: string;
    size?: RadioSize;
    state?: InputState;
    disabled?: boolean;
    comment?: string;
    hint?: string;
    required?: boolean;
    showRequiredLabel?: boolean;
    /** Specifies a name that is set on each contained Radio, used for making sure only one can be selected at a time */
    name: string;
    /** Array of all props for all Radio components that should be created inside the radio group */
    radios: RadioGroupChildRadioProps[];
    /** Sets the label to be inline */
    inline?: boolean;
    children?: (radioComponents: ReactNode[]) => ReactNode;
}
export declare type RadioGroupChildRadioProps = Omit<ReactRadioProps & {
    testId: string;
    label?: ReactNode;
}, 'name' | 'size' | 'state' | 'disabled' | 'required' | 'children'>;
declare type ContainerProps = SpaceProps & LayoutProps & PositionProps & FlexboxProps;
export declare const RadioGroup: ({ testId, label, size, state, disabled, comment, hint, required, showRequiredLabel, name, radios, inline, children, ...props }: RadioGroupProps & ContainerProps) => JSX.Element;
export declare const DefaultRadioGroupLayout: FunctionComponent;
export {};
