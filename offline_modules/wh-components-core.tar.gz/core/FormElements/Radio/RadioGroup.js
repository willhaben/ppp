"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.DefaultRadioGroupLayout = exports.RadioGroup = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _react = _interopRequireDefault(require("react"));

var _Label = require("../Label/Label");

var _Radio = require("./Radio");

var RadioGroup = function RadioGroup(_ref) {
  var testId = _ref.testId,
      label = _ref.label,
      size = _ref.size,
      state = _ref.state,
      disabled = _ref.disabled,
      comment = _ref.comment,
      hint = _ref.hint,
      required = _ref.required,
      showRequiredLabel = _ref.showRequiredLabel,
      name = _ref.name,
      radios = _ref.radios,
      inline = _ref.inline,
      _ref$children = _ref.children,
      children = _ref$children === void 0 ? function (radioComponents) {
    return /*#__PURE__*/_react["default"].createElement(DefaultRadioGroupLayout, null, radioComponents);
  } : _ref$children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["testId", "label", "size", "state", "disabled", "comment", "hint", "required", "showRequiredLabel", "name", "radios", "inline", "children"]);
  return /*#__PURE__*/_react["default"].createElement(_Label.Label, (0, _extends2["default"])({
    testIdPrefix: testId,
    label: label,
    state: state,
    disabled: disabled,
    required: required,
    showRequiredLabel: showRequiredLabel,
    comment: comment,
    hint: hint,
    inline: inline,
    align: "radio-group",
    size: size
  }, props), children((0, _map["default"])(radios).call(radios, function (radioProps) {
    var _context, _radioProps$value, _radioProps$testId, _context2;

    return /*#__PURE__*/_react["default"].createElement(_Radio.Radio, (0, _extends2["default"])({
      key: (0, _concat["default"])(_context = "".concat((_radioProps$value = radioProps.value) !== null && _radioProps$value !== void 0 ? _radioProps$value : '', "-")).call(_context, (_radioProps$testId = radioProps.testId) !== null && _radioProps$testId !== void 0 ? _radioProps$testId : '')
    }, radioProps, {
      testId: (0, _concat["default"])(_context2 = "".concat(testId, "-")).call(_context2, radioProps.testId),
      name: name,
      size: size,
      state: state,
      disabled: disabled,
      required: required
    }));
  })));
};

exports.RadioGroup = RadioGroup;

var _StyledDiv = (0, _styledComponents["default"])("div").withConfig({
  displayName: "RadioGroup___StyledDiv",
  componentId: "m34b0k-0"
})(["display:flex;flex-wrap:wrap;& > *{width:100%;margin-right:", "px;", "{width:calc(50% - ", "px);}", "{width:calc(25% - ", "px);}}"], function (p) {
  return p.theme.space.s;
}, function (p) {
  return p.theme.media.tablet;
}, function (p) {
  return p.theme.space.s;
}, function (p) {
  return p.theme.media.desktop;
}, function (p) {
  return p.theme.space.s;
});

var DefaultRadioGroupLayout = function DefaultRadioGroupLayout(props) {
  return /*#__PURE__*/_react["default"].createElement(_StyledDiv, null, props.children);
};

exports.DefaultRadioGroupLayout = DefaultRadioGroupLayout;