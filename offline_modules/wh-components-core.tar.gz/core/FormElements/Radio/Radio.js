"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Radio = void 0;

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/toConsumableArray"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _filter = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/filter"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _variant = require("@wh-components/system/variant");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _position = require("@wh-components/system/position");

var _flexbox = require("@wh-components/system/flexbox");

var _common = require("../../common");

var _Box = require("../../Box/Box");

var _utilities = require("@wh-components/system/utilities");

var radioSizes = (0, _variant.variant)({
  scale: 'components.radio.sizes',
  prop: 'radioSize'
});
var labelSizes = (0, _variant.variant)({
  scale: 'components.radioLabel.sizes',
  prop: 'radioSize'
});
var labelColors = (0, _variant.variant)({
  scale: 'components.radioLabel.borderColors',
  prop: 'state'
});

var RadioInput = _styledComponents["default"].input.withConfig({
  displayName: "Radio__RadioInput",
  componentId: "m8bwjn-0"
})(["margin:0;position:absolute;top:0;left:0;opacity:0;&:checked + label:after{opacity:1;}&:disabled + label{color:", ";cursor:not-allowed;&:before{border-color:", ";background-color:", ";}&:after{background-color:", ";}}&:focus + label{&:before{box-shadow:0 0 0 3px ", ";}}", ""], function (p) {
  return p.theme.colors.palette.elephant;
}, function (p) {
  return p.theme.colors.palette.owl;
}, function (p) {
  return p.theme.colors.palette.babyseal;
}, function (p) {
  return p.theme.colors.palette.primary.disabled;
}, function (p) {
  return p.theme.colors.palette.primary.disabled;
}, radioSizes);

var RadioLabel = _styledComponents["default"].label.withConfig({
  displayName: "Radio__RadioLabel",
  componentId: "m8bwjn-1"
})(["display:flex;align-items:center;color:", ";cursor:pointer;&:before{content:'';position:absolute;top:0;left:0;border:1px solid ", ";border-radius:50%;background-color:", ";}&:hover:before{background-color:", ";}&:after{content:'';position:absolute;top:4px;left:4px;opacity:0;border-radius:50%;background-color:", ";transition:opacity 0.1s ease-in-out;}", " ", ""], function (p) {
  return p.theme.colors.palette.verydarkgrey;
}, function (p) {
  return p.theme.colors.palette.grey;
}, function (p) {
  return p.theme.colors.palette.white;
}, function (p) {
  return p.theme.colors.palette.dove;
}, function (p) {
  return p.theme.colors.palette.primary.main;
}, labelSizes, labelColors);

var Radio = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var _context;

  var id = _ref.id,
      testId = _ref.testId,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'medium' : _ref$size,
      _ref$state = _ref.state,
      state = _ref$state === void 0 ? 'normal' : _ref$state,
      label = _ref.label,
      ariaLabelledBy = _ref['aria-labelledby'],
      props = (0, _objectWithoutProperties2["default"])(_ref, ["id", "testId", "size", "state", "label", "aria-labelledby"]);

  var _separateWrapperAndRe = separateWrapperAndRemainingProps(props),
      wrapperProps = _separateWrapperAndRe.wrapperProps,
      remainingProps = _separateWrapperAndRe.remainingProps;

  return /*#__PURE__*/_react["default"].createElement(_Box.Box, (0, _extends2["default"])({
    paddingVertical: "xs"
  }, wrapperProps), /*#__PURE__*/_react["default"].createElement(_Box.Box, {
    position: "relative"
  }, /*#__PURE__*/_react["default"].createElement(RadioInput, (0, _extends2["default"])({
    type: "radio",
    id: id
  }, remainingProps, {
    ref: ref,
    radioSize: size,
    "data-testid": testId,
    "aria-labelledby": (0, _filter["default"])(_context = [ariaLabelledBy, "".concat(id, "-label")]).call(_context, Boolean).join(' ')
  })), /*#__PURE__*/_react["default"].createElement(RadioLabel, {
    id: "".concat(id, "-label"),
    radioSize: size,
    state: state,
    htmlFor: id,
    "data-testid": "".concat(testId, "-label")
  }, label)));
}); // this avoids setting props like `name` on the wrapper div

exports.Radio = Radio;

var separateWrapperAndRemainingProps = function separateWrapperAndRemainingProps(props) {
  var _context2;

  var extract = (0, _concat["default"])(_context2 = []).call(_context2, (0, _toConsumableArray2["default"])(_space.spacePropKeys), (0, _toConsumableArray2["default"])(_layout.displayPropKeys), (0, _toConsumableArray2["default"])(_position.positionPropKeys), (0, _toConsumableArray2["default"])(_flexbox.flexboxPropKeys), (0, _toConsumableArray2["default"])(_common.classNamePropKeys));

  var _extractProps = (0, _utilities.extractProps)(props, extract),
      wrapperProps = _extractProps.extractedProps,
      remainingProps = _extractProps.remainingProps;

  return {
    wrapperProps: wrapperProps,
    remainingProps: remainingProps
  };
};