import { FunctionComponent, DetailedHTMLProps, InputHTMLAttributes } from 'react';
import { TestProps } from '../../common';
import { MarginProps } from '@wh-components/system/space';
import { WidthProps, DisplayProps } from '@wh-components/system/layout';
import { FlexItemProps } from '@wh-components/system/flexbox';
import { IconType } from '@wh-components/icons/utilities/createSvgIcon';
declare type RangeSize = 'small' | 'medium' | 'large';
declare type RangeColor = 'primary' | 'secondary' | 'complimentary' | 'accent';
declare type ContainerProps = MarginProps & WidthProps & DisplayProps & FlexItemProps;
declare type ReactRangeProps = Omit<DetailedHTMLProps<InputHTMLAttributes<HTMLInputElement>, HTMLInputElement>, 'ref' | 'size' | 'type' | 'width'>;
interface RangeProps extends TestProps, ContainerProps, ReactRangeProps {
    size?: RangeSize;
    color?: RangeColor;
    leftIcon?: IconType;
    rightIcon?: IconType;
    onLeftIconClick?: () => void;
    onRightIconClick?: () => void;
    value?: number;
    min?: number;
    max?: number;
    step?: number;
}
export declare const Range: FunctionComponent<RangeProps>;
export {};
