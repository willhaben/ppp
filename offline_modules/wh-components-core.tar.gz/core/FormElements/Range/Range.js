"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Range = void 0;

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/toConsumableArray"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _react = _interopRequireDefault(require("react"));

var _common = require("../../common");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _flexbox = require("@wh-components/system/flexbox");

var _utilities = require("@wh-components/system/utilities");

var _variant = require("@wh-components/system/variant");

var _system = require("@wh-components/system");

var _Box = require("../../Box/Box");

var _Button = require("../../Button/Button");

var _StyledIconButton = (0, _styledComponents["default"])(_Button.IconButton).withConfig({
  displayName: "Range___StyledIconButton",
  componentId: "sc-1hxaclw-0"
})(["", ""], function (p) {
  return p._css;
});

var _StyledIconButton2 = (0, _styledComponents["default"])(_Button.IconButton).withConfig({
  displayName: "Range___StyledIconButton2",
  componentId: "sc-1hxaclw-1"
})(["", ""], function (p) {
  return p._css2;
});

var Range = function Range(_ref) {
  var _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'medium' : _ref$size,
      _ref$color = _ref.color,
      color = _ref$color === void 0 ? 'primary' : _ref$color,
      leftIcon = _ref.leftIcon,
      rightIcon = _ref.rightIcon,
      onLeftIconClick = _ref.onLeftIconClick,
      onRightIconClick = _ref.onRightIconClick,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["size", "color", "leftIcon", "rightIcon", "onLeftIconClick", "onRightIconClick"]);

  var _separateWrapperAndRe = separateWrapperAndRemainingProps(props),
      wrapperProps = _separateWrapperAndRe.wrapperProps,
      inputProps = _separateWrapperAndRe.remainingProps;

  return /*#__PURE__*/_react["default"].createElement(_Box.Box, (0, _extends2["default"])({
    display: "inline-flex",
    alignItems: "center"
  }, wrapperProps), leftIcon && /*#__PURE__*/_react["default"].createElement(_StyledIconButton, {
    size: "xsmall",
    variant: "transparent",
    Icon: leftIcon,
    marginRight: "xs",
    disabled: props.disabled || !!props.value && !!props.min && props.value <= props.min,
    onClick: function onClick() {
      return onLeftIconClick === null || onLeftIconClick === void 0 ? void 0 : onLeftIconClick();
    },
    _css: !onLeftIconClick ? IconButtonDisabled : undefined
  }), /*#__PURE__*/_react["default"].createElement(RangeInput, (0, _extends2["default"])({
    type: "range",
    rangeSize: size,
    color: color
  }, inputProps)), rightIcon && /*#__PURE__*/_react["default"].createElement(_StyledIconButton2, {
    size: "xsmall",
    variant: "transparent",
    Icon: rightIcon,
    marginLeft: "xs",
    disabled: props.disabled || !!props.value && !!props.max && props.value >= props.max,
    onClick: function onClick() {
      return onRightIconClick === null || onRightIconClick === void 0 ? void 0 : onRightIconClick();
    },
    _css2: !onRightIconClick ? IconButtonDisabled : undefined
  }));
};

exports.Range = Range;
var IconButtonDisabled = (0, _styledComponents.css)(["pointer-events:none;color:", ";"], function (p) {
  return p.theme.colors.palette.koala;
});
var rangeSize = (0, _variant.variant)({
  scale: 'components.range.sizes.input',
  prop: 'rangeSize'
});
var thumbSize = (0, _variant.variant)({
  scale: 'components.range.sizes.thumb',
  prop: 'rangeSize'
});
var trackSize = (0, _variant.variant)({
  scale: 'components.range.sizes.track',
  prop: 'rangeSize'
});
var chromeThumbMargin = (0, _variant.variant)({
  scale: 'components.range.sizes.chrome',
  prop: 'rangeSize'
});
var IE11TrackBorder = (0, _variant.variant)({
  scale: 'components.range.sizes.ie11',
  prop: 'rangeSize'
});
var rangeColor = (0, _variant.variant)({
  scale: 'components.range.colors',
  prop: 'color'
});

var RangeInput = _styledComponents["default"].input.attrs(_common.testIdAttribute).withConfig({
  displayName: "Range__RangeInput",
  componentId: "sc-1hxaclw-2"
})(["width:100%;margin:0;padding:0;background:transparent;border-radius:", "px;appearance:none;", " &:focus{outline:none;}&:focus-visible{box-shadow:0 0 0 3px ", ";}&:-moz-focusring{box-shadow:0 0 0 3px ", ";}&:disabled{cursor:not-allowed;&::-webkit-slider-thumb{cursor:not-allowed;background-color:", ";}&::-moz-range-thumb{cursor:not-allowed;background-color:", ";}&::-ms-thumb{cursor:not-allowed;background-color:", ";}}&::-webkit-slider-thumb{appearance:none;border-radius:50%;cursor:pointer;", " ", "}&::-moz-range-thumb{border:0;border-radius:50%;cursor:pointer;", "}&::-ms-thumb{border:0;border-radius:50%;cursor:pointer;", "}&::-webkit-slider-runnable-track{width:100%;background-color:", ";border-radius:8px;", "}&::-moz-range-track{width:100%;background-color:", ";border-radius:8px;", "}&::-ms-track{width:100%;background:transparent;border-color:transparent;color:transparent;", " ", "}&::-ms-fill-lower,&::-ms-fill-upper{background-color:", ";border-radius:8px;}"], function (p) {
  return p.theme.borderRadii.m;
}, rangeSize, function (p) {
  return p.theme.colors.palette.primary.disabled;
}, function (p) {
  return p.theme.colors.palette.primary.disabled;
}, function (p) {
  return p.theme.colors.palette.koala;
}, function (p) {
  return p.theme.colors.palette.koala;
}, function (p) {
  return p.theme.colors.palette.koala;
}, chromeThumbMargin, (0, _system.compose)(thumbSize, rangeColor), (0, _system.compose)(thumbSize, rangeColor), (0, _system.compose)(thumbSize, rangeColor), function (p) {
  return p.theme.colors.palette.owl;
}, trackSize, function (p) {
  return p.theme.colors.palette.owl;
}, trackSize, IE11TrackBorder, trackSize, function (p) {
  return p.theme.colors.palette.owl;
});

var separateWrapperAndRemainingProps = function separateWrapperAndRemainingProps(props) {
  var _context;

  var extract = (0, _concat["default"])(_context = []).call(_context, (0, _toConsumableArray2["default"])(_space.marginPropKeys), (0, _toConsumableArray2["default"])(_layout.widthPropKeys), (0, _toConsumableArray2["default"])(_layout.displayPropKeys), (0, _toConsumableArray2["default"])(_flexbox.flexItemPropKeys));

  var _extractProps = (0, _utilities.extractProps)(props, extract),
      wrapperProps = _extractProps.extractedProps,
      remainingProps = _extractProps.remainingProps;

  return {
    wrapperProps: wrapperProps,
    remainingProps: remainingProps
  };
};