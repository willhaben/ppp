"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Textarea = void 0;

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/toConsumableArray"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _common = require("../../common");

var _Label = require("../Label/Label");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _position = require("@wh-components/system/position");

var _flexbox = require("@wh-components/system/flexbox");

var _Input = require("../Input/Input");

var _utilities = require("@wh-components/system/utilities");

var _variant = require("@wh-components/system/variant");

var textareaSizes = (0, _variant.variant)({
  scale: 'components.textarea.sizes',
  prop: 'textareaSize'
});

var TextareaElement = _styledComponents["default"].textarea.attrs(_common.testIdAttribute).withConfig({
  displayName: "Textarea__TextareaElement",
  componentId: "sc-1xtphl0-0"
})(["resize:vertical;height:auto;", " padding-top:", "px;padding-bottom:", "px;", ""], _Input.inputElementCommonCss, function (p) {
  return p.theme.space.sm;
}, function (p) {
  return p.theme.space.sm;
}, textareaSizes);

var Textarea = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var id = _ref.id,
      testId = _ref.testId,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'large' : _ref$size,
      _ref$state = _ref.state,
      state = _ref$state === void 0 ? 'normal' : _ref$state,
      _ref$inline = _ref.inline,
      inline = _ref$inline === void 0 ? false : _ref$inline,
      label = _ref.label,
      showRequiredLabel = _ref.showRequiredLabel,
      hint = _ref.hint,
      comment = _ref.comment,
      disabled = _ref.disabled,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["id", "testId", "size", "state", "inline", "label", "showRequiredLabel", "hint", "comment", "disabled"]);

  var _separateWrapperAndRe = separateWrapperAndRemainingProps(props),
      wrapperProps = _separateWrapperAndRe.wrapperProps,
      remainingProps = _separateWrapperAndRe.remainingProps;

  return /*#__PURE__*/_react["default"].createElement(_Label.Label, (0, _extends2["default"])({
    htmlFor: id,
    state: state,
    disabled: disabled,
    inline: inline,
    label: label,
    required: props.required,
    showRequiredLabel: showRequiredLabel,
    hint: hint,
    comment: comment,
    testIdPrefix: testId
  }, wrapperProps), /*#__PURE__*/_react["default"].createElement(_Input.InputWrapper, {
    state: disabled ? 'normal' : state
  }, /*#__PURE__*/_react["default"].createElement(TextareaElement, (0, _extends2["default"])({}, remainingProps, {
    id: id,
    testId: testId,
    textareaSize: size,
    disabled: disabled,
    ref: ref
  }))));
}); // this avoids setting props like `name` on the wrapper div

exports.Textarea = Textarea;

var separateWrapperAndRemainingProps = function separateWrapperAndRemainingProps(props) {
  var _context;

  var extract = (0, _concat["default"])(_context = []).call(_context, (0, _toConsumableArray2["default"])(_space.spacePropKeys), (0, _toConsumableArray2["default"])(_layout.layoutPropKeys), (0, _toConsumableArray2["default"])(_position.positionPropKeys), (0, _toConsumableArray2["default"])(_flexbox.flexboxPropKeys), (0, _toConsumableArray2["default"])(_common.classNamePropKeys));

  var _extractProps = (0, _utilities.extractProps)(props, extract),
      wrapperProps = _extractProps.extractedProps,
      remainingProps = _extractProps.remainingProps;

  return {
    wrapperProps: wrapperProps,
    remainingProps: remainingProps
  };
};