"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.DefaultCheckboxGroupLayout = exports.CheckboxGroup = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _react = _interopRequireDefault(require("react"));

var _Label = require("../Label/Label");

var _Checkbox = require("./Checkbox");

var CheckboxGroup = function CheckboxGroup(_ref) {
  var testId = _ref.testId,
      label = _ref.label,
      size = _ref.size,
      state = _ref.state,
      disabled = _ref.disabled,
      comment = _ref.comment,
      hint = _ref.hint,
      required = _ref.required,
      showRequiredLabel = _ref.showRequiredLabel,
      checkboxes = _ref.checkboxes,
      inline = _ref.inline,
      _ref$children = _ref.children,
      children = _ref$children === void 0 ? function (checkboxComponents) {
    return /*#__PURE__*/_react["default"].createElement(DefaultCheckboxGroupLayout, null, checkboxComponents);
  } : _ref$children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["testId", "label", "size", "state", "disabled", "comment", "hint", "required", "showRequiredLabel", "checkboxes", "inline", "children"]);
  return /*#__PURE__*/_react["default"].createElement(_Label.Label, (0, _extends2["default"])({
    testIdPrefix: testId,
    label: label,
    state: state,
    disabled: disabled,
    required: required,
    showRequiredLabel: showRequiredLabel,
    comment: comment,
    hint: hint,
    inline: inline,
    align: "checkbox-group",
    size: size
  }, props), children((0, _map["default"])(checkboxes).call(checkboxes, function (checkboxProps) {
    var _context, _checkboxProps$value, _checkboxProps$testId, _context2;

    return /*#__PURE__*/_react["default"].createElement(_Checkbox.Checkbox, (0, _extends2["default"])({
      key: (0, _concat["default"])(_context = "".concat((_checkboxProps$value = checkboxProps.value) !== null && _checkboxProps$value !== void 0 ? _checkboxProps$value : '', "-")).call(_context, (_checkboxProps$testId = checkboxProps.testId) !== null && _checkboxProps$testId !== void 0 ? _checkboxProps$testId : '')
    }, checkboxProps, {
      testId: (0, _concat["default"])(_context2 = "".concat(testId, "-")).call(_context2, checkboxProps.testId),
      size: size,
      state: state,
      disabled: disabled,
      required: required
    }));
  })));
};

exports.CheckboxGroup = CheckboxGroup;

var _StyledDiv = (0, _styledComponents["default"])("div").withConfig({
  displayName: "CheckboxGroup___StyledDiv",
  componentId: "em11gf-0"
})(["display:flex;flex-wrap:wrap;& > *{width:100%;margin-right:", "px;", "{width:calc(50% - ", "px);}}"], function (p) {
  return p.theme.space.s;
}, function (p) {
  return p.theme.media.desktop;
}, function (p) {
  return p.theme.space.s;
});

var DefaultCheckboxGroupLayout = function DefaultCheckboxGroupLayout(props) {
  return /*#__PURE__*/_react["default"].createElement(_StyledDiv, null, props.children);
};

exports.DefaultCheckboxGroupLayout = DefaultCheckboxGroupLayout;