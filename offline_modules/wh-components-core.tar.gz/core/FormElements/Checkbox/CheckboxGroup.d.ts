import { ReactNode, FunctionComponent } from 'react';
import { InputState, TestProps } from '../../common';
import { SpaceProps } from '@wh-components/system/space';
import { LayoutProps } from '@wh-components/system/layout';
import { PositionProps } from '@wh-components/system/position';
import { FlexboxProps } from '@wh-components/system/flexbox';
import { ReactCheckboxProps, CheckboxSize } from './Checkbox';
export interface CheckboxGroupProps extends TestProps {
    label?: string;
    size?: CheckboxSize;
    state?: InputState;
    disabled?: boolean;
    comment?: string;
    hint?: string;
    required?: boolean;
    showRequiredLabel?: boolean;
    /** Array of all props for all Checkbox components that should be created inside the checkbox group */
    checkboxes: CheckboxGroupChildCheckboxProps[];
    /** Sets the label to be inline */
    inline?: boolean;
    children?: (checkboxComponents: ReactNode[]) => ReactNode;
}
export declare type CheckboxGroupChildCheckboxProps = Omit<ReactCheckboxProps & {
    testId: string;
    label?: ReactNode;
}, 'size' | 'state' | 'disabled' | 'required' | 'children'>;
declare type ContainerProps = SpaceProps & LayoutProps & PositionProps & FlexboxProps;
export declare const CheckboxGroup: ({ testId, label, size, state, disabled, comment, hint, required, showRequiredLabel, checkboxes, inline, children, ...props }: CheckboxGroupProps & ContainerProps) => JSX.Element;
export declare const DefaultCheckboxGroupLayout: FunctionComponent;
export {};
