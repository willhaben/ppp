"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Checkbox = void 0;

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/toConsumableArray"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _filter = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/filter"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _variant = require("@wh-components/system/variant");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _position = require("@wh-components/system/position");

var _flexbox = require("@wh-components/system/flexbox");

var _common = require("../../common");

var _Box = require("../../Box/Box");

var _CheckThick = _interopRequireDefault(require("@wh-components/icons/CheckThick"));

var _utilities = require("@wh-components/system/utilities");

var checkboxSizes = (0, _variant.variant)({
  scale: 'components.checkbox.sizes',
  prop: 'checkboxSize'
});
var labelSizes = (0, _variant.variant)({
  scale: 'components.checkboxLabel.sizes',
  prop: 'checkboxSize'
});
var labelColors = (0, _variant.variant)({
  scale: 'components.checkboxLabel.borderColors',
  prop: 'state'
});
var commentColors = (0, _variant.variant)({
  scale: 'components.checkboxComment.colors',
  prop: 'state'
});
var CheckboxIcon = (0, _styledComponents["default"])(_CheckThick["default"]).withConfig({
  displayName: "Checkbox__CheckboxIcon",
  componentId: "sc-7kkiwa-0"
})(["padding:2px;position:absolute;top:0;left:0;opacity:0;transition:opacity 0.1s ease-in-out;color:", ";", ""], function (p) {
  return p.theme.colors.palette.primary.main;
}, checkboxSizes);

var CustomCheckboxContentContainer = _styledComponents["default"].div.withConfig({
  displayName: "Checkbox__CustomCheckboxContentContainer",
  componentId: "sc-7kkiwa-1"
})(["position:absolute;top:0;left:0;", ""], checkboxSizes);

var CustomCheckboxContentContainerCheckedChild = _styledComponents["default"].div.withConfig({
  displayName: "Checkbox__CustomCheckboxContentContainerCheckedChild",
  componentId: "sc-7kkiwa-2"
})(["position:absolute;top:0;left:0;right:0;bottom:0;opacity:0;transition:opacity 0.1s ease-in-out;"]);

var CustomCheckboxContentContainerUncheckedChild = _styledComponents["default"].div.withConfig({
  displayName: "Checkbox__CustomCheckboxContentContainerUncheckedChild",
  componentId: "sc-7kkiwa-3"
})(["position:absolute;top:0;left:0;right:0;bottom:0;"]);

var CheckboxInput = _styledComponents["default"].input.withConfig({
  displayName: "Checkbox__CheckboxInput",
  componentId: "sc-7kkiwa-4"
})(["margin:0;position:absolute;top:0;left:0;opacity:0;&:checked + label > ", "{opacity:1;}&:checked + label > * ", "{opacity:1;}&:disabled + label{color:", ";cursor:not-allowed;&:before{border-color:", ";background-color:", ";}> ", "{color:", ";}}&:focus + label{&:before{box-shadow:0 0 0 3px ", ";}}", ""], CheckboxIcon, CustomCheckboxContentContainerCheckedChild, function (p) {
  return p.theme.colors.palette.elephant;
}, function (p) {
  return p.theme.colors.palette.owl;
}, function (p) {
  return p.theme.colors.palette.babyseal;
}, CheckboxIcon, function (p) {
  return p.theme.colors.palette.primary.disabled;
}, function (p) {
  return p.theme.colors.palette.primary.disabled;
}, checkboxSizes);

var CheckboxLabel = _styledComponents["default"].label.withConfig({
  displayName: "Checkbox__CheckboxLabel",
  componentId: "sc-7kkiwa-5"
})(["display:flex;align-items:center;color:", ";cursor:pointer;&:before{content:'';position:absolute;top:0;left:0;border:1px solid ", ";border-radius:", "px;background-color:", ";}&:hover:before{background-color:", ";}", " ", ""], function (p) {
  return p.theme.colors.palette.verydarkgrey;
}, function (p) {
  return p.theme.colors.palette.grey;
}, function (p) {
  return p.theme.borderRadii.m;
}, function (p) {
  return p.theme.colors.palette.white;
}, function (p) {
  return p.theme.colors.palette.dove;
}, labelSizes, labelColors);

var CheckboxComment = _styledComponents["default"].small.withConfig({
  displayName: "Checkbox__CheckboxComment",
  componentId: "sc-7kkiwa-6"
})(["display:block;margin-top:", "px;font-size:", ";", ""], function (p) {
  return p.theme.space.xs;
}, function (p) {
  return p.theme.fontSizes.s;
}, commentColors);

var Checkbox = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var _context;

  var id = _ref.id,
      testId = _ref.testId,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'medium' : _ref$size,
      _ref$state = _ref.state,
      state = _ref$state === void 0 ? 'normal' : _ref$state,
      label = _ref.label,
      comment = _ref.comment,
      customCheckboxContent = _ref.customCheckboxContent,
      ariaLabelledBy = _ref['aria-labelledby'],
      props = (0, _objectWithoutProperties2["default"])(_ref, ["id", "testId", "size", "state", "label", "comment", "customCheckboxContent", "aria-labelledby"]);
  var customContent = customCheckboxContent === null || customCheckboxContent === void 0 ? void 0 : customCheckboxContent(size, state);

  var _separateWrapperAndRe = separateWrapperAndRemainingProps(props),
      wrapperProps = _separateWrapperAndRe.wrapperProps,
      remainingProps = _separateWrapperAndRe.remainingProps;

  return /*#__PURE__*/_react["default"].createElement(_Box.Box, (0, _extends2["default"])({
    paddingVertical: "xs"
  }, wrapperProps), /*#__PURE__*/_react["default"].createElement(_Box.Box, {
    position: "relative"
  }, /*#__PURE__*/_react["default"].createElement(CheckboxInput, (0, _extends2["default"])({
    type: "checkbox",
    id: id
  }, remainingProps, {
    ref: ref,
    checkboxSize: size,
    "data-testid": testId,
    "aria-labelledby": (0, _filter["default"])(_context = [ariaLabelledBy, "".concat(id, "-label")]).call(_context, Boolean).join(' ')
  })), /*#__PURE__*/_react["default"].createElement(CheckboxLabel, {
    id: "".concat(id, "-label"),
    checkboxSize: size,
    state: state,
    htmlFor: id,
    "data-testid": "".concat(testId, "-label")
  }, label, typeof customContent === 'undefined' ? /*#__PURE__*/_react["default"].createElement(CheckboxIcon, {
    checkboxSize: size,
    state: state,
    "aria-hidden": "true",
    focusable: "false"
  }) : /*#__PURE__*/_react["default"].createElement(CustomCheckboxContentContainer, {
    checkboxSize: size
  }, /*#__PURE__*/_react["default"].createElement(CustomCheckboxContentContainerUncheckedChild, null, customContent.unchecked), /*#__PURE__*/_react["default"].createElement(CustomCheckboxContentContainerCheckedChild, null, customContent.checked)))), comment && /*#__PURE__*/_react["default"].createElement(CheckboxComment, {
    state: state,
    "data-testid": "".concat(testId, "-comment")
  }, comment));
}); // this avoids setting props like `name` on the wrapper div

exports.Checkbox = Checkbox;

var separateWrapperAndRemainingProps = function separateWrapperAndRemainingProps(props) {
  var _context2;

  var extract = (0, _concat["default"])(_context2 = []).call(_context2, (0, _toConsumableArray2["default"])(_space.spacePropKeys), (0, _toConsumableArray2["default"])(_layout.displayPropKeys), (0, _toConsumableArray2["default"])(_position.positionPropKeys), (0, _toConsumableArray2["default"])(_flexbox.flexboxPropKeys), (0, _toConsumableArray2["default"])(_common.classNamePropKeys));

  var _extractProps = (0, _utilities.extractProps)(props, extract),
      wrapperProps = _extractProps.extractedProps,
      remainingProps = _extractProps.remainingProps;

  return {
    wrapperProps: wrapperProps,
    remainingProps: remainingProps
  };
};