import { FunctionComponent } from 'react';
import { InputState, InputSize, ClassNameProps } from '../../common';
import { MarginProps } from '@wh-components/system/space';
import { WidthProps, DisplayProps } from '@wh-components/system/layout';
import { FlexItemProps } from '@wh-components/system/flexbox';
import { RadioSize } from '../Radio/Radio';
import { CheckboxSize } from '../Checkbox/Checkbox';
declare type ContainerProps = MarginProps & WidthProps & DisplayProps & FlexItemProps & ClassNameProps;
interface LabelProps extends ContainerProps {
    htmlFor?: string;
    /** this is necessary for matching the label baseline to the first radio/checkbox, only applied when inline=true and align='radio-group' or 'checkbox-group', default is 'medium' */
    size?: InputSize | RadioSize | CheckboxSize;
    state?: InputState;
    disabled?: boolean;
    label?: string;
    inline?: boolean;
    /** only applied when inline=true, default is 'center' */
    align?: 'center' | 'radio-group' | 'checkbox-group';
    required?: boolean;
    showRequiredLabel?: boolean;
    hint?: string;
    comment?: string;
    testIdPrefix?: string;
    /** usable for injecting props to the <label> element from headless components like downshift */
    extraLabelProps?: any;
}
export declare const Label: FunctionComponent<LabelProps>;
export {};
