"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Label = void 0;

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/toConsumableArray"));

var _includes = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/includes"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _react = _interopRequireDefault(require("react"));

var _common = require("../../common");

var _variant = require("@wh-components/system/variant");

var _Box = require("../../Box/Box");

var _Text = require("../../Text/Text");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _flexbox = require("@wh-components/system/flexbox");

var _utilities = require("@wh-components/system/utilities");

var _StyledText = (0, _styledComponents["default"])(_Text.Text).withConfig({
  displayName: "Label___StyledText",
  componentId: "sc-1nw9nyg-0"
})(["margin-left:", "px;"], function (p) {
  return p.theme.space.s;
});

var Label = function Label(_ref) {
  var htmlFor = _ref.htmlFor,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'medium' : _ref$size,
      _ref$state = _ref.state,
      state = _ref$state === void 0 ? 'normal' : _ref$state,
      disabled = _ref.disabled,
      label = _ref.label,
      _ref$inline = _ref.inline,
      inline = _ref$inline === void 0 ? false : _ref$inline,
      _ref$align = _ref.align,
      align = _ref$align === void 0 ? 'center' : _ref$align,
      _ref$required = _ref.required,
      required = _ref$required === void 0 ? false : _ref$required,
      _ref$showRequiredLabe = _ref.showRequiredLabel,
      showRequiredLabel = _ref$showRequiredLabe === void 0 ? false : _ref$showRequiredLabe,
      hint = _ref.hint,
      comment = _ref.comment,
      testIdPrefix = _ref.testIdPrefix,
      extraLabelProps = _ref.extraLabelProps,
      children = _ref.children,
      containerProps = (0, _objectWithoutProperties2["default"])(_ref, ["htmlFor", "size", "state", "disabled", "label", "inline", "align", "required", "showRequiredLabel", "hint", "comment", "testIdPrefix", "extraLabelProps", "children"]);
  var wrapperProps = separateWrapperAndRemainingProps(containerProps).wrapperProps;
  return /*#__PURE__*/_react["default"].createElement(_Box.Box, wrapperProps, /*#__PURE__*/_react["default"].createElement(_Box.Box, {
    display: "flex",
    flexWrap: "wrap"
  }, label && /*#__PURE__*/_react["default"].createElement(StyledLabel, (0, _extends2["default"])({}, extraLabelProps, {
    size: size,
    inline: inline,
    align: align,
    htmlFor: htmlFor,
    "data-testid": testIdPrefix && "".concat(testIdPrefix, "-label")
  }), /*#__PURE__*/_react["default"].createElement(_Text.Text, {
    fontWeight: "semibold",
    color: "palette.verydarkgrey"
  }, label), showRequiredLabel && /*#__PURE__*/_react["default"].createElement(_StyledText, {
    fontSize: "s",
    color: "palette.elephant",
    testId: testIdPrefix && "".concat(testIdPrefix, "-label-required")
  }, required ? 'Pflichtfeld' : 'optional')), hint && /*#__PURE__*/_react["default"].createElement(StyledHint, {
    inline: inline,
    "data-testid": testIdPrefix && "".concat(testIdPrefix, "-hint")
  }, hint), /*#__PURE__*/_react["default"].createElement(StyledContentWrapper, {
    inline: inline
  }, children)), comment && /*#__PURE__*/_react["default"].createElement(StyledComment, {
    state: disabled ? 'normal' : state,
    "data-testid": testIdPrefix && "".concat(testIdPrefix, "-comment")
  }, comment));
};

exports.Label = Label;
var labelAlignSelf = {
  center: 'center',
  'radio-group': 'flex-start',
  'checkbox-group': 'flex-start'
};

var StyledLabel = _styledComponents["default"].label.withConfig({
  displayName: "Label__StyledLabel",
  componentId: "sc-1nw9nyg-1"
})(["order:", ";display:", ";align-items:", ";height:", ";height:", ";align-self:", ";margin-right:", "px;margin-bottom:", ";"], function (p) {
  return p.inline && 1;
}, function (p) {
  var _context;

  return p.inline && (0, _includes["default"])(_context = ['radio-group', 'checkbox-group']).call(_context, p.align) ? 'flex' : 'inline-block';
}, function (p) {
  var _context2;

  return p.inline && (0, _includes["default"])(_context2 = ['radio-group', 'checkbox-group']).call(_context2, p.align) && 'center';
}, function (p) {
  return p.inline && p.align === 'radio-group' && "".concat(p.theme.components.radioGroupInlineLabel.sizes[p.size].height, "px");
}, function (p) {
  return p.inline && p.align === 'checkbox-group' && "".concat(p.theme.components.checkboxGroupInlineLabel.sizes[p.size].height, "px");
}, function (p) {
  return p.inline && labelAlignSelf[p.align];
}, function (p) {
  return p.theme.space.s;
}, function (p) {
  return !p.inline && "".concat(p.theme.space.xs, "px");
});

var StyledHint = _styledComponents["default"].small.withConfig({
  displayName: "Label__StyledHint",
  componentId: "sc-1nw9nyg-2"
})(["display:inline-block;align-self:flex-end;margin-bottom:", "px;font-size:", ";color:", ";text-align:right;flex-grow:", ";flex-basis:", ";"], function (p) {
  return p.theme.space.xs;
}, function (p) {
  return p.theme.fontSizes.s;
}, function (p) {
  return p.theme.colors.palette.elephant;
}, function (p) {
  return !p.inline && 1;
}, function (p) {
  return p.inline && '100%';
});

var StyledContentWrapper = _styledComponents["default"].div.withConfig({
  displayName: "Label__StyledContentWrapper",
  componentId: "sc-1nw9nyg-3"
})(["order:", ";flex-grow:", ";flex-basis:", ";"], function (p) {
  return p.inline && 2;
}, function (p) {
  return p.inline && 1;
}, function (p) {
  return p.inline ? '0%' : '100%';
});

var commentColors = (0, _variant.variant)({
  scale: 'components.input.comment.colors',
  prop: 'state'
});

var StyledComment = _styledComponents["default"].small.withConfig({
  displayName: "Label__StyledComment",
  componentId: "sc-1nw9nyg-4"
})(["display:inline-block;margin-top:", "px;font-size:", ";", ""], function (p) {
  return p.theme.space.xs;
}, function (p) {
  return p.theme.fontSizes.s;
}, commentColors); // this avoids setting props like `name` or `placeholder` on the wrapper div


var separateWrapperAndRemainingProps = function separateWrapperAndRemainingProps(props) {
  var _context3;

  var extract = (0, _concat["default"])(_context3 = []).call(_context3, (0, _toConsumableArray2["default"])(_space.marginPropKeys), (0, _toConsumableArray2["default"])(_layout.widthPropKeys), (0, _toConsumableArray2["default"])(_layout.displayPropKeys), (0, _toConsumableArray2["default"])(_flexbox.flexItemPropKeys), (0, _toConsumableArray2["default"])(_common.classNamePropKeys));

  var _extractProps = (0, _utilities.extractProps)(props, extract),
      wrapperProps = _extractProps.extractedProps,
      remainingProps = _extractProps.remainingProps;

  return {
    wrapperProps: wrapperProps,
    remainingProps: remainingProps
  };
};