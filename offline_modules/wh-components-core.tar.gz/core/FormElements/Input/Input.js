"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Input = exports.inputElementCommonCss = exports.InputWrapper = void 0;

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/toConsumableArray"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireWildcard(require("react"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _variant = require("@wh-components/system/variant");

var _system = require("@wh-components/system");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _position = require("@wh-components/system/position");

var _flexbox = require("@wh-components/system/flexbox");

var _common = require("../../common");

var _Button = require("../../Button/Button");

var _Label = require("../Label/Label");

var _utilities = require("@wh-components/system/utilities");

var inputSizes = (0, _variant.variant)({
  scale: 'components.input.sizes',
  prop: 'inputSize'
});
var borderColors = (0, _variant.variant)({
  scale: 'components.input.colors',
  prop: 'state'
});
var addonSizes = (0, _variant.variant)({
  scale: 'components.input.addon.sizes',
  prop: 'inputSize'
});
var addonColors = (0, _variant.variant)({
  scale: 'components.input.addon.colors',
  prop: 'state'
});
var iconButtonSizes = (0, _variant.variant)({
  scale: 'components.input.iconButton.button.sizes',
  prop: 'buttonSize'
});
var iconSizes = (0, _system.system)({
  buttonSize: {
    properties: ['height', 'width'],
    scale: 'components.input.iconButton.icon.sizes'
  }
});

var InputWrapper = _styledComponents["default"].div.withConfig({
  displayName: "Input__InputWrapper",
  componentId: "sc-18xaepr-0"
})(["display:flex;border:1px solid;border-radius:", "px;background-color:", ";transition:box-shadow 0.2s;& > *:first-child{border-top-left-radius:", "px;border-bottom-left-radius:", "px;}& > *:last-child{border-top-right-radius:", "px;border-bottom-right-radius:", "px;}&:focus-within{box-shadow:0 0 0 3px ", ";}", ""], function (p) {
  return p.theme.borderRadii.m;
}, function (p) {
  return p.theme.colors.palette.white;
}, function (p) {
  return p.theme.borderRadii.m;
}, function (p) {
  return p.theme.borderRadii.m;
}, function (p) {
  return p.theme.borderRadii.m;
}, function (p) {
  return p.theme.borderRadii.m;
}, function (p) {
  return p.theme.colors.palette.primary.disabled;
}, borderColors);

exports.InputWrapper = InputWrapper;
var inputElementCommonCss = (0, _styledComponents.css)(["width:100%;min-width:0;padding:0.375em 0.75em;color:", ";background-color:", ";border:0;outline:0;&:disabled{background-color:", ";cursor:not-allowed;}"], function (p) {
  return p.theme.colors.palette.verydarkgrey;
}, function (p) {
  return p.theme.colors.palette.white;
}, function (p) {
  return p.theme.colors.palette.babyseal;
}); // cast as workaround necessary because of injected testId and inputSize props

exports.inputElementCommonCss = inputElementCommonCss;

var InputElement = _styledComponents["default"].input.attrs(_common.testIdAttribute).withConfig({
  displayName: "Input__InputElement",
  componentId: "sc-18xaepr-1"
})(["", " ", ""], inputElementCommonCss, inputSizes);

var InputAddon = _styledComponents["default"].div.withConfig({
  displayName: "Input__InputAddon",
  componentId: "sc-18xaepr-2"
})(["padding:0 0.75em;display:flex;align-items:center;justify-content:center;flex:none;color:", ";user-select:none;&:first-child{border-right-width:1px;border-right-style:solid;}&:last-child{border-left-width:1px;border-left-style:solid;}", ""], function (p) {
  return p.theme.colors.palette.verydarkgrey;
}, (0, _system.compose)(addonSizes, addonColors));

var InputActionButton = (0, _styledComponents["default"])(_Button.IconButton).attrs({
  variant: 'transparent'
}).withConfig({
  displayName: "Input__InputActionButton",
  componentId: "sc-18xaepr-3"
})(["border:0;color:", ";", " svg{", "}"], function (p) {
  return p.theme.colors.palette.koala;
}, iconButtonSizes, iconSizes);
var Input = /*#__PURE__*/(0, _react.forwardRef)(function (_ref, ref) {
  var id = _ref.id,
      testId = _ref.testId,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'large' : _ref$size,
      _ref$state = _ref.state,
      state = _ref$state === void 0 ? 'normal' : _ref$state,
      _ref$inline = _ref.inline,
      inline = _ref$inline === void 0 ? false : _ref$inline,
      label = _ref.label,
      showRequiredLabel = _ref.showRequiredLabel,
      hint = _ref.hint,
      comment = _ref.comment,
      Icon = _ref.Icon,
      onIconClick = _ref.onIconClick,
      prepend = _ref.prepend,
      append = _ref.append,
      disabled = _ref.disabled,
      iconRef = _ref.iconRef,
      iconTestId = _ref.iconTestId,
      iconAriaLabel = _ref.iconAriaLabel,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["id", "testId", "size", "state", "inline", "label", "showRequiredLabel", "hint", "comment", "Icon", "onIconClick", "prepend", "append", "disabled", "iconRef", "iconTestId", "iconAriaLabel"]);

  var _separateWrapperAndRe = separateWrapperAndRemainingProps(props),
      wrapperProps = _separateWrapperAndRe.wrapperProps,
      remainingProps = _separateWrapperAndRe.remainingProps;

  return /*#__PURE__*/_react["default"].createElement(_Label.Label, (0, _extends2["default"])({
    htmlFor: id,
    state: state,
    disabled: disabled,
    inline: inline,
    label: label,
    required: props.required,
    showRequiredLabel: showRequiredLabel,
    hint: hint,
    comment: comment,
    testIdPrefix: testId
  }, wrapperProps), /*#__PURE__*/_react["default"].createElement(InputWrapper, {
    state: disabled ? 'normal' : state
  }, prepend && /*#__PURE__*/_react["default"].createElement(InputAddon, {
    inputSize: size,
    state: disabled ? 'normal' : state
  }, typeof prepend === 'string' ? prepend : /*#__PURE__*/(0, _react.createElement)(prepend, {
    color: 'inherit'
  })), /*#__PURE__*/_react["default"].createElement(InputElement, (0, _extends2["default"])({}, remainingProps, {
    disabled: disabled,
    inputSize: size,
    ref: ref,
    id: id,
    testId: testId
  })), Icon && !disabled && /*#__PURE__*/_react["default"].createElement(InputActionButton, {
    "aria-label": iconAriaLabel,
    testId: iconTestId,
    ref: iconRef,
    Icon: Icon,
    buttonSize: size,
    onClick: onIconClick
  }), append && /*#__PURE__*/_react["default"].createElement(InputAddon, {
    inputSize: size,
    state: disabled ? 'normal' : state
  }, typeof append === 'string' ? append : /*#__PURE__*/(0, _react.createElement)(append, {
    color: 'inherit'
  }))));
}); // this avoids setting props like `name` on the wrapper div

exports.Input = Input;

var separateWrapperAndRemainingProps = function separateWrapperAndRemainingProps(props) {
  var _context;

  var extract = (0, _concat["default"])(_context = []).call(_context, (0, _toConsumableArray2["default"])(_space.spacePropKeys), (0, _toConsumableArray2["default"])(_layout.layoutPropKeys), (0, _toConsumableArray2["default"])(_position.positionPropKeys), (0, _toConsumableArray2["default"])(_flexbox.flexboxPropKeys), (0, _toConsumableArray2["default"])(_common.classNamePropKeys));

  var _extractProps = (0, _utilities.extractProps)(props, extract),
      wrapperProps = _extractProps.extractedProps,
      remainingProps = _extractProps.remainingProps;

  return {
    wrapperProps: wrapperProps,
    remainingProps: remainingProps
  };
};