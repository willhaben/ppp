export declare const BlockBodyScroll: import("styled-components").GlobalStyleComponent<{}, import("styled-components").DefaultTheme>;
