"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Card = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _Box = require("../Box/Box");

var Card = (0, _styledComponents["default"])(_Box.Box).withConfig({
  displayName: "Card",
  componentId: "nhpl83-0"
})({});
exports.Card = Card;
Card.defaultProps = {
  padding: 'm',
  backgroundColor: {
    phone: 'palette.babyseal',
    tablet: 'palette.polarbear'
  },
  border: {
    tablet: 'owl'
  },
  borderRadius: {
    tablet: 'm'
  },
  overflow: {
    tablet: 'hidden'
  }
};