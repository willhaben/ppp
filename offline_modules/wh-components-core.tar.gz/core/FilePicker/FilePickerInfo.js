"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.FilePickerInfo = void 0;

var _isFinite = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/number/is-finite"));

var _Box = require("../Box/Box");

var _react = _interopRequireDefault(require("react"));

var FilePickerInfo = function FilePickerInfo(props) {
  var maxSingleFileSizeParagraph = (0, _isFinite["default"])(props.maxSingleFileSizeInMB) && /*#__PURE__*/_react["default"].createElement("p", null, "Max. Gr\xF6\xDFe eines Anhangs: ", props.maxSingleFileSizeInMB, "MB");

  var maxSumOfFileSizesParagraph = (0, _isFinite["default"])(props.maxSumOfFileSizesInMB) && /*#__PURE__*/_react["default"].createElement("p", null, "Max. Gesamtgr\xF6\xDFe aller Anh\xE4nge: ", props.maxSumOfFileSizesInMB, "MB");

  var maxFileCountParagraph = (0, _isFinite["default"])(props.maxFileCount) && /*#__PURE__*/_react["default"].createElement("p", null, "Max. Gesamtzahl der Anh\xE4nge: ", props.maxFileCount);

  return /*#__PURE__*/_react["default"].createElement(_Box.Box, {
    margin: "10px",
    fontSize: "xs"
  }, maxSingleFileSizeParagraph, maxSumOfFileSizesParagraph, maxFileCountParagraph);
};

exports.FilePickerInfo = FilePickerInfo;