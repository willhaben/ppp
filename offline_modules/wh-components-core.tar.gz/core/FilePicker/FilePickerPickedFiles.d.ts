import { FunctionComponent } from 'react';
import { FileWithAcceptanceState } from './helper/FilePickerHelperTypes';
interface FilePickerPickedFilesProps {
    files: FileWithAcceptanceState[];
    disabled?: boolean;
    removeFile: (file: FileWithAcceptanceState) => void;
}
export declare const FilePickerPickedFiles: FunctionComponent<FilePickerPickedFilesProps>;
export {};
