import { FunctionComponent } from 'react';
interface FilePickerInfoProps {
    maxSingleFileSizeInMB: number;
    maxSumOfFileSizesInMB: number;
    maxFileCount: number;
}
export declare const FilePickerInfo: FunctionComponent<FilePickerInfoProps>;
export {};
