import { FunctionComponent } from 'react';
import { FilePickerProps } from './helper/FilePickerHelperTypes';
export declare const FilePicker: FunctionComponent<FilePickerProps>;
