"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.FilePicker = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _react = _interopRequireDefault(require("react"));

var _Flex = require("../Flex/Flex");

var _FilePickerDropzone = require("./FilePickerDropzone");

var _FilePickerInfo = require("./FilePickerInfo");

var _FilePickerPickedFiles = require("./FilePickerPickedFiles");

var _FilePickerHelperFuncs = require("./helper/FilePickerHelperFuncs");

var _layout = require("@wh-components/system/layout");

var _utilities = require("@wh-components/system/utilities");

var _Label = require("../FormElements/Label/Label");

var FilePicker = function FilePicker(props) {
  var _props$testId;

  var layoutProps = (0, _utilities.extractProps)(props, _layout.layoutPropKeys).extractedProps;

  var fileCountReached = function fileCountReached() {
    return props.files.length >= props.maxFileCount;
  };

  return /*#__PURE__*/_react["default"].createElement(_Label.Label, {
    htmlFor: props.id,
    label: props.label,
    required: props.required,
    showRequiredLabel: props.showRequiredLabel
  }, /*#__PURE__*/_react["default"].createElement(_Flex.Flex, (0, _extends2["default"])({
    flexDirection: "column"
  }, layoutProps), /*#__PURE__*/_react["default"].createElement(_Flex.Flex, {
    flexDirection: {
      phone: 'column',
      tablet: 'row'
    },
    alignItems: {
      phone: 'stretch',
      tablet: 'center'
    },
    flexGrow: 1
  }, /*#__PURE__*/_react["default"].createElement(_FilePickerDropzone.FilePickerDropzone, {
    id: props.id || '',
    name: props.name,
    testId: (_props$testId = props.testId) !== null && _props$testId !== void 0 ? _props$testId : 'filePickerDropzoneInput',
    droppabilityState: (0, _FilePickerHelperFuncs.getDroppabilityState)(props.rejectReason, fileCountReached()),
    onDrop: (0, _FilePickerHelperFuncs.onDrop)({
      files: props.files,
      onFilesChanged: props.onFilesChanged,
      maxFileCount: props.maxFileCount,
      maxSumOfFileSizesInMB: props.maxSumOfFileSizesInMB,
      maxSingleFileSizeInMB: props.maxSingleFileSizeInMB
    }),
    accept: props.accept,
    multiple: props.maxFileCount > 1,
    disabled: props.disabled || fileCountReached(),
    innerRef: props.innerRef,
    flexGrow: 1,
    alignSelf: "stretch",
    minHeight: "180px"
  }), /*#__PURE__*/_react["default"].createElement(_FilePickerInfo.FilePickerInfo, {
    maxFileCount: props.maxFileCount,
    maxSingleFileSizeInMB: props.maxSingleFileSizeInMB,
    maxSumOfFileSizesInMB: props.maxSumOfFileSizesInMB
  })), /*#__PURE__*/_react["default"].createElement(_FilePickerPickedFiles.FilePickerPickedFiles, {
    files: props.files,
    disabled: props.disabled,
    removeFile: (0, _FilePickerHelperFuncs.removeFile)({
      files: props.files,
      onFilesChanged: props.onFilesChanged
    })
  })));
};

exports.FilePicker = FilePicker;
FilePicker.defaultProps = {
  label: 'Anhänge'
};