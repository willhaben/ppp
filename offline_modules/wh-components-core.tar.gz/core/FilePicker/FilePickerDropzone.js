"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.FilePickerDropzoneInner = exports.TOP_TEXT_FILE_COUNT_REACHED_DEFAULT = exports.TOP_TEXT_ACTIVE = exports.TOP_TEXT_FILE_COUNT_EXCEEDED = exports.BUTTON_TEXT_IDLE = exports.MIDDLE_TEXT_IDLE = exports.TOP_TEXT_IDLE = exports.FilePickerDropzone = void 0;

var _construct = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/reflect/construct"));

var _classCallCheck2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/classCallCheck"));

var _inherits2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/inherits"));

var _possibleConstructorReturn2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/possibleConstructorReturn"));

var _getPrototypeOf2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/getPrototypeOf"));

var _wrapNativeSuper2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/wrapNativeSuper"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _toConsumableArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/toConsumableArray"));

var _react = _interopRequireDefault(require("react"));

var _reactDropzone = require("react-dropzone");

var _Box = require("../Box/Box");

var _Text = require("../Text/Text");

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _layout = require("@wh-components/system/layout");

var _utilities = require("@wh-components/system/utilities");

var _flexbox = require("@wh-components/system/flexbox");

var _position = require("@wh-components/system/position");

var _Button = require("../Button/Button");

var _context;

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = (0, _getPrototypeOf2["default"])(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = (0, _getPrototypeOf2["default"])(this).constructor; result = (0, _construct["default"])(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return (0, _possibleConstructorReturn2["default"])(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !_construct["default"]) return false; if (_construct["default"].sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call((0, _construct["default"])(Date, [], function () {})); return true; } catch (e) { return false; } }

var wrapperPropKeys = (0, _concat["default"])(_context = []).call(_context, (0, _toConsumableArray2["default"])(_layout.layoutPropKeys), (0, _toConsumableArray2["default"])(_flexbox.flexItemPropKeys), (0, _toConsumableArray2["default"])(_position.positionPropKeys));

var FilePickerDropzone = function FilePickerDropzone(_ref) {
  var onDrop = _ref.onDrop,
      accept = _ref.accept,
      multiple = _ref.multiple,
      disabled = _ref.disabled,
      _ref$textFileCountRea = _ref.textFileCountReached,
      textFileCountReached = _ref$textFileCountRea === void 0 ? TOP_TEXT_FILE_COUNT_REACHED_DEFAULT : _ref$textFileCountRea,
      remainingProps = (0, _objectWithoutProperties2["default"])(_ref, ["onDrop", "accept", "multiple", "disabled", "textFileCountReached"]);

  var _useDropzone = (0, _reactDropzone.useDropzone)({
    onDrop: onDrop,
    accept: accept,
    multiple: multiple,
    disabled: disabled
  }),
      getRootProps = _useDropzone.getRootProps,
      getInputProps = _useDropzone.getInputProps,
      isDragActive = _useDropzone.isDragActive;

  return /*#__PURE__*/_react["default"].createElement(FilePickerDropzoneInner, (0, _extends2["default"])({
    textFileCountReached: textFileCountReached,
    getRootProps: getRootProps,
    getInputProps: getInputProps,
    isDragActive: isDragActive
  }, remainingProps));
};

exports.FilePickerDropzone = FilePickerDropzone;
var DummyButton = (0, _styledComponents["default"])(_Button.Button).withConfig({
  displayName: "FilePickerDropzone__DummyButton",
  componentId: "sc-1qudha4-0"
})(["pointer-events:none;"]); // http://ideasintosoftware.com/exhaustive-switch-in-typescript/

var UnexpectedCaseError = /*#__PURE__*/function (_Error) {
  (0, _inherits2["default"])(UnexpectedCaseError, _Error);

  var _super = _createSuper(UnexpectedCaseError);

  function UnexpectedCaseError(val) {
    (0, _classCallCheck2["default"])(this, UnexpectedCaseError);
    return _super.call(this, "Unexpected case: ".concat(val));
  }

  return UnexpectedCaseError;
}( /*#__PURE__*/(0, _wrapNativeSuper2["default"])(Error));

var TOP_TEXT_IDLE = 'Datei hineinziehen';
exports.TOP_TEXT_IDLE = TOP_TEXT_IDLE;
var MIDDLE_TEXT_IDLE = 'oder';
exports.MIDDLE_TEXT_IDLE = MIDDLE_TEXT_IDLE;
var BUTTON_TEXT_IDLE = 'Datei hochladen';
exports.BUTTON_TEXT_IDLE = BUTTON_TEXT_IDLE;
var TOP_TEXT_FILE_COUNT_EXCEEDED = 'Gesamtanzahl aller Anhänge überschritten!';
exports.TOP_TEXT_FILE_COUNT_EXCEEDED = TOP_TEXT_FILE_COUNT_EXCEEDED;
var TOP_TEXT_ACTIVE = 'Jetzt loslassen';
exports.TOP_TEXT_ACTIVE = TOP_TEXT_ACTIVE;
var TOP_TEXT_FILE_COUNT_REACHED_DEFAULT = 'Maximale Gesamtzahl der Anhänge erreicht.';
exports.TOP_TEXT_FILE_COUNT_REACHED_DEFAULT = TOP_TEXT_FILE_COUNT_REACHED_DEFAULT;

var FilePickerDropzoneInner = function FilePickerDropzoneInner(props) {
  var getRootBoxProps = function getRootBoxProps() {
    var rootBoxProps = (0, _utilities.extractProps)(props, wrapperPropKeys).extractedProps;
    rootBoxProps.backgroundColor = 'palette.white';
    rootBoxProps.borderStyle = 'dashed';
    rootBoxProps.borderWidth = '1px';
    rootBoxProps.borderRadius = '5px';
    rootBoxProps.fontSize = 's';
    rootBoxProps.borderColor = 'palette.koala';

    if (props.isDragActive) {
      rootBoxProps.borderColor = 'palette.primary.main';
      rootBoxProps.color = 'palette.primary.main';
      rootBoxProps.fontWeight = 'bold';
    } else if (props.droppabilityState === 'fileCountExceeded' || props.droppabilityState === 'fileSizesSumExceeded') {
      rootBoxProps.borderColor = 'adStatus.rejected';
      rootBoxProps.color = 'adStatus.rejected';
    } else if (props.droppabilityState === 'fileCountReached') {
      rootBoxProps.color = 'palette.elephant';
    }

    rootBoxProps.display = 'flex';
    rootBoxProps.flexDirection = 'column';
    rootBoxProps.justifyContent = 'center';
    rootBoxProps.alignItems = 'center';
    rootBoxProps.testId = 'filepicker-dropzone-content';
    return rootBoxProps;
  };

  var _ref2 = function () {
    if (props.isDragActive) {
      return {
        topText: TOP_TEXT_ACTIVE,
        middleText: null,
        buttonText: null
      };
    } else {
      switch (props.droppabilityState) {
        case 'droppable':
          return {
            topText: TOP_TEXT_IDLE,
            middleText: MIDDLE_TEXT_IDLE,
            buttonText: BUTTON_TEXT_IDLE
          };

        case 'fileCountExceeded':
          return {
            topText: TOP_TEXT_FILE_COUNT_EXCEEDED,
            middleText: null,
            buttonText: 'Erneut versuchen'
          };

        case 'fileSizesSumExceeded':
          return {
            topText: 'Gesamtgröße aller Anhänge überschritten!',
            middleText: null,
            buttonText: 'Erneut versuchen'
          };

        case 'fileCountReached':
          return {
            topText: props.textFileCountReached,
            middleText: null,
            buttonText: null
          };

        case 'disabled':
          return {
            topText: null,
            middleText: null,
            buttonText: null
          };

        default:
          // unreachable
          throw new UnexpectedCaseError(props.droppabilityState);
      }
    }
  }(),
      topText = _ref2.topText,
      middleText = _ref2.middleText,
      buttonText = _ref2.buttonText;

  var childElementsMargin = 'xs';
  return /*#__PURE__*/_react["default"].createElement(_Box.Box, props.getRootProps(getRootBoxProps()), /*#__PURE__*/_react["default"].createElement("input", (0, _extends2["default"])({}, props.getInputProps(), {
    id: props.id,
    name: props.name,
    "data-testid": props.testId
  })), topText && /*#__PURE__*/_react["default"].createElement(_Text.Text, {
    margin: childElementsMargin
  }, topText), middleText && /*#__PURE__*/_react["default"].createElement(_Text.Text, {
    margin: childElementsMargin
  }, middleText), buttonText && /*#__PURE__*/_react["default"].createElement(DummyButton, {
    margin: childElementsMargin,
    size: "small",
    color: "complimentary"
  }, buttonText));
};

exports.FilePickerDropzoneInner = FilePickerDropzoneInner;