"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.FilePickerPickedFiles = void 0;

var _parseFloat2 = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/parse-float"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var _ResetCircle = _interopRequireDefault(require("@wh-components/icons/ResetCircle"));

var _CheckCircle = _interopRequireDefault(require("@wh-components/icons/CheckCircle"));

var _Delete = _interopRequireDefault(require("@wh-components/icons/Delete"));

var _react = _interopRequireDefault(require("react"));

var _Button = require("../Button/Button");

var _Text = require("../Text/Text");

var _Box = require("../Box/Box");

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _common = require("../common");

var StyledList = _styledComponents["default"].ul.withConfig({
  displayName: "FilePickerPickedFiles__StyledList",
  componentId: "sc-1v7jw1c-0"
})(["list-style-type:none;margin:0;padding:0;"]);

var StyledListItem = _styledComponents["default"].li.attrs(_common.testIdAttribute).withConfig({
  displayName: "FilePickerPickedFiles__StyledListItem",
  componentId: "sc-1v7jw1c-1"
})(["display:flex;flex-direction:row;align-items:center;justify-content:space-between;&:not(:last-child){border-bottom:1px solid ", ";}"], function (p) {
  return p.theme.colors.palette.owl;
});

var TextWithBreakAll = (0, _styledComponents["default"])(_Text.Text).withConfig({
  displayName: "FilePickerPickedFiles__TextWithBreakAll",
  componentId: "sc-1v7jw1c-2"
})(["word-break:break-all;"]);

var FilePickerPickedFiles = function FilePickerPickedFiles(props) {
  var _context;

  if (props.files.length === 0) {
    return null;
  }

  var rejectReason = function rejectReason(f) {
    if (f.mimeTypeAcceptanceState !== 'accepted') {
      return 'Nicht erlaubter Dateityp. Bitte löschen.';
    }

    if (f.singleFileSizeAcceptanceState !== 'accepted') {
      return 'Datei zu groß. Bitte löschen.';
    }

    return null;
  };

  return /*#__PURE__*/_react["default"].createElement(_Box.Box, {
    marginTop: "s",
    fontSize: "m"
  }, /*#__PURE__*/_react["default"].createElement(StyledList, {
    key: "acceptedFiles"
  }, (0, _map["default"])(_context = props.files).call(_context, function (f) {
    var formattedFileSize = (0, _parseFloat2["default"])((f.file.size / 1024 / 1024).toPrecision(2));
    var isRejectedFileType = f.mimeTypeAcceptanceState !== 'accepted';
    var isRejectedFileSize = f.singleFileSizeAcceptanceState !== 'accepted';
    var isRejected = isRejectedFileType || isRejectedFileSize;
    return /*#__PURE__*/_react["default"].createElement(StyledListItem, {
      key: f.file.name,
      testId: "filepicker-picked-file"
    }, /*#__PURE__*/_react["default"].createElement(_Box.Box, {
      margin: "s"
    }, isRejected ? /*#__PURE__*/_react["default"].createElement(_ResetCircle["default"], {
      size: "medium",
      color: "adStatus.rejected"
    }) : /*#__PURE__*/_react["default"].createElement(_CheckCircle["default"], {
      size: "medium",
      color: "adStatus.active"
    })), /*#__PURE__*/_react["default"].createElement(_Box.Box, {
      flexGrow: 1,
      marginLeft: 0,
      marginRight: "s"
    }, /*#__PURE__*/_react["default"].createElement(TextWithBreakAll, {
      testId: "filepicker-picked-file-filename"
    }, f.file.name), /*#__PURE__*/_react["default"].createElement(_Text.Text, {
      testId: "filepicker-picked-file-reject-reason",
      display: "block",
      fontSize: "s",
      color: "adStatus.rejected"
    }, rejectReason(f))), /*#__PURE__*/_react["default"].createElement(_Text.Text, {
      margin: "s",
      color: "palette.elephant"
    }, formattedFileSize, " MB"), /*#__PURE__*/_react["default"].createElement(_Button.IconButton, {
      Icon: _Delete["default"],
      disabled: props.disabled,
      onClick: function onClick() {
        return props.removeFile(f);
      },
      color: "complimentary",
      variant: "outline",
      marginLeft: "xl",
      height: "30px",
      width: "40px",
      testId: "filepicker-picked-file-remove"
    }));
  })));
};

exports.FilePickerPickedFiles = FilePickerPickedFiles;