import { FunctionComponent, RefObject } from 'react';
import { DropzoneOptions, DropzoneState } from 'react-dropzone';
import { LayoutProps } from '@wh-components/system/layout';
import { FlexItemProps } from '@wh-components/system/flexbox';
import { DroppabilityState } from './helper/FilePickerHelperTypes';
import { PositionProps } from '@wh-components/system/position';
declare type WrapperProps = LayoutProps & FlexItemProps & PositionProps;
declare type FilePickerDropzoneProps = {
    /** Specifies the id of the input tag */
    id: string;
    /** Specifies a name of the input tag */
    name: string;
    testId: string;
    textFileCountReached?: string;
    droppabilityState: DroppabilityState;
    innerRef?: RefObject<HTMLInputElement>;
} & Pick<DropzoneOptions, 'onDrop' | 'accept' | 'multiple' | 'disabled'> & WrapperProps;
export declare const FilePickerDropzone: FunctionComponent<FilePickerDropzoneProps>;
declare type FilePickerDropZoneInnerProps = Exclude<FilePickerDropzoneProps, 'onDrop' | 'accept' | 'multiple' | 'disabled'> & Pick<DropzoneState, 'getRootProps' | 'getInputProps' | 'isDragActive'> & {
    textFileCountReached: string;
};
export declare const TOP_TEXT_IDLE = "Datei hineinziehen";
export declare const MIDDLE_TEXT_IDLE = "oder";
export declare const BUTTON_TEXT_IDLE = "Datei hochladen";
export declare const TOP_TEXT_FILE_COUNT_EXCEEDED = "Gesamtanzahl aller Anh\u00E4nge \u00FCberschritten!";
export declare const TOP_TEXT_ACTIVE = "Jetzt loslassen";
export declare const TOP_TEXT_FILE_COUNT_REACHED_DEFAULT = "Maximale Gesamtzahl der Anh\u00E4nge erreicht.";
export declare const FilePickerDropzoneInner: FunctionComponent<FilePickerDropZoneInnerProps>;
export {};
