import { RefObject } from 'react';
import { IdProps, NoChildrenProps, TestProps } from '../../common';
import { LayoutProps } from '@wh-components/system/layout';
export interface FilePickerProps extends NoChildrenProps, LayoutProps, TestProps, IdProps {
    /** Specifies a name of the input tag */
    name: string;
    /** Specifies the main text of the label for the form element */
    label?: string;
    /** If set the field is required */
    required?: boolean;
    /** If set shows the required text */
    showRequiredLabel?: boolean;
    /** Sets the input to disabled */
    disabled?: boolean;
    /** Maximum file size (in MB) */
    maxSingleFileSizeInMB: number;
    /** Maximum of sum of file sizes (in MB) */
    maxSumOfFileSizesInMB: number;
    /** Maximum count of files that can be uploaded */
    maxFileCount: number;
    /** mime types that can be selected, comma separated
     * `undefined` to allow all file types
     * note that directly passing file extensions (e.g. ".png") is discouraged, as due to browser limitations, the files won't be detected correctly
     */
    accept?: string;
    /** A reject reason for the last drop that should be shown for the user.
     *  `undefined` for no reason.
     */
    rejectReason?: RejectReason;
    /** The files that should be displayed as already added */
    files: FileWithAcceptanceState[];
    /** Function that gets called when files are dropped or removed.
     *  Files are _not_ expected to be collected from the `files` property from the `input` field,
     *  but rather by listening on the `onFilesChanged` callback.
     */
    onFilesChanged?: (changeEvent: FilePickerChangeEvent) => void;
    /** Refs provide a way to access DOM nodes or React elements created in the render method. */
    innerRef?: RefObject<HTMLInputElement>;
}
export declare type DroppabilityState = 'droppable' | 'fileCountExceeded' | 'fileSizesSumExceeded' | 'fileCountReached' | 'disabled';
export declare type AcceptanceState = 'accepted' | 'rejected';
export interface FileWithAcceptanceState {
    file: File;
    mimeTypeAcceptanceState: AcceptanceState;
    singleFileSizeAcceptanceState: AcceptanceState;
}
export interface FilePickerChangeEvent {
    /** This includes single files that are rejected for their file size or type.
     *  It also includes previously dropped files from the `files` prop.
     */
    allDroppedFiles: FileWithAcceptanceState[];
    /** If the last drop was rejected, this prop contains the reject reason and the rejected files. */
    rejectedDrop?: FilePickerRejectInfo;
}
export interface FilePickerRejectInfo {
    rejectedFiles: FileWithAcceptanceState[];
    rejectReason: RejectReason;
}
export declare type RejectReason = 'fileCountExceeded' | 'fileSizesSumExceeded';
