"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.getDroppabilityState = exports.removeFile = exports.onDrop = void 0;

var _filter = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/filter"));

var _reduce = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/reduce"));

var _concat = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/concat"));

var _map = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/map"));

var onDrop = function onDrop(props) {
  return function (acceptedFiles, rejectedFiles) {
    if (!props.onFilesChanged) {
      return;
    }

    var acceptedFilesWithAcceptanceStates = (0, _map["default"])(acceptedFiles).call(acceptedFiles, function (f) {
      var fa = {
        file: f,
        mimeTypeAcceptanceState: 'accepted',
        singleFileSizeAcceptanceState: singleFileSizeAcceptanceStateOfFile(props)(f)
      };
      return fa;
    });
    var rejectedFilesWithAcceptanceStates = (0, _map["default"])(rejectedFiles).call(rejectedFiles, function (f) {
      var fa = {
        file: f,
        mimeTypeAcceptanceState: 'rejected',
        singleFileSizeAcceptanceState: singleFileSizeAcceptanceStateOfFile(props)(f)
      };
      return fa;
    });
    var acceptedAndRejectedFilesWithAcceptanceStates = (0, _concat["default"])(acceptedFilesWithAcceptanceStates).call(acceptedFilesWithAcceptanceStates, rejectedFilesWithAcceptanceStates);
    var appendedFiles = appendedAndDedupedFiles(props.files, acceptedAndRejectedFilesWithAcceptanceStates);
    var fileSizesSum = (0, _reduce["default"])(appendedFiles).call(appendedFiles, function (total, f) {
      return total + f.file.size;
    }, 0);

    if (appendedFiles.length > props.maxFileCount) {
      props.onFilesChanged({
        allDroppedFiles: props.files,
        rejectedDrop: {
          rejectedFiles: acceptedAndRejectedFilesWithAcceptanceStates,
          rejectReason: 'fileCountExceeded'
        }
      });
    } else if (fileSizesSum > props.maxSumOfFileSizesInMB * 1024 * 1024) {
      props.onFilesChanged({
        allDroppedFiles: props.files,
        rejectedDrop: {
          rejectedFiles: acceptedAndRejectedFilesWithAcceptanceStates,
          rejectReason: 'fileSizesSumExceeded'
        }
      });
    } else {
      props.onFilesChanged({
        allDroppedFiles: appendedFiles
      });
    }
  };
};

exports.onDrop = onDrop;

var appendedAndDedupedFiles = function appendedAndDedupedFiles(existingFiles, addedFiles) {
  var updatedFiles = existingFiles;
  updatedFiles = (0, _concat["default"])(updatedFiles).call(updatedFiles, addedFiles);
  updatedFiles = uniqFiles(updatedFiles);
  return updatedFiles;
};

var uniqFiles = function uniqFiles(files) {
  // currenty wh-components is expected not to depend on polyfills, so we need to provide an implementation of Array.prototype.findIndex ourself
  // polyfill is adapted from https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/findIndex#Polyfill
  var findIndex = function findIndex(array, predicate) {
    var k = 0;

    while (k < array.length) {
      if (predicate.call(array, array[k])) {
        return k;
      }

      k++;
    }

    return -1;
  };

  return (0, _filter["default"])(files).call(files, function (item1, pos, self) {
    return findIndex(self, function (item2) {
      return item1.file.name === item2.file.name;
    }) === pos;
  });
};

var removeFile = function removeFile(props) {
  return function (file) {
    var _context;

    if (!props.onFilesChanged) {
      return;
    }

    var remainingFiles = (0, _filter["default"])(_context = props.files).call(_context, function (f) {
      return f !== file;
    });
    props.onFilesChanged({
      allDroppedFiles: remainingFiles
    });
  };
};

exports.removeFile = removeFile;

var getDroppabilityState = function getDroppabilityState(rejectReason, fileCountReached) {
  if (rejectReason !== undefined) {
    return rejectReason;
  } else if (fileCountReached) {
    return 'fileCountReached';
  } else {
    return 'droppable';
  }
};

exports.getDroppabilityState = getDroppabilityState;

var singleFileSizeAcceptanceStateOfFile = function singleFileSizeAcceptanceStateOfFile(props) {
  return function (file) {
    var fileSizeExceeded = file.size > props.maxSingleFileSizeInMB * 1024 * 1024;
    return fileSizeExceeded ? 'rejected' : 'accepted';
  };
};