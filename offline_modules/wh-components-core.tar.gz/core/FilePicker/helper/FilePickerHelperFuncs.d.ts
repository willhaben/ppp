import { DroppabilityState, FilePickerProps, FileWithAcceptanceState } from './FilePickerHelperTypes';
export declare const onDrop: (props: Pick<FilePickerProps, 'files' | 'onFilesChanged' | 'maxFileCount' | 'maxSumOfFileSizesInMB' | 'maxSingleFileSizeInMB'>) => (acceptedFiles: File[], rejectedFiles: File[]) => void;
export declare const removeFile: (props: Pick<FilePickerProps, 'files' | 'onFilesChanged'>) => (file: FileWithAcceptanceState) => void;
export declare const getDroppabilityState: (rejectReason: DroppabilityState | undefined, fileCountReached: boolean) => DroppabilityState;
