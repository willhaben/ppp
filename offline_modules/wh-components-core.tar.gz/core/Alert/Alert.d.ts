import { FunctionComponent } from 'react';
import { IconType } from '@wh-components/icons/utilities/createSvgIcon';
import { TestProps } from '../common';
import { SpaceProps } from '@wh-components/system/space';
import { LayoutProps } from '@wh-components/system/layout';
import { PositionProps } from '@wh-components/system/position';
import { FlexItemProps } from '@wh-components/system/flexbox';
export declare type AlertVariant = 'info' | 'success' | 'warning' | 'error';
interface AlertProps extends TestProps, SpaceProps, LayoutProps, PositionProps, FlexItemProps {
    variant?: AlertVariant;
    Icon?: IconType;
    title?: string;
    dismissable?: boolean;
    autoDismiss?: number;
    onDidDismiss?: () => void;
}
export declare const Alert: FunctionComponent<AlertProps>;
export {};
