"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Alert = void 0;

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _setTimeout2 = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/set-timeout"));

var _slicedToArray2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/slicedToArray"));

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _react = _interopRequireWildcard(require("react"));

var _variant = require("@wh-components/system/variant");

var _system = require("@wh-components/system");

var _common = require("../common");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _position = require("@wh-components/system/position");

var _flexbox = require("@wh-components/system/flexbox");

var _Box = require("../Box/Box");

var _Text = require("../Text/Text");

var _CloseButton = require("../CloseButton/CloseButton");

var alertVariants = (0, _variant.variant)({
  scale: 'components.alert.colors',
  prop: 'variant'
});

var AlertContainer = _styledComponents["default"].div.attrs(_common.testIdAttribute).withConfig({
  displayName: "Alert__AlertContainer",
  componentId: "n1a3n8-0"
})(["position:relative;display:flex;align-items:center;padding:", "px;border:1px solid currentColor;border-radius:", "px;", ""], function (p) {
  return p.theme.space.m;
}, function (p) {
  return p.theme.borderRadii.m;
}, (0, _system.compose)(alertVariants, _space.space, _layout.layout, _position.position, _flexbox.flexItem));

var _StyledCloseButton = (0, _styledComponents["default"])(_CloseButton.CloseButton).withConfig({
  displayName: "Alert___StyledCloseButton",
  componentId: "n1a3n8-1"
})(["color:inherit;"]);

var Alert = function Alert(_ref) {
  var testId = _ref.testId,
      _ref$variant = _ref.variant,
      variant = _ref$variant === void 0 ? 'info' : _ref$variant,
      Icon = _ref.Icon,
      title = _ref.title,
      dismissable = _ref.dismissable,
      autoDismiss = _ref.autoDismiss,
      onDidDismiss = _ref.onDidDismiss,
      children = _ref.children,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["testId", "variant", "Icon", "title", "dismissable", "autoDismiss", "onDidDismiss", "children"]);

  var _useState = (0, _react.useState)(true),
      _useState2 = (0, _slicedToArray2["default"])(_useState, 2),
      show = _useState2[0],
      setShow = _useState2[1];

  (0, _react.useEffect)(function () {
    if (autoDismiss) {
      var timer = (0, _setTimeout2["default"])(function () {
        setShow(false);
        onDidDismiss === null || onDidDismiss === void 0 ? void 0 : onDidDismiss();
      }, autoDismiss);
      return function () {
        return clearTimeout(timer);
      };
    }

    return;
  });
  var iconProps = {
    size: 40,
    color: 'inherit',
    marginRight: 'm',
    'aria-hidden': true
  };
  return (title || children) && show ? /*#__PURE__*/_react["default"].createElement(AlertContainer, (0, _extends2["default"])({}, props, {
    variant: variant,
    role: variant === 'error' ? 'alert' : 'status',
    testId: testId
  }), Icon && /*#__PURE__*/(0, _react.createElement)(Icon, iconProps), /*#__PURE__*/_react["default"].createElement(_Box.Box, {
    display: "flex",
    flexDirection: "column",
    flex: "1 1 100%"
  }, title && /*#__PURE__*/_react["default"].createElement(_Text.Text, {
    fontSize: "l",
    fontWeight: "bold"
  }, title), children), dismissable && /*#__PURE__*/_react["default"].createElement(_StyledCloseButton, {
    size: "xsmall",
    position: "absolute",
    top: 0,
    right: 0,
    "aria-label": "Hinweis schlie\xDFen",
    testId: testId && "".concat(testId, "-close-button"),
    onClick: function onClick() {
      setShow(false);
      onDidDismiss === null || onDidDismiss === void 0 ? void 0 : onDidDismiss();
    }
  })) : null;
};

exports.Alert = Alert;