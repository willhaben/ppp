"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Avatar = exports.avatarSize = void 0;

var _objectWithoutProperties2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/objectWithoutProperties"));

var _react = _interopRequireDefault(require("react"));

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _common = require("../common");

var _system = require("@wh-components/system");

var _utilities = require("@wh-components/system/utilities");

var _space = require("@wh-components/system/space");

var _layout = require("@wh-components/system/layout");

var _position = require("@wh-components/system/position");

var _flexbox = require("@wh-components/system/flexbox");

var _ProfilePicPlaceholder = _interopRequireDefault(require("@wh-components/icons/ProfilePicPlaceholder"));

var avatarSize = (0, _system.system)({
  size: {
    properties: ['height', 'width'],
    scale: 'components.avatar.sizes',
    transform: function transform(n, scale) {
      return (0, _utilities.isString)(n) ? (0, _utilities.getFromKeyPath)(scale, n, n) : n;
    }
  }
});
exports.avatarSize = avatarSize;

var Container = _styledComponents["default"].div.attrs(_common.testIdAttribute).withConfig({
  displayName: "Avatar__Container",
  componentId: "sc-1aip38w-0"
})(["display:inline-flex;flex-shrink:0;border-radius:50%;user-select:none;> img,> svg{height:100%;width:100%;object-fit:cover;border-radius:50%;}> svg{border:1px solid ", ";}", ""], function (p) {
  return p.theme.colors.palette.seal;
}, (0, _system.compose)(avatarSize, _space.margin, _layout.display, _position.position, _flexbox.flexItem));

var Avatar = function Avatar(_ref) {
  var src = _ref.src,
      _ref$alt = _ref.alt,
      alt = _ref$alt === void 0 ? 'Profilbild' : _ref$alt,
      props = (0, _objectWithoutProperties2["default"])(_ref, ["src", "alt"]);
  return /*#__PURE__*/_react["default"].createElement(Container, props, src ? /*#__PURE__*/_react["default"].createElement("img", {
    src: src,
    alt: alt
  }) : /*#__PURE__*/_react["default"].createElement(_ProfilePicPlaceholder["default"], null));
};

exports.Avatar = Avatar;
Avatar.defaultProps = {
  size: 'medium'
};