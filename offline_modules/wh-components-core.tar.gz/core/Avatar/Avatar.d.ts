import { FunctionComponent } from 'react';
import { NoChildrenProps, TestProps } from '../common';
import { ResponsiveValue } from '@wh-components/system';
import { MarginProps } from '@wh-components/system/space';
import { DisplayProps } from '@wh-components/system/layout';
import { PositionProps } from '@wh-components/system/position';
import { FlexItemProps } from '@wh-components/system/flexbox';
export declare const avatarSize: import("@wh-components/system").ParserFunction;
declare type AvatarSizeType = 'xsmall' | 'small' | 'medium' | 'large' | 'xlarge' | number;
interface AvatarProps extends NoChildrenProps {
    size?: ResponsiveValue<AvatarSizeType>;
    src?: string;
    alt?: string;
}
declare type ContainerProps = TestProps & MarginProps & DisplayProps & PositionProps & FlexItemProps;
export declare const Avatar: FunctionComponent<AvatarProps & ContainerProps>;
export {};
