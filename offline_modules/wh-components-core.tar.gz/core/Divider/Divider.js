"use strict";

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty(exports, "__esModule", {
  value: true
});

exports.Divider = void 0;

var _styledComponents = _interopRequireDefault(require("styled-components"));

var _space = require("@wh-components/system/space");

var _system = require("@wh-components/system");

var dividerMargin = function dividerMargin(orientation) {
  return (0, _system.system)({
    marginStart: {
      property: orientation === 'horizontal' ? 'marginTop' : 'marginLeft',
      scale: 'space'
    },
    marginEnd: {
      property: orientation === 'horizontal' ? 'marginBottom' : 'marginRight',
      scale: 'space'
    }
  });
};

var Divider = _styledComponents["default"].hr.withConfig({
  displayName: "Divider",
  componentId: "sc-2vp0ed-0"
})(["margin:0;height:", ";width:", ";flex-shrink:0;border:0;background-color:", ";", ""], function (p) {
  return p.orientation === 'horizontal' && '1px';
}, function (p) {
  return p.orientation === 'vertical' && '1px';
}, function (p) {
  return p.theme.colors.palette.owl;
}, function (p) {
  return (0, _system.compose)(_space.margin, dividerMargin(p.orientation));
});

exports.Divider = Divider;
Divider.defaultProps = {
  orientation: 'horizontal'
};