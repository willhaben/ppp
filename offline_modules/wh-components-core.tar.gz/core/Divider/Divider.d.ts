import { MarginProps } from '@wh-components/system/space';
import { ResponsiveValue, SystemValue } from '@wh-components/system';
declare type DividerOrientation = 'horizontal' | 'vertical';
interface DividerProps extends MarginProps {
    orientation?: DividerOrientation;
    marginStart?: ResponsiveValue<SystemValue>;
    marginEnd?: ResponsiveValue<SystemValue>;
}
export declare const Divider: import("styled-components").StyledComponent<"hr", import("styled-components").DefaultTheme, DividerProps, never>;
export {};
