"use strict";

var _interopRequireWildcard = require("@babel/runtime-corejs3/helpers/interopRequireWildcard");

var _interopRequireDefault = require("@babel/runtime-corejs3/helpers/interopRequireDefault");

var _Object$defineProperty2 = require("@babel/runtime-corejs3/core-js-stable/object/define-property");

_Object$defineProperty2(exports, "__esModule", {
  value: true
});

exports.ToastContainer = exports.dismissAllToasts = exports.toast = void 0;

var _defineProperty2 = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/define-property"));

var _defineProperties = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/define-properties"));

var _getOwnPropertyDescriptors = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors"));

var _forEach = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/for-each"));

var _getOwnPropertyDescriptor = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor"));

var _filter = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/instance/filter"));

var _getOwnPropertySymbols = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols"));

var _keys = _interopRequireDefault(require("@babel/runtime-corejs3/core-js-stable/object/keys"));

var _taggedTemplateLiteral2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/taggedTemplateLiteral"));

var _extends2 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/extends"));

var _defineProperty3 = _interopRequireDefault(require("@babel/runtime-corejs3/helpers/defineProperty"));

var _styledComponents = _interopRequireWildcard(require("styled-components"));

var _react = _interopRequireWildcard(require("react"));

var _reactToastify = require("react-toastify");

var _Alert = require("../Alert/Alert");

var _CloseButton = require("../CloseButton/CloseButton");

function _templateObject() {
  var data = (0, _taggedTemplateLiteral2["default"])(["\n    .Toastify__toast-container {\n        width: 100%;\n        padding: ", "px;\n\n        ", " {\n            width: ", "px;\n            padding: ", "px;\n        }\n\n        ", " {\n            &--top-center, &--bottom-center {\n                left: 0;\n                margin-left: 0;\n            }\n        }\n\n        &--top-left, &--top-center, &--top-right {\n            top: 0;\n        }\n\n        &--bottom-left, &--bottom-center, &--bottom-right {\n            bottom: 0;\n        }\n\n        &--top-left, &--bottom-left {\n            left: 0;\n        }\n\n        &--top-right, &--bottom-right {\n            right: 0;\n        }\n    }\n\n    .Toastify__toast {\n        display: block;\n        min-height: auto;\n        margin: 0;\n        padding: 0;\n        border-radius: ", "px;\n        box-shadow: 0 0 16px 4px rgba(0, 0, 0, 0.05), 0 2px 4px rgba(0, 0, 0, 0.1);\n\n        &:not(:first-child) {\n            margin-top: ", "px;\n        }\n\n        &--info {\n            color: ", ";\n            background-color: ", ";\n        }\n\n        &--success {\n            color: ", ";\n            background-color: ", ";\n        }\n\n        &--warning {\n            color: ", ";\n            background-color: ", ";\n        }\n\n        &--error {\n            color: ", ";\n            background-color: ", ";\n        }\n    }\n\n    .Toastify__progress-bar {\n        background: currentColor;\n    }\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function ownKeys(object, enumerableOnly) { var keys = (0, _keys["default"])(object); if (_getOwnPropertySymbols["default"]) { var symbols = (0, _getOwnPropertySymbols["default"])(object); if (enumerableOnly) symbols = (0, _filter["default"])(symbols).call(symbols, function (sym) { return (0, _getOwnPropertyDescriptor["default"])(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { var _context; (0, _forEach["default"])(_context = ownKeys(Object(source), true)).call(_context, function (key) { (0, _defineProperty3["default"])(target, key, source[key]); }); } else if (_getOwnPropertyDescriptors["default"]) { (0, _defineProperties["default"])(target, (0, _getOwnPropertyDescriptors["default"])(source)); } else { var _context2; (0, _forEach["default"])(_context2 = ownKeys(Object(source))).call(_context2, function (key) { (0, _defineProperty2["default"])(target, key, (0, _getOwnPropertyDescriptor["default"])(source, key)); }); } } return target; }

var toast = function toast(content, options) {
  var defaultOptions = _objectSpread({
    type: (options === null || options === void 0 ? void 0 : options.type) || 'info',
    role: (options === null || options === void 0 ? void 0 : options.type) === 'error' ? 'alert' : 'status'
  }, options);

  return (0, _reactToastify.toast)(typeof content === 'string' ? /*#__PURE__*/_react["default"].createElement(_Alert.Alert, {
    variant: options === null || options === void 0 ? void 0 : options.type,
    Icon: options === null || options === void 0 ? void 0 : options.Icon
  }, content) : content, defaultOptions);
};
/**
 * Dismiss all open toasts.
 */


exports.toast = toast;

var dismissAllToasts = function dismissAllToasts() {
  return _reactToastify.toast.dismiss();
};

exports.dismissAllToasts = dismissAllToasts;

var ToastContainer = function ToastContainer(props) {
  return /*#__PURE__*/_react["default"].createElement(_react.Fragment, null, /*#__PURE__*/_react["default"].createElement(GlobalToastifyStyle, null), /*#__PURE__*/_react["default"].createElement(_reactToastify.ToastContainer, (0, _extends2["default"])({
    closeButton: /*#__PURE__*/_react["default"].createElement(ToastCloseButton, null)
  }, props)));
};

exports.ToastContainer = ToastContainer;
ToastContainer.defaultProps = {
  autoClose: 5000,
  closeOnClick: false,
  draggablePercent: 60,
  position: 'bottom-left'
};

var _StyledCloseButton = (0, _styledComponents["default"])(_CloseButton.CloseButton).withConfig({
  displayName: "Toast___StyledCloseButton",
  componentId: "sc-176q47h-0"
})(["color:inherit;&:focus{box-shadow:none;}"]);

var ToastCloseButton = function ToastCloseButton(_ref) {
  var closeToast = _ref.closeToast;
  return /*#__PURE__*/_react["default"].createElement(_StyledCloseButton, {
    size: "xsmall",
    position: "absolute",
    top: 0,
    right: 0,
    "aria-label": "Hinweis schlie\xDFen",
    onClick: function onClick() {
      return closeToast === null || closeToast === void 0 ? void 0 : closeToast();
    }
  });
};

var GlobalToastifyStyle = (0, _styledComponents.createGlobalStyle)(_templateObject(), function (p) {
  return p.theme.space.s;
}, function (p) {
  return p.theme.media.tablet;
}, function (p) {
  return 300 + 2 * p.theme.space.m;
}, function (p) {
  return p.theme.space.m;
}, function (p) {
  return p.theme.media.only.phone;
}, function (p) {
  return p.theme.borderRadii.m;
}, function (p) {
  return p.theme.space.s;
}, function (p) {
  return p.theme.colors.alert.info.main;
}, function (p) {
  return p.theme.colors.alert.info.background;
}, function (p) {
  return p.theme.colors.alert.success.main;
}, function (p) {
  return p.theme.colors.alert.success.background;
}, function (p) {
  return p.theme.colors.alert.warning.main;
}, function (p) {
  return p.theme.colors.alert.warning.background;
}, function (p) {
  return p.theme.colors.alert.error.main;
}, function (p) {
  return p.theme.colors.alert.error.background;
});