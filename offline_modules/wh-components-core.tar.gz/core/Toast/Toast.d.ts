import { FunctionComponent, ReactNode } from 'react';
import { ToastOptions as ToastifyOptions, ToastContainerProps } from 'react-toastify';
import { AlertVariant } from '../Alert/Alert';
import { IconType } from '@wh-components/icons/utilities/createSvgIcon';
export declare type ToastOptions = ToastifyOptions & {
    type?: AlertVariant;
    Icon?: IconType;
};
export declare const toast: (content: ReactNode, options?: ToastOptions | undefined) => import("csstype").AnimationIterationCountProperty;
/**
 * Dismiss all open toasts.
 */
export declare const dismissAllToasts: () => void;
export declare const ToastContainer: FunctionComponent<ToastContainerProps>;
